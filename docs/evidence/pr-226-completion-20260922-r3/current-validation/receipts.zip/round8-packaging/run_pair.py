"""New retrospective effectiveness pair, never recovery of original R7 chronology."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

P = Path(__file__).resolve().parent
W = Path("C:/LOCAL/actor/repos/ecorp/worktrees/pr226-r7-public-evidence")
PAIR = P / "retrospective-pair"
OLD = "9d79db02c814497f93eed4b8d7c842cb2518d153"
TREE = "2cf0ea4851f09cbdb7cf3f08a6c3422abda416a8"
HELPER = "tools/check_evidence_personal_paths.mjs"
TEST = "tools/check_evidence_personal_paths.test.mjs"
ROOTS = ["docs/evidence/pr226-integration-20260921",
         "docs/evidence/pr226-local-validation",
         "docs/evidence/pr-226-completion-20260922-r3"]
NAME = "retained PR226 packets including r3 are scanned for personal user paths"
NODE = Path("C:/LOCAL/actor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe")
GIT = Path(shutil.which("git"))
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path, value):
    with Path(path).open("xb") as f:
        f.write((json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode())
def git(*args):
    return subprocess.check_output([str(GIT), *args], cwd=W,
        env={**os.environ, "GIT_OPTIONAL_LOCKS":"0"}, creationflags=subprocess.CREATE_NO_WINDOW)
def object_id(data):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
base = json.loads((P.parent / "round8-integration/validation/source-before.json").read_bytes())
before_package = json.loads((P / "before.json").read_bytes())
first = json.loads((P / "final-handoff.json").read_bytes())
assert git("rev-parse","HEAD").decode().strip() == base["head"]
assert git("rev-parse","MERGE_HEAD").decode().strip() == base["merge_head"]
assert sha(Path(base["index_path"]).read_bytes()) == base["index_sha256"]
assert git("rev-parse",OLD+"^{commit}").decode().strip() == OLD
PAIR.mkdir()
save(PAIR/".owner.json", {"purpose":"PR226 retrospective existing-regression pair",
    "retain":True,"created_at":now(),"source_checkout_writes":False,"root":str(PAIR)})

def snapshot():
    return {"head":git("rev-parse","HEAD").decode().strip(),
        "merge_head":git("rev-parse","MERGE_HEAD").decode().strip(),
        "index_sha256":sha(Path(base["index_path"]).read_bytes()),
        "index_entries_sha256":sha(git("ls-files","--stage","-z")),
        "tracked_files":{name:sha((W/name).read_bytes()) for name in base["tracked_files"]},
        "packet":{name:sha((W/name).read_bytes()) for name in first["public_files"]},
        "git_controls":{name:sha(Path(item["path"]).read_bytes()) if Path(item["path"]).is_file() else None
                        for name,item in base["git_control_files"].items()},
        "selected_refs":{ref:git("rev-parse",ref).decode().strip() for ref in before_package["selected_refs"]}}
source = snapshot()
assert source["selected_refs"] == before_package["selected_refs"]
save(PAIR/"source-before.json",source)
old_helper = git("show",OLD+":"+HELPER)
test_work = (W/TEST).read_bytes()
test_index = git("show",":"+TEST)
helper_work = (W/HELPER).read_bytes()
helper_index = git("show",":"+HELPER)
assert helper_work.replace(b"\r\n",b"\n") == helper_index
assert test_work.replace(b"\r\n",b"\n") == test_index
assert git("hash-object","--path="+HELPER,HELPER).decode().strip() == object_id(helper_index)
assert git("hash-object","--path="+TEST,TEST).decode().strip() == object_id(test_index)
assert b"../docs/evidence/pr-226-completion-20260922-r3/" not in old_helper
assert b"../docs/evidence/pr-226-completion-20260922-r3/" in helper_work
declared = re.findall(rb"^test\('([^']+)'",test_work,re.M)
assert len(declared) == 6 and NAME.encode() in declared
driver_sha = sha(Path(__file__).read_bytes())
node_sha = sha(NODE.read_bytes())
node_version = subprocess.check_output([str(NODE),"--version"],creationflags=subprocess.CREATE_NO_WINDOW).decode().strip()
git_sha = sha(GIT.read_bytes())
git_version = git("--version").decode().strip()
env = {k:v for k,v in os.environ.items() if k.upper() in
    {"SYSTEMROOT","WINDIR","COMSPEC","PATH","PATHEXT","TEMP","TMP","USERPROFILE","LOCALAPPDATA","APPDATA"}}
env.update({"GIT_OPTIONAL_LOCKS":"0","CI":"true"})
assert "NODE_OPTIONS" not in env

def entries(revision):
    result = {}
    for item in git("ls-tree","-r","-z",revision,"--",*ROOTS).split(b"\0")[:-1]:
        metadata,name = item.split(b"\t",1)
        mode,kind,blob = metadata.split()
        assert mode == b"100644" and kind == b"blob"
        path = name.decode()
        assert any(path.startswith(root+"/") for root in ROOTS)
        result[path] = blob.decode()
    return result
def blobs(ids):
    distinct = sorted(set(ids))
    raw = subprocess.check_output([str(GIT),"cat-file","--batch"],cwd=W,
        input=("\n".join(distinct)+"\n").encode(),env={**os.environ,"GIT_OPTIONAL_LOCKS":"0"},
        creationflags=subprocess.CREATE_NO_WINDOW)
    cursor,result = 0,{}
    for wanted in distinct:
        end = raw.index(b"\n",cursor)
        blob,kind,length = raw[cursor:end].split()
        assert blob.decode() == wanted and kind == b"blob"
        cursor=end+1;data=raw[cursor:cursor+int(length)];cursor+=int(length)+1
        assert object_id(data)==wanted
        result[wanted]=data
    assert cursor==len(raw)
    return result

plans = []
for label,revision,helper in [("old",OLD,old_helper),("current",TREE,helper_work)]:
    fixture = PAIR/("fixture-"+label)
    fixture.mkdir()
    docs = entries(revision)
    if label == "current":
        for name,blob in docs.items():
            assert git("rev-parse",":"+name).decode().strip() == blob
    content = blobs(docs.values())
    inventory = {}
    for name,blob in docs.items():
        destination = fixture/name;destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(content[blob])
        inventory[name]={"source_revision":revision,"git_blob":blob,
                         "copied_sha256":sha(destination.read_bytes()),"bytes":len(content[blob]),
                         "copy_rule":"exact raw Git blob; no path or newline normalization"}
    for name,data,index_data,origin in [
        (HELPER,helper,old_helper if label=="old" else helper_index,OLD if label=="old" else TREE),
        (TEST,test_work,test_index,TREE)]:
        destination=fixture/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
        inventory[name]={"source_revision":origin,"git_blob":object_id(index_data),
            "copied_sha256":sha(data),"bytes":len(data),
            "index_bytes_sha256":sha(index_data),"index_bytes":len(index_data),
            "working_sha256":sha((W/name).read_bytes()) if not(label=="old" and name==HELPER) else None,
            "copy_rule":"git show exact original commit bytes" if label=="old" and name==HELPER
                        else "exact current working bytes; verified CRLF-only native checkout conversion and native clean blob equals index"}
    assert (fixture/TEST).read_bytes() == test_work
    assert (fixture/HELPER).read_bytes() == helper
    assert all(any(n.startswith(r+"/") for n in docs) for r in ROOTS)
    argv=[str(NODE),"--test","--test-reporter=tap","--test-name-pattern=^"+NAME+"$",TEST]
    binding={"kind":"NEW retrospective effectiveness execution; not original R7 TDD chronology",
        "lane":label,"prepared_at":now(),"cwd":str(fixture),"argv":argv,"environment":env,
        "original_commit":OLD,"candidate_head":base["head"],"candidate_index_tree":TREE,
        "merge_head":base["merge_head"],"real_index_sha256":source["index_sha256"],
        "helper":inventory[HELPER],"regression":inventory[TEST],"copied_files":inventory,
        "docs_roots":ROOTS,"declared_tests":len(declared),"selected_test":NAME,
        "not_selected_tests":[n.decode() for n in declared if n!=NAME.encode()],
        "test_origin_note":"The unchanged existing current regression is copied into BOTH fixtures; it was introduced after the original baseline.",
        "input_equivalence":"Original helper/docs are exact original-commit blobs. Current helper/test are exact working copies native-clean-equivalent to index; current docs are exact index/tree blobs. New current-validation evidence files and unstaged README addition are intentionally excluded.",
        "no_mocks":"Unmodified imported helper uses real default root resolution and recursive filesystem scanner; no monkeypatch/root override.",
        "driver":{"path":str(Path(__file__).resolve()),"sha256":driver_sha,"python":sys.executable,
                  "python_sha256":sha(Path(sys.executable).read_bytes())},
        "node":{"path":str(NODE),"sha256":node_sha,"version":node_version},
        "git":{"path":str(GIT),"sha256":git_sha,"version":git_version},
        "source_snapshot":"source-before.json","source_snapshot_sha256":sha((PAIR/"source-before.json").read_bytes())}
    save(PAIR/(label+".before.json"),binding)
    plans.append((label,fixture,argv,binding))

# BOTH bindings and all copied inputs are written and verified before either test.
save(PAIR/"pair-preexecution.json",{"at":now(),"driver_sha256":driver_sha,
    "bindings":{label:sha((PAIR/(label+".before.json")).read_bytes()) for label,_,_,_ in plans},
    "scope":"Only the existing selected test; five other declared cases excluded in each lane. No heavy validation."})
outcomes=[]
for label,fixture,argv,binding in plans:
    assert snapshot()==source
    assert sha(Path(__file__).read_bytes())==driver_sha and sha(NODE.read_bytes())==node_sha
    for name,record in binding["copied_files"].items():
        assert sha((fixture/name).read_bytes())==record["copied_sha256"]
    started=now()
    result=subprocess.run(argv,cwd=fixture,env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
    (PAIR/(label+".stdout.log")).write_bytes(result.stdout)
    (PAIR/(label+".stderr.log")).write_bytes(result.stderr)
    summary={key.decode():int(value) for key,value in re.findall(
        rb"^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\r?$",result.stdout,re.M)}
    unchanged=all(sha((fixture/name).read_bytes())==record["copied_sha256"] for name,record in binding["copied_files"].items())
    receipt={"kind":"NEW retrospective effectiveness result, not historical TDD proof","lane":label,
        "started_at":started,"ended_at":now(),"exit_code":result.returncode,"summary":summary,
        "binding_sha256":sha((PAIR/(label+".before.json")).read_bytes()),
        "preexecution_pair_sha256":sha((PAIR/"pair-preexecution.json").read_bytes()),
        "logs":{stream:{"file":label+"."+stream+".log","sha256":sha(raw),"bytes":len(raw)}
                for stream,raw in [("stdout",result.stdout),("stderr",result.stderr)]},
        "declared_tests":6,"selected_tests":1,"excluded_by_name_pattern":5,
        "source_index_merge_unchanged":snapshot()==source,
        "copied_inputs_unchanged":unchanged,"node_unchanged":sha(NODE.read_bytes())==node_sha,
        "driver_unchanged":sha(Path(__file__).read_bytes())==driver_sha}
    save(PAIR/(label+".result.json"),receipt)
    assert receipt["source_index_merge_unchanged"] and unchanged
    assert receipt["node_unchanged"] and receipt["driver_unchanged"]
    assert result.returncode==(1 if label=="old" else 0)
    assert summary["fail"]==(1 if label=="old" else 0)
    assert summary["pass"]==(0 if label=="old" else 1)
    if label=="old":
        assert b"default scan must include the r3 completion packet" in result.stdout
    outcomes.append(receipt)
save(PAIR/"source-after.json",snapshot())
save(PAIR/"pair-result.json",{"status":"PASS: expected OLD failure and CURRENT success",
    "kind":"NEW retrospective effectiveness pair; not recovery of original TDD time",
    "original_commit":OLD,"candidate_head":base["head"],"candidate_index_tree":TREE,
    "lane_results":outcomes,"source_preserved":snapshot()==source,
    "limits":"Existing current test introduced after baseline. Single selected regression only; no nine-gate/Factory/independent approval."})
print(json.dumps({"kind":"new retrospective pair","outcomes":[
    {"lane":r["lane"],"exit":r["exit_code"],"summary":r["summary"],"excluded":5} for r in outcomes]},indent=2))
