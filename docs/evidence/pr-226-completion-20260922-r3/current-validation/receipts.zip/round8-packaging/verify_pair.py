"""Read-only verification of the packet; finalization writes only owned receipts."""
from pathlib import PurePosixPath
import datetime
import hashlib
import json
import os
import re
import stat
import struct
import subprocess
import zlib
import zipfile
import package_pair as p

before = p.load(p.P / "before.json")
manifest = p.load(p.OUT / "manifest.json")
checks = []
def check(name, condition):
    assert condition, name
    checks.append(name)

check("Original R8 artifact inventory, outcomes and author assertions reverified", p.raw_checks()[1] > 0)
prior = p.load(p.P / "first-packaging-preserved.json")
for name,record in prior["files"].items():
    raw = (p.P / "first-packaging" / name).read_bytes()
    check("First packet preserved: "+name, p.sha(raw)==record["sha256"] and len(raw)==record["bytes"])
pair = p.P / "retrospective-pair"
pair_summary = p.load(pair / "pair-result.json")
preflight = p.load(pair / "pair-preexecution.json")
old_binding = p.load(pair/"old.before.json")
current_binding = p.load(pair/"current.before.json")
check("Both preexecution bindings precede both actual test invocations",
      max(b["prepared_at"] for b in [old_binding,current_binding]) <= preflight["at"]
      < min(r["started_at"] for r in pair_summary["lane_results"]))
check("Same unchanged current regression in both fixtures",
      old_binding["regression"] == current_binding["regression"]
      and current_binding["regression"]["git_blob"]=="61839dfbfc30adc8adabbafeee73c021264553c6")
check("Source/index/merge/first-public-packet preserved during retrospective pair",
      p.load(pair/"source-before.json")==p.load(pair/"source-after.json") and pair_summary["source_preserved"])
check("Pair driver exact preexecution hash",
      p.sha((p.P/"run_pair.py").read_bytes())==preflight["driver_sha256"])
for lane,expected_exit in [("old",1),("current",0)]:
    b=p.load(pair/(lane+".before.json"));r=p.load(pair/(lane+".result.json"))
    check(lane+": exact preexecution binding",
          p.sha((pair/(lane+".before.json")).read_bytes())==preflight["bindings"][lane]==r["binding_sha256"])
    check(lane+": binding records driver and Node identities before invocation",
          b["driver"]["sha256"]==preflight["driver_sha256"]
          and p.sha(p.Path(b["node"]["path"]).read_bytes())==b["node"]["sha256"]
          and b["node"]["version"]=="v24.19.0")
    check(lane+": actual expected exit and selected/filter/skip counts",
          r["exit_code"]==expected_exit and r["selected_tests"]==1 and r["excluded_by_name_pattern"]==5
          and r["summary"]["tests"]==1 and r["summary"]["skipped"]==0
          and r["summary"]["fail"]==expected_exit and r["summary"]["pass"]==1-expected_exit)
    check(lane+": unmodified default-root regression argv",
          b["argv"][1:]==["--test","--test-reporter=tap",
          "--test-name-pattern=^retained PR226 packets including r3 are scanned for personal user paths$",
          "tools/check_evidence_personal_paths.test.mjs"])
    for stream,item in r["logs"].items():
        raw=(pair/item["file"]).read_bytes()
        check(lane+": original actual "+stream+" log hash",
              p.sha(raw)==item["sha256"] and len(raw)==item["bytes"])
    for name,item in b["copied_files"].items():
        raw=(pair/("fixture-"+lane)/name).read_bytes()
        check(lane+": retained copied input "+name,p.sha(raw)==item["copied_sha256"] and len(raw)==item["bytes"])
        # Reconstruct raw Git blob identity independently. Working helper/test use
        # the already established native CRLF-only checkout conversion.
        git_raw=raw.replace(b"\r\n",b"\n") if "working" in item["copy_rule"] else raw
        blob=hashlib.sha1(b"blob "+str(len(git_raw)).encode()+b"\0"+git_raw).hexdigest()
        check(lane+": copied bytes match bound Git blob "+name,blob==item["git_blob"])
    check(lane+": real source/index and fixture bytes unchanged",
          all(r[key] for key in ["source_index_merge_unchanged","copied_inputs_unchanged","node_unchanged","driver_unchanged"]))
check("OLD fails for the actual missing r3 default assertion",
      b"default scan must include the r3 completion packet" in (pair/"old.stdout.log").read_bytes())
check("CURRENT reaches and passes actual existing default-root scan",
      b"ok 1 - retained PR226 packets including r3" in (pair/"current.stdout.log").read_bytes()
      and b"assert.deepEqual(findPersonalPathFiles(), [])" in (pair/"fixture-current/tools/check_evidence_personal_paths.test.mjs").read_bytes())
originals = p.selection()
members = {r["member"]: r for r in manifest["archive_members"]}
with zipfile.ZipFile(p.OUT / "receipts.zip") as z:
    infos = z.infolist()
    check("Unique ZIP inventory exactly matches manifest", len(infos) == len(members) and set(z.namelist()) == set(members))
    check("ZIP CRCs pass", z.testzip() is None)
    check("ZIP bounded: <=250 entries, <=2MiB/member, <=16MiB expanded, <=4MiB compressed",
          len(infos) <= 250 and max(i.file_size for i in infos) <= 2*1024*1024
          and sum(i.file_size for i in infos) <= 16*1024*1024
          and (p.OUT / "receipts.zip").stat().st_size <= 4*1024*1024)
    for info in infos:
        name = info.filename
        path = PurePosixPath(name)
        check(name + ": safe regular text member",
              not path.is_absolute() and ".." not in path.parts and "\\" not in name and ":" not in name
              and not name.endswith("/") and not (info.flag_bits & 1)
              and stat.S_ISREG(info.external_attr >> 16)
              and path.suffix in {".json", ".jsonl", ".log", ".md", ".py", ".cjs"})
        record = members[name]
        raw = originals[name].read_bytes()
        public = z.read(name)
        check(name + ": original hash and size", (p.sha(raw), len(raw)) == (record["original_sha256"], record["original_bytes"]))
        check(name + ": public hash and size", (p.sha(public), len(public)) == (record["public_sha256"], record["public_bytes"]))
        # Independent normalization replay using the declared original-span hashes,
        # lengths and public replacements, not the packager's replacement function.
        result = bytearray()
        end = 0
        counts = {}
        rules = {r["original_span_sha256"]: r for r in record["path_substitutions"]}
        for match in p.PERSONAL.finditer(raw):
            key = p.sha(match.group())
            rule = rules[key]
            check(name + ": declared path span length", len(match.group()) == rule["original_span_bytes"])
            result.extend(raw[end:match.start()])
            result.extend(rule["public_span"].encode())
            end = match.end()
            counts[key] = counts.get(key, 0) + 1
        result.extend(raw[end:])
        check(name + ": exact path-only transformation and unchanged non-path bytes", bytes(result) == public)
        check(name + ": exact substitution counts", counts == {k:r["occurrences"] for k,r in rules.items()})
        check(name + ": decompressed personal-path scan", not p.PERSONAL.search(public))
        public.decode("utf-8")
        if path.suffix == ".json":
            json.loads(public)
        if path.suffix == ".jsonl":
            for line in public.splitlines():
                if line.strip():
                    json.loads(line)
    for alias, record in manifest["snapshot_aliases"].items():
        original = originals[alias].read_bytes()
        canonical = originals[record["member"]].read_bytes()
        check(alias + ": snapshot deduplication is byte-exact",
              original == canonical and p.sha(original) == record["original_sha256"]
              and p.sha(z.read(record["member"])) == record["public_sha256"])
    zip_stats = {"members":len(infos), "snapshot_aliases":len(manifest["snapshot_aliases"]),
                 "compressed_bytes":(p.OUT/"receipts.zip").stat().st_size,
                 "expanded_bytes":sum(i.file_size for i in infos),
                 "maximum_member_bytes":max(i.file_size for i in infos)}

# PNG signature, every chunk CRC, IHDR dimensions and zlib data validate without
# manufacturing or rewriting pixels. Actual visual inspection was performed separately.
png = (p.OUT / "results.png").read_bytes()
check("PNG signature", png[:8] == b"\x89PNG\r\n\x1a\n")
offset, compressed, width, height = 8, bytearray(), None, None
while offset < len(png):
    length = struct.unpack(">I", png[offset:offset+4])[0]
    kind = png[offset+4:offset+8]
    data = png[offset+8:offset+8+length]
    expected = struct.unpack(">I", png[offset+8+length:offset+12+length])[0]
    check("PNG chunk CRC " + kind.decode(), zlib.crc32(kind+data) & 0xffffffff == expected)
    if kind == b"IHDR":
        width, height = struct.unpack(">II", data[:8])
    if kind == b"IDAT":
        compressed.extend(data)
    offset += length + 12
check("PNG complete and dimensions bounded", offset == len(png) and width == 1440 and 1100 <= height <= 2400)
check("PNG pixel stream decompresses", len(zlib.decompress(compressed)) > 0)
capture = manifest["browser_capture"]
check("PNG and HTML match actual successful browser capture",
      p.sha(png) == capture["screenshot_sha256"]
      and p.sha((p.OUT/"results.html").read_bytes()) == capture["source_html_sha256"]
      and len(capture["headings"]) == 6 and capture["image_edits"] == "none")

def preserved():
    check("HEAD unchanged", p.git("rev-parse","HEAD").decode().strip() == before["head"])
    check("MERGE_HEAD unchanged", p.git("rev-parse","MERGE_HEAD").decode().strip() == before["merge_head"])
    baseline = p.load(p.V/"source-before.json")
    check("Real index bytes unchanged", p.sha(p.Path(baseline["index_path"]).read_bytes()) == before["index_sha256"])
    for name, item in baseline["git_control_files"].items():
        path = p.Path(item["path"])
        check("Git control unchanged: " + name, (p.sha(path.read_bytes()) if path.is_file() else None) == before["controls"][name])
    for ref, oid in before["selected_refs"].items():
        check("Selected ref unchanged: " + ref, p.git("rev-parse",ref).decode().strip() == oid)
    parent = p.R + "/README.md"
    delta = []
    for name, digest in before["tracked_files"].items():
        if p.sha((p.W/name).read_bytes()) != digest:
            delta.append(name)
    check("Only original tracked input changed is allowed parent README", delta == [parent])
    old = (p.P/"parent-readme.before").read_bytes()
    new = (p.W/parent).read_bytes()
    check("Parent README is byte-exact prefix plus one additive link",
          new.startswith(old) and len(new[len(old):].splitlines()) == 4
          and new[len(old):].count(b"[current-validation/README.md]") == 1)
    expected = {"README.md","manifest.json","receipts.zip","results.html","results.png","packaging-checks.json"}
    check("Only six allowed new public files", {q.name for q in p.OUT.iterdir()} <= expected)
    other_new = set(p.git("ls-files","--others","--exclude-standard","-z").decode().split("\0")[:-1]) - set(before["untracked"])
    check("No new untracked files outside exact packet scope",
          other_new <= {p.R+"/current-validation/"+n for n in expected})
    check("Unstaged tracked diff is only parent README",
          p.git("diff","--name-only","-z").decode().split("\0")[:-1] == [parent])

preserved()
commands = []
node = p.Path("C:/LOCAL/actor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe")
for args in [
    [str(node),"tools/check_evidence_personal_paths.mjs"],
    [str(node),"tools/check_evidence_personal_paths.mjs",p.R+"/current-validation"],
    ["git","diff","--check"],
]:
    result = subprocess.run(args,cwd=p.W,capture_output=True,env={**os.environ,"GIT_OPTIONAL_LOCKS":"0"},creationflags=subprocess.CREATE_NO_WINDOW)
    check("Packaging-only command: " + " ".join(args[1:]), result.returncode == 0)
    normalized, _ = p.normalize(json.dumps({"argv":args,"exit_code":result.returncode,
        "stdout":result.stdout.decode(),"stderr":result.stderr.decode()}).encode())
    commands.append(json.loads(normalized))
check("Every new public text line has no trailing whitespace",
      all(line == line.rstrip(b" \t") for f in p.OUT.iterdir() if f.suffix in {".md",".html",".json"}
          for line in f.read_bytes().splitlines()))

check_receipt = {
    "status":"PASS","scope":"Focused packaging/provenance validation plus separately retained new retrospective existing-regression pair; no implementation or heavy builds",
    "checks_passed_before_receipt":len(checks), "zip":zip_stats,
    "checks":["CRC/safe relative regular text inventory/bounds","every original and public member SHA256",
              "independent exact path-span replay; all non-path bytes identical","decompressed normalized-path scan",
              "raw R8 artifact inventory and all claimed terminal counts/author assertions",
              "unchanged 1147 prior tracked files and real index/HEAD/MERGE_HEAD/controls/selected refs",
              "parent README exact prefix plus additive link","PNG chunk CRC/decompression and capture hashes"],
    "commands":commands,
    "visual_inspection":{"performed":True,"tool":"view_image","png_sha256":p.sha(png),
        "width":width,"height":height,"result":"All six lanes including clearly separate NEW retrospective pair, exact source IDs, 343 ignored, static/non-application label, retained Rust/global failures and authority limits visible without clipping. No pixel edits."},
    "retrospective_pair":{"old_exit":1,"current_exit":0,"selected_each":1,"name_filtered_each":5,"node_reported_skipped_each":0,"original_chronology_recovered":False},
    "driver":{"archive_member":"round8-packaging/verify_pair.py","original_sha256":p.sha(p.Path(__file__).read_bytes())},
    "limits":"Text scan is not exhaustive OCR/privacy proof. Global-ref preservation remains false; no independent approval or fresh nine-gate execution."
}
p.save(p.OUT/"packaging-checks.json",check_receipt)
manifest["public_files"] = {f.name:{"sha256":p.sha(f.read_bytes()),"bytes":f.stat().st_size}
                          for f in sorted(p.OUT.iterdir()) if f.name != "manifest.json"}
p.save(p.OUT/"manifest.json",manifest)
for name, record in manifest["public_files"].items():
    check("Final public file hash " + name, p.sha((p.OUT/name).read_bytes()) == record["sha256"])
check("Six final files exactly", len(list(p.OUT.iterdir())) == 6)
for f in p.OUT.iterdir():
    check("Final public scanner " + f.name, not p.PERSONAL.search(f.read_bytes()))
preserved()

# Compute hypothetical Git trees in memory from native index entries, without
# staging or writing objects/refs. Baseline must match the supplied tested tree.
entries = {}
for entry in p.git("ls-files","--stage","-z").split(b"\0")[:-1]:
    meta, name = entry.split(b"\t",1)
    mode, oid, stage = meta.split()
    assert stage == b"0"
    entries[name] = (mode, bytes.fromhex(oid.decode()))
def oid(kind, data):
    return hashlib.sha1(kind+b" "+str(len(data)).encode()+b"\0"+data).digest()
def tree(entries):
    root = {}
    for path, value in entries.items():
        current = root
        parts = path.split(b"/")
        for name in parts[:-1]:
            current = current.setdefault(name,{})
        current[parts[-1]] = value
    def digest(directory):
        data = bytearray()
        for name,value in sorted(directory.items(),key=lambda item:item[0]+(b"/" if isinstance(item[1],dict) else b"")):
            mode, object_id = (b"40000",digest(value)) if isinstance(value,dict) else value
            data.extend(mode+b" "+name+b"\0"+object_id)
        return oid(b"tree",data)
    return digest(root).hex()
check("Native index reconstructs exact tested tree", tree(entries) == before["tested_tree"])
changed = [p.R+"/README.md", *[p.R+"/current-validation/"+f.name for f in sorted(p.OUT.iterdir())]]
output = dict(entries)
for name in changed:
    output[name.encode()] = (b"100644",oid(b"blob",(p.W/name).read_bytes()))
excluded = set(manifest["equivalence_exclusions"])
check("Exact exclusions equal output changes", excluded == set(changed))
check("Every Git input outside exclusions identical",
      {k:v for k,v in entries.items() if k.decode() not in excluded} ==
      {k:v for k,v in output.items() if k.decode() not in excluded})
final = {"status":"PASS","checks":len(checks),"input_tree":before["tested_tree"],
         "hypothetical_evidence_only_output_tree":tree(output),
         "tree_note":"Computed in memory; not staged or committed and not tested by the historical nine. All other index objects are identical.",
         "input_equivalence_exclusions":sorted(excluded),"changed_paths":changed,
         "public_files":{name:{"sha256":p.sha((p.W/name).read_bytes()),"bytes":(p.W/name).stat().st_size} for name in changed},
         "zip":zip_stats,"image_inspected":True,"index_unchanged":True,"merge_head_unchanged":True,
         "whole_repository_ref_preservation_claimed":False,
         "retrospective_pair":check_receipt["retrospective_pair"],
         "first_packaging_preserved_manifest_sha256":p.sha((p.P/"first-packaging-preserved.json").read_bytes()),
         "parent_next":"Independent scoped reviews and normal remote-fenced publication; no approval here.",
         "completed_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
p.save(p.P/"final-handoff.json",final)
p.save(p.P/"verification-checks.private.json",checks)
print(json.dumps(final,indent=2))
