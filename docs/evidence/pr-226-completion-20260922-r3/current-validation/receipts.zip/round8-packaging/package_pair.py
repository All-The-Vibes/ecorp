"""One-off evidence packaging only; never execute archived validation drivers."""
from pathlib import Path, PurePosixPath
import hashlib
import html
import json
import os
import re
import subprocess
import sys
import zipfile

S = Path(__file__).resolve().parent.parent
P = Path(__file__).resolve().parent
W = Path("C:/LOCAL/actor/repos/ecorp/worktrees/pr226-r7-public-evidence")
R = "docs/evidence/pr-226-completion-20260922-r3"
OUT = W / R / "current-validation"
V = S / "round8-integration/validation"
R7 = S / "round7-public-evidence"
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(Path(path).read_bytes())
def save(path, value):
    Path(path).write_bytes((json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode())
def git(*args):
    return subprocess.check_output(["git", *args], cwd=W, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"})

# Replace only this machine's local personal-root path prefix; keep separator
# encoding, every suffix, and all other bytes (including old digests) untouched.
ROOT_PATH = re.compile(rb'(?i)(?:[a-z]:)?([/\\]+)Users([/\\]+)(sschofield|SSCHOF~1|shyamsridhar|SHYAMS~1)(?![a-z0-9])')
PERSONAL = re.compile(rb'(?i)(?:[a-z]:)?[/\\]+Users[/\\]+[^/\\\s"\'<>]+')
def normalize(data):
    changes = []
    def replace(m):
        old = m.group()
        prefix = old[:2] if len(old) > 1 and old[1:2] == b":" else b""
        actor = b"actor" if m[3].lower() in (b"sschofield", b"sschof~1") else b"prior-source-actor"
        new = prefix + m[1] + b"LOCAL" + m[2] + actor
        changes.append({"original_span_sha256": sha(old), "original_span_bytes": len(old),
                        "public_span": new.decode()})
        return new
    public = ROOT_PATH.sub(replace, data)
    # Independent splice reconstruction: all bytes outside actual local path spans
    # are copied verbatim. No whitespace, outcomes, counts, identifiers or hashes edited.
    cursor, pieces = 0, []
    for m, change in zip(ROOT_PATH.finditer(data), changes):
        pieces.extend([data[cursor:m.start()], change["public_span"].encode()])
        cursor = m.end()
    pieces.append(data[cursor:])
    assert b"".join(pieces) == public
    assert not PERSONAL.search(public), "Undeclared personal path remains"
    counts = {}
    for change in changes:
        key = json.dumps(change, sort_keys=True)
        counts[key] = counts.get(key, 0) + 1
    return public, [{**json.loads(k), "occurrences": n} for k, n in sorted(counts.items())]

def selection():
    files = {}
    def add(path):
        path = Path(path)
        assert path.is_file() and not path.is_symlink(), path
        files[path.relative_to(S).as_posix()] = path
    # Exact executed commands, complete streams and referenced source snapshots.
    for directory, numbers in [(V, range(20)), (R7 / "validation", [*range(11), 20, 21, 22])]:
        for number in numbers:
            for receipt in sorted(directory.glob(f"{number:02}-*.json")):
                if receipt.name.endswith((".before.json", ".after.json")):
                    continue
                record = load(receipt)
                add(receipt)
                for item in record.get("logs", {}).values():
                    raw = directory / item.get("file", item.get("path"))
                    assert sha(raw.read_bytes()) == item["sha256"], raw
                    assert len(raw.read_bytes()) == item["bytes"]
                    add(raw)
                for key in ("source_before", "source_after"):
                    if isinstance(record.get(key), str):
                        add(directory / record[key])
                for trace in directory.glob(receipt.stem + ".git-trace.jsonl"):
                    add(trace)
    for name in [
        "verification-report.md", "verification-report.json", "author-self-review.md",
        "artifact-manifest.json", "source-before.json", "source-after.json", "environment.json",
        "validate-r8.py", "native-mcp-binding.json", "author-checks-r8.py",
        "run-author-checks-r8.py", "author-checks-result-r8.json", "new-main-receipt-tests.json",
        "complete-log-audit.json", "main-integration-inventory.json",
        "20-terminal-audit-reconciled-preflight-failure.json", "external-ref-observation-2.json",
        "audit-r8.py", "audit-r8-reconciled.py", "run-terminal-audit.py",
        "run-terminal-audit-reconciled.py", "final-readback.py", "final-readback.json",
        "final-readback-command.json", "final-readback-binding.json",
        "final-readback.before.json", "final-readback.after.json",
        "final-readback.stdout.log", "final-readback.stderr.log",
        "post-report-source-preservation.json",
    ]:
        add(V / name)
    add(V.parent / "identity.json")
    for name in [
        "identity.json", "scanner-coverage-red.log", "scanner-covered-leak-red.log",
        "scanner-green.log", "focused-checks.json", "focused.stdout.log", "focused.stderr.log",
        "run-focused-checks.py", "handoff.md", "combined-validation-qualified.json",
        "validation-source.json", "provenance-and-preservation.json",
        "validation/environment.json", "validation/source-before.json",
        "validation/validate.py", "validation/run-rust-diagnostics.py",
        "validation/rust-rerun-preconditions.json", "validation/rust-diagnostics.md",
        "validation/verification-report-final.md", "validation/verification-report-final.json",
        "validation/author-checks-v3.py", "validation/run-author-checks-v3.py",
    ]:
        add(R7 / name)
    # Explicit, small probe directory allowlist; never recurse into build outputs.
    for name in ["before.json", "result.json", "root.json", "stdout.log", "stderr.log",
                 "git.trace.log", "probe.py", "rerun-rust.py",
                 "full-rust/before.json", "full-rust/after.json", "full-rust/result.json",
                 "full-rust/process.json", "full-rust/stdout.log", "full-rust/stderr.log"]:
        add(R7 / "short-temp-probe" / name)
    add(P / "capture-saved-report-edge.cjs")
    add(P / "browser-capture.json")
    add(P / "verify.py")
    add(P / "package.py")
    add(P / "capture-blocked-file-attempt.cjs")
    add(P / "capture-blocked-file-attempt.json")
    for name in ["run_pair.py","package_pair.py","verify_pair.py","capture-pair.cjs",
                 "browser-capture-pair.json","first-packaging-preserved.json",
                 "retrospective-pair/old.before.json","retrospective-pair/current.before.json",
                 "retrospective-pair/old.result.json","retrospective-pair/current.result.json",
                 "retrospective-pair/old.stdout.log","retrospective-pair/old.stderr.log",
                 "retrospective-pair/current.stdout.log","retrospective-pair/current.stderr.log",
                 "retrospective-pair/pair-preexecution.json","retrospective-pair/pair-result.json",
                 "retrospective-pair/source-before.json","retrospective-pair/source-after.json"]:
        add(P / name)
    return files

def raw_checks():
    report = load(V / "verification-report.json")
    baseline = load(V / "source-before.json")
    artifact = load(V / "artifact-manifest.json")
    for name, entry in artifact["files"].items():
        raw = (V / name).read_bytes()
        assert sha(raw) == entry["sha256"] and len(raw) == entry["bytes"], name
    results = load(V / "results.json")
    assert len([r for r in results if r["required"] and r["passed"] and r["exit_code"] == 0]) == 9
    for r in results:
        assert load(V / r["source_before"]) == load(V / r["source_after"]) == baseline
    assert load(V / "10-focused.json")["node_summary"] == {
        "tests":16, "suites":0, "pass":16, "fail":0, "cancelled":0, "skipped":0, "todo":0}
    author = load(V / "author-checks-result-r8.json")
    assert author["checks"] == 387 and len(author["results"]) == 387
    assert all(r["passed"] for r in author["results"])
    assert author["contribution_files"] == 276 and author["contribution_bytes"] == 5943365
    assert load(V / "19-terminal-audit.json")["exit_code"] == 1
    assert load(V / "20-terminal-audit-reconciled-preflight-failure.json")["exit_code"] == 1
    assert load(V / "final-readback.json")["whole_repository_refs_unchanged"] is False
    assert load(R7 / "validation/07-cargo-test.json")["exit_code"] == 101
    for name, expected in [
        (V / "07-cargo-test.stdout.log", (571, 0, 343, 0, 0)),
        (R7 / "validation/07-cargo-test.stdout.log", (366, 9, 1, 0, 0)),
        (R7 / "short-temp-probe/full-rust/stdout.log", (566, 0, 343, 0, 0)),
    ]:
        rows = re.findall(rb"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", name.read_bytes())
        assert tuple(map(sum, zip(*(map(int, row) for row in rows)))) == expected
    for name, expected in [("scanner-coverage-red.log", (1, 0, 1)), ("scanner-covered-leak-red.log", (1, 0, 1)), ("scanner-green.log", (6, 6, 0))]:
        data = (R7 / name).read_bytes()
        assert tuple(int(re.search(rb"^# " + key + rb" (\d+)\r?$", data, re.M)[1]) for key in [b"tests", b"pass", b"fail"]) == expected
    for directory in [R7 / "short-temp-probe", R7 / "short-temp-probe/full-rust"]:
        receipt = load(directory / "result.json")
        assert receipt.get("exit_code", receipt.get("exit")) == 0
        for stream in ("stdout", "stderr"):
            assert sha((directory / (stream + ".log")).read_bytes()) == receipt[stream + "_sha256"]
    assert sha((V / "validate-r8.py").read_bytes()) == load(V / "environment.json")["driver_sha256"]
    assert report["pending_tree"] == baseline["staged_tree"]
    return report, len(artifact["files"])

def prepare():
    report, count = raw_checks()
    OUT.mkdir(exist_ok=False)
    readme = """# PR226 current validation: public evidence derivatives

September 22, 2026. **Packaging only; no tests or builds rerun here.**
Read [the saved-results report](results.html), its [genuine Edge screenshot](results.png),
and [manifest.json](manifest.json). Complete selected logs, receipts and executed-driver
derivatives are in [receipts.zip](receipts.zip). Nothing in the ZIP is to be executed
as part of reading this packet.

## Exact input and separate lanes

- R8 HEAD: `91a5b4e58a13eb0128f3f69beedcb9bd174fbb23`.
- R8 tested pending tree: `2cf0ea4851f09cbdb7cf3f08a6c3422abda416a8`.
- Pending MERGE_HEAD/main: `08b0b89b2dd16c1906c9dd3468c5ddecca24c4ce`.
- R7 correction chronology: actual missing-default-root RED (0/1), covered-leak
  RED (0/1), then six-case scanner GREEN (6/0); the existing R7 handoff records
  that order and exit 1/1/0. Logs lack independent per-RED source snapshots or
  timestamps: none are invented. The 16-case focused GREEN is separately retained.
- R7 original contributor pass remains **8/9**. Rust exit **101**, 366 passed,
  9 failed, 1 ignored in reached suites; later suites were not reached.
  The initial selected diagnostics retain exits 101/101/0; a later unchanged-binary
  short owned-TEMP probe passed 1 case. Only then did a real unfiltered full Rust
  rerun pass **566 / 0 / 343 ignored**, exit 0. These bind R7 HEAD
  `9d79db02c814497f93eed4b8d7c842cb2518d153`, candidate tree
  `c71eec9d7617d5879c596f646615167a6633a566`, target
  `de12261d045ddfccf790bcfd04a7fa254563d456`, not R8.
- R8 actually executed all **nine** required commands on the new-main merged
  source: Node **1,259**, Steward **227**, Rust **571 / 0 / 343 ignored**;
  focused **16/16**, zero skips. The native MCP build/binary is bound; 43 native
  cases executed within the Node total, not additional tests. Five new-main
  receipt tests appear in the full Rust log.
- AUTHOR-DELEGATE self-review actually completed: **387 assertions** over
  **276 contribution files / 5,943,365 bytes**. This is not independent approval.

## Preserved failures and authority

The R8 global shared-ref audit and its attempted reconciliation remain failed.
Concurrent unrelated PR362 branch creation and Codex metadata-ref changes made
whole-repository preservation false. The separate 197-check final readback
preserved the exact PR226 source/index/merge state and selected local refs.
This is neither a product-test failure nor a claim of full global preservation.
Local tracking refs are not a fresh remote publication fence.

All 343 Rust ignored cases remain unexecuted (342 database cases and one
stopped-session probe). Issue #225 remains nonclosing: no live application,
browser/server/runner, provider, database, Factory/native acceptance, hosted CI,
Santa/NICE/SAFE, human or independent approval is supplied.

## Derivatives and provenance

Every selected original is read-only and its original SHA-256/byte count is
mapped to its public SHA-256/byte count in the manifest. Only local personal-root
path prefixes are replaced by `LOCAL/actor` with their original separator
encoding. All suffixes and non-path bytes are exact; no newline/whitespace
normalization was needed. Existing hashes, source IDs, exits, counts and failure
text outside those path spans are unchanged. Thus old hashes inside normalized
receipts still describe **original private bytes**, not public derivatives.
Executed-script derivatives are archival text, not newly executed drivers.

The ZIP uses an explicit selection, not a scratch-directory copy. It excludes
raw patches, baseline binaries, Cargo caches, dependencies, old/private images
and unrelated worktrees. Byte-identical source snapshots are deduplicated:
`snapshot_aliases` maps each original referenced filename to its canonical ZIP
member, retaining original hashes. The archived original artifact manifest
describes a larger private collection; it is not the ZIP inventory.

`results.png` is one unedited Microsoft Edge capture of local static `results.html`
with browser-context requests blocked; no live application or tests are pictured.
The installed Playwright capture script was reused, not a new capture framework.
The manifest binds the actual HTML, PNG, browser version, driver and capture time.
The older correction screenshot and redacted failed capture remain untouched.

## Evidence-only descendant and handoff

Before packaging, all 1,148 tracked working inputs, index bytes, HEAD, MERGE_HEAD,
merge/config controls and selected refs matched the R8 frozen state.
After packaging the only exclusions from input-equivalence comparison are this
six-file `current-validation/` directory and the parent r3 README, whose entire
original bytes are retained as a prefix with one additive link. The other
1,147 tracked files, historical receipts/images, real index and merge controls
must remain exact. The output is an evidence-only descendant of the tested tree,
not a newly tested tree/commit; no not-yet-existing SHA is credited with execution.
The final hypothetical Git output-tree ID is in the private handoff because
embedding that ID inside its own tree would be self-referential.

The parent owns final independent scoped reviews, live remote re-fencing and
normal publication. This packet confers no approval. No staging, commit, push,
source/test changes, test runs, heavy builds or shared-stack changes were made.
"""
    (OUT / "README.md").write_bytes(readme.encode())
    original = (P / "parent-readme.before").read_bytes()
    assert (W / R / "README.md").read_bytes() == original
    (W / R / "README.md").write_bytes(original + b"\n## Current-main validation evidence\n\nSee [current-validation/README.md](current-validation/README.md) for the separately source-bound R8 nine-gate results, retained R7 failures/rerun, author-delegate receipt and static browser capture. Historical receipts above remain unchanged.\n")
    rows = []
    descriptions = ["41 immutable migrations", "5 validation / 2 runtime documents; 9 marked commands",
                    "1,259 passed; 0 failed / skipped", "227 passed; 0 failed / skipped",
                    "format check passed", "all targets; warnings denied",
                    "571 passed; 0 failed; 343 ignored; 0 filtered",
                    "TypeScript + Vite; 57 modules", "58 files; 0 warnings / errors"]
    for r, description in zip(report["nine_gates"], descriptions):
        rows.append(f"<tr><td><code>{html.escape(r['label'])}</code></td><td>{r['exit_code']}</td><td>{description}</td></tr>")
    page = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src 'none'">
<title>PR226 — saved R7/R8 evidence</title><style>
body{font:16px/1.4 system-ui,sans-serif;margin:24px;color:#162b3d;background:#fff}
h1{font-size:28px;margin:4px 0}h2{font-size:19px;margin:0 0 8px}p{margin:7px 0}
code{font:13px/1.4 Consolas,monospace;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:14px}
th,td{border-bottom:1px solid #ccd6df;text-align:left;padding:6px}th{background:#edf2f7}
.cards{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
section{border:1px solid #879aaa;border-radius:5px;padding:14px}.wide{grid-column:1/-1}
.red{color:#a32424}.green{color:#136438}.label{font-weight:700;color:#345a77}
.note{background:#fff3db;padding:12px;border-left:5px solid #91630c}footer{margin-top:12px;font-size:14px}
</style></head><body>
<p class="label">SAVED RESULTS · September 22, 2026 · NOT live tests or an application screenshot</p>
<h1>PR #226 — correction, current-main validation &amp; provenance</h1>
<p>R8 HEAD <code>91a5b4e58a13eb0128f3f69beedcb9bd174fbb23</code><br>
Tested staged tree <code>2cf0ea4851f09cbdb7cf3f08a6c3422abda416a8</code><br>
Pending main <code>08b0b89b2dd16c1906c9dd3468c5ddecca24c4ce</code></p>
<div class="cards">
<section><h2 class="red">1 · Actual ordered R7 coverage RED → GREEN</h2>
<p>Missing r3 default: <b>0 passed / 1 failed · exit 1</b><br>
Default added, actual retained leak: <b>0 / 1 · exit 1</b><br>
Public path correction: <b class="green">6 passed / 0 failed · exit 0</b></p>
<p>Raw TAP logs + contemporaneous R7 handoff retained. No per-RED source SHA or timestamp invented.</p>
<p><code>scanner-coverage-red.log → scanner-covered-leak-red.log → scanner-green.log</code></p></section>
<section><h2 class="green">2 · Focused GREEN — distinct lane</h2>
<p><b>16 passed / 0 failed / 0 skipped</b>, exit 0.<br>
Canary status, exact Git bytes and recursive personal-path scanner.</p>
<p>R7 focused receipt retained; R8 <code>10-focused</code> ran again on the exact tested tree above. Packaging does not rerun it.</p></section>
<section class="wide"><h2 class="green">3 · R8 fresh nine — actual new-main source</h2>
<table><thead><tr><th>Executed required command</th><th>Exit</th><th>Complete result summary</th></tr></thead><tbody>
""" + "\n".join(rows) + """</tbody></table>
<p>Native MCP build passed; exact binary hash bound before Node. <b>43 native cases</b> are included in 1,259.
All five new-main upload-binding cases passed inside the full Rust run.</p></section>
<section><h2>4 · R7 Rust failure and real full rerun</h2>
<p class="red"><b>Original 8/9: Rust exit 101</b><br>366 passed / 9 failed / 1 ignored in reached suites.</p>
<p>Selected diagnostics retained: exits <b>101 / 101 / 0</b>.<br>
Later short owned-TEMP diagnostic: <b>1 passed</b>, exit 0.<br>
Then unfiltered full rerun: <b class="green">566 / 0 / 343 ignored</b>, exit 0.</p>
<p>R7 tree <code>c71eec9d7617d5879c596f646615167a6633a566</code><br>
HEAD <code>9d79db02c814497f93eed4b8d7c842cb2518d153</code><br>
Target <code>de12261d045ddfccf790bcfd04a7fa254563d456</code><br>
Not R8 proof. Original failed Rust stays failed.</p></section>
<section><h2 class="green">5 · Author review / source &amp; tool provenance</h2>
<p><b>AUTHOR-DELEGATE: 387 passed assertions</b><br>
276 contribution files / 5,943,365 bytes actually reviewed.</p>
<p>R8 driver, source/index/merge snapshots, tools, native MCP, complete raw streams and original/public hashes retained.
Separate final readback: <b>197 bounded checks</b>.</p>
<p><b>Not independent, human, Santa/NICE or SAFE approval.</b><br>
Evidence-only packaging descendant; no new nine-gate claim.</p></section>
</div>
<p class="note"><b>Preserved global-ref audit FAIL; overall preservation PARTIAL.</b> Unrelated PR362 branch and Codex metadata refs changed.
Exact PR226 source/index/merge and selected local refs were preserved. This is not a product-test failure or full-global-preservation claim.</p>
<footer><b>343 ignored Rust cases remain unexecuted:</b> 342 database cases + one stopped-session probe.
Issue #225 remains nonclosing; no live application, provider, DB or Factory/native acceptance.<br>
Read <a href="README.md">scope</a>, <a href="manifest.json">original/public manifest</a> and <a href="receipts.zip">selected receipts ZIP</a>.
Public path-only derivatives; original private artifacts untouched. Parent retains independent review, remote fence and publication.</footer>
</body></html>
"""
    (OUT / "results.html").write_bytes(page.encode())
    # Reuse the already executed, installed-Edge capture script; adapt only report
    # filenames, section count, routing and output location. No new capture harness.
    old = (R7 / "capture-saved-report-edge.cjs").read_text()
    script = old.replace("docs/evidence/pr-226-completion-20260922-r3", R + "/current-validation")
    script = script.replace("saved-correction-results", "results")
    script = script.replace("headings.length !== 4", "headings.length !== 5").replace("Expected four", "Expected five")
    script = script.replace("await page.route(/^https?:/, route => route.abort());",
                            "await page.context().route('**/*', route => route.abort());")
    script = script.replace("round7-public-evidence/saved-report-browser-capture.json", "round8-packaging/browser-capture.json")
    script = script.replace("HTTP(S) requests blocked; local static file only", "All browser-context requests blocked; local static file only")
    (P / "capture-saved-report-edge.cjs").write_bytes(script.encode())
    save(P / "raw-preflight.json", {"status":"passed", "r8_private_manifest_files_verified":count,
                                   "checks":"raw hashes, source bindings, terminal counts, failed receipts, author assertions"})
    print("Prepared report; next execute reused Edge capture, then archive.")

def archive():
    report, count = raw_checks()
    capture = load(P / "browser-capture-pair.json")
    assert sha((OUT / "results.html").read_bytes()) == capture["source_html_sha256"]
    assert sha((OUT / "results.png").read_bytes()) == capture["screenshot_sha256"]
    records, aliases, hashes = [], {}, {}
    files = selection()
    with zipfile.ZipFile(OUT / "receipts.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for member, path in sorted(files.items()):
            raw = path.read_bytes()
            public, changes = normalize(raw)
            raw.decode("utf-8")  # Archive contains text only, never a binary or patch.
            if path.suffix == ".json":
                json.loads(public)
            is_snapshot = member.endswith((".before.json", ".after.json", "/source-before.json", "/source-after.json"))
            canonical = hashes.get(sha(raw)) if is_snapshot else None
            if canonical is not None:
                aliases[member] = {"member": canonical, "original_sha256": sha(raw), "public_sha256": sha(public)}
                continue
            if is_snapshot:
                hashes[sha(raw)] = member
            info = zipfile.ZipInfo(member, date_time=(2026, 9, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, public)
            records.append({"member":member, "original_locator":member,
                            "original_sha256":sha(raw), "original_bytes":len(raw),
                            "public_sha256":sha(public), "public_bytes":len(public),
                            "kind":"path-only derivative" if changes else "byte-identical original copy",
                            "path_substitutions":changes, "non_path_bytes_exact":True})
    before = load(P / "before.json")
    manifest = {
        "schema":1, "scope":"PR226 evidence packaging plus explicitly new retrospective single-regression pair; no new nine-gate run, approval or issue225 closure",
        "input":{"head":before["head"],"tested_tree":before["tested_tree"],"merge_head":before["merge_head"],
                 "index_sha256":before["index_sha256"],"tracked_count":len(before["tracked_files"]),
                 "source_snapshot_original_sha256":before["baseline_sha256"]},
        "normalization":"Only actual local personal-root prefixes; original separator encoding and all other bytes exact. No whitespace changes. Internal old hashes and IDs remain original identities, not public hashes.",
        "archive_selection":"Explicit executed receipts/logs/source snapshots/tool bindings/drivers; no patches, binaries, dependency trees, private originals, old images or unrelated worktrees.",
        "archive_members":records, "snapshot_aliases":aliases,
        "source_manifest_scope":"Archived original artifact-manifest.json is a derivative of the larger private inventory, not the ZIP inventory.",
        "browser_capture":capture,
        "capture_driver":{"member":"round8-packaging/capture-pair.cjs",
                          "original_sha256":sha((P / "capture-pair.cjs").read_bytes()),
                          "reused_from_original_sha256":sha((P / "capture-saved-report-edge.cjs").read_bytes())},
        "first_packet_preservation":load(P / "first-packaging-preserved.json"),
        "retrospective_pair":{"member":"round8-packaging/retrospective-pair/pair-result.json",
             "original_sha256":sha((P / "retrospective-pair/pair-result.json").read_bytes()),
             "kind":"NEW retrospective effectiveness pair; unchanged current regression introduced after baseline, not original R7 chronology",
             "old_helper_blob":"48c8a593e23ca122e16f2ada5db0e73d4d036d5f",
             "current_helper_index_blob":"9b77198637139fff907cc0a20d245c4a071487e1",
             "shared_regression_index_blob":"61839dfbfc30adc8adabbafeee73c021264553c6",
             "old_exit":1,"current_exit":0,"selected_each":1,"name_filtered_each":5,"node_reported_skipped_each":0},
        "equivalence_exclusions":[R + "/README.md", *[R + "/current-validation/" + n for n in
            ["README.md","manifest.json","receipts.zip","results.html","results.png","packaging-checks.json"]]],
        "original_parent_readme_sha256":sha((P / "parent-readme.before").read_bytes()),
        "authority":"AUTHOR-DELEGATE only; parent independent scoped reviews, fresh remote fence and publication pending",
        "whole_repository_refs_unchanged":False,
        "global_ref_caveat":"Original exit-1 audit and reconciliation stay failed: concurrent unrelated PR362 branch and Codex metadata changes. Not a product-test failure.",
        "hash_scope":"public_files binds every sibling public file; manifest self-hash is external in private final handoff to avoid self-reference.",
    }
    save(OUT / "manifest.json", manifest)
    print("Archive members",len(records),"deduplicated snapshots",len(aliases),"ZIP bytes",(OUT/"receipts.zip").stat().st_size)

if __name__ == "__main__":
    {"prepare":prepare, "archive":archive}[sys.argv[1]]()
