const { chromium } = require('C:/LOCAL/actor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const { readFileSync, writeFileSync } = require('node:fs');
const { createHash } = require('node:crypto');
const { resolve } = require('node:path');
const { pathToFileURL } = require('node:url');
(async () => {
  const dir = resolve('docs/evidence/pr-226-completion-20260922-r3/current-validation');
  const browser = await chromium.launch({ channel: 'msedge', headless: true, chromiumSandbox: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1100 }, deviceScaleFactor: 1 });
    await page.context().route('**/*', route => route.request().url() === pathToFileURL(`${dir}/results.html`).href ? route.continue() : route.abort());
    await page.goto(pathToFileURL(`${dir}/results.html`).href);
    await page.evaluate(() => document.fonts.ready);
    const headings = await page.locator('section h2').allTextContents();
    if (headings.length !== 6) throw Error('Expected six saved-result sections');
    const image = `${dir}/results.png`;
    await page.screenshot({ path: image, fullPage: true });
    const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex');
    const record = { kind: 'genuine browser screenshot of static saved-results report; not live tests', captured_at_utc: new Date().toISOString(), browser: `Microsoft Edge ${browser.version()}`, playwright: require('C:/LOCAL/actor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json').version, viewport: { width: 1440, height: 1100 }, device_scale_factor: 1, full_page: true, source_html: 'results.html', source_html_sha256: hash(`${dir}/results.html`), screenshot: 'results.png', screenshot_sha256: hash(image), headings, network: 'Exact local report file URL allowed; every other browser-context request aborted', image_edits: 'none' };
    writeFileSync('C:/LOCAL/actor/repos/ecorp/output/pr-gauntlet-20260922/pr226/round8-packaging/browser-capture-pair.json', JSON.stringify(record, null, 2)+'\n');
    console.log(JSON.stringify(record, null, 2));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode=1; });
