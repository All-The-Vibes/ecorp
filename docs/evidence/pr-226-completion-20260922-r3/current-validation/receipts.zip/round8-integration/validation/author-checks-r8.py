# Private execution of reviewed existing provenance assertions, followed by full contribution checks.
import os,json
from pathlib import Path
v=Path(__file__).resolve().parent
environment=json.loads((v/'environment.json').read_bytes())
os.environ.clear(); os.environ.update(environment['environment'])
os.chdir(environment['cwd'])
from pathlib import Path
from PIL import Image,ImageChops,ImageDraw
import hashlib,json,subprocess,os,re
os.environ['GIT_OPTIONAL_LOCKS']='0'
s=Path(r'C:/LOCAL/actor/repos/ecorp/output/pr-gauntlet-20260922/pr226/round7-public-evidence'); base=json.loads((s/'source-before.json').read_bytes()); head=base['head']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
def blob(ref):return git('cat-file','blob',ref)
checks=[]
def verify(label,actual,expected):
 assert actual==expected,(label,actual,expected)
 checks.append({'check':label,'passed':True})
r3=Path('docs/evidence/pr-226-completion-20260922-r3'); r2=Path('docs/evidence/pr-226-completion-20260922-r2'); it=Path('docs/evidence/pr226-integration-20260921')
c=json.loads((r3/'correction-provenance.json').read_bytes()); old=json.loads(blob(head+':'+(r3/'correction-provenance.json').as_posix()))
for i,a in enumerate(c['artifacts']):
 verify(a['path']+' current public digest',sha((r3/a['path']).read_bytes()),a['published_sha256'])
 verify(a['path']+' original identity retained',a['original_sha256'],old['artifacts'][i]['original_sha256'])
 if i:verify(a['path']+' entire historical entry retained',a,old['artifacts'][i])
a=c['artifacts'][0]['previous_publications'][0]
verify('root-before prior Git digest',sha(blob(a['git'])),a['published_sha256'])
verify('root-before private copy digest',sha((s/'private-originals/root-before.log').read_bytes()),a['published_sha256'])
b=blob(a['git']); expected=b.replace(b'C:\\\\LOCAL\\\\prior-source-actor',b'C:\\\\Users\\\\<original-user>').replace(b'C:\\LOCAL\\prior-source-actor',b'C:\\Users\\<original-user>')
verify('root-before only two user-root substitutions',(r3/'root-before.log').read_bytes(),expected)
a=c['dated_report_public_normalization']; before=blob(a['previous_publication_git']); verify('dated report previous raw Git digest',sha(before),a['previous_published_sha256'])
fixed=before.replace(b'C:\\LOCAL\\prior-source-actor',b'C:\\Users\\<original-user>'); verify('dated report current Git digest',sha(fixed),a['published_sha256']); verify('dated report only three spans plus ordinary CRLF checkout',(r3/a['path']).read_bytes(),fixed.replace(b'\n',b'\r\n'))
a=c['saved_results_capture']
for field,digest in [('source_html','source_html_sha256'),('screenshot','screenshot_sha256')]: verify('saved-results '+field,sha((r3/a[field]).read_bytes()),a[digest])
html=(r3/a['source_html']).read_text(encoding='utf8')
for artifact in c['artifacts']:
 verify('report shows '+artifact['path']+' public hash',artifact['published_sha256'] in html,True)
 verify('report shows '+artifact['path']+' original hash',artifact['original_sha256'] in html,True)
for name in ['root-before.log','root-intermediate-failed.log','root-after.log']:
 text=(r3/name).read_text(encoding='utf8'); verify(name+' unchanged result summary',re.findall(r'ℹ (?:tests|pass|fail|skipped) \d+',text),re.findall(r'ℹ (?:tests|pass|fail|skipped) \d+',blob(head+':'+(r3/name).as_posix()).decode()))
# Existing validation receipts and their published references, not fresh executions.
for root in [r2,r3]:
 v=json.loads((root/'validation.json').read_bytes())
 verify(root.name+' validation receipt unchanged',(root/'validation.json').read_bytes(),blob(head+':'+(root/'validation.json').as_posix()))
 for a in [*v['checks'],*v.get('build_preparation',{}).values()]:verify(root.name+'/'+a['log'],sha((root/a['log']).read_bytes()),a['published_log_sha256'])
ref=json.loads((r3/'receipt-reference.json').read_bytes())
for key,path in [('previous_receipt_sha256','prior-attempts/personal-path-correction-before-r3.json'),('updated_receipt_sha256','personal-path-correction.json'),('updated_binding_sha256','correction-binding.json')]:verify(key,sha((r2/path).read_bytes()),ref[key])
for a in json.loads((r2/'correction-binding.json').read_bytes())['artifacts']:verify('r2 bound '+a['file'],sha((r2/a['file']).read_bytes()),a['published_sha256'])
prov=json.loads((it/'terminal-provenance.json').read_bytes()); oldprov=json.loads(blob(head+':'+(it/'terminal-provenance.json').as_posix()))
verify('original terminal identity fields unchanged',{k:prov[k] for k in oldprov},oldprov)
a=prov['public_derivative_20260922']; verify('raw screenshot immutable Git digest',sha(blob(a['original_git'])),a['original_sha256']); verify('private raw screenshot digest',sha((s/'private-originals/capture-launch-v1-failed.png').read_bytes()),a['original_sha256']); verify('public derivative digest',sha((it/a['path']).read_bytes()),a['published_sha256'])
raw=Image.open(s/'private-originals/capture-launch-v1-failed.png'); derivative=Image.open(it/a['path']); verify('image dimensions retained',raw.size,derivative.size)
mask=Image.new('L',raw.size,0); draw=ImageDraw.Draw(mask)
for rect in [*a['user_root_rectangles'],a['disclosure_label_rectangle']]:draw.rectangle(rect,fill=255)
diff=ImageChops.difference(raw,derivative).convert('RGB'); diff.paste((0,0,0),(0,0),mask); verify('all pixels outside declared rectangles unchanged',diff.getbbox(),None)
for label,file in [('validation original',r3/'validation.png'),('saved-result genuine screenshot',r3/'saved-correction-results.png')]:
 with Image.open(file) as image:image.verify()
 checks.append({'check':label+' decodes','passed':True})
m=json.loads((it/a['historical_manifest']).read_bytes()); verify('historical normalization manifest bytes unchanged',(it/a['historical_manifest']).read_bytes(),blob(head+':'+(it/a['historical_manifest']).as_posix())); verify('historical manifest digest',sha((it/a['historical_manifest']).read_bytes()),a['historical_manifest_sha256'])
for f in m['files']:verify('normalization published '+f['file'],sha((it/f['file']).read_bytes()),f['published_sha256'])
for path,digest in m['unchanged_captures'].items():verify('historical image '+path,sha(blob(head+':'+(it/path).as_posix())) if path==a['path'] else sha((it/path).read_bytes()),digest)
verify('historical README published digest',sha(blob(a['historical_readme_publication_git'])),m['readme']['published_sha256']); verify('historical README original digest',sha(blob(a['historical_original_readme_git'])),m['readme']['original_sha256'])
verify('previous public README digest',sha(blob(a['readme']['previous_publication_git'])),a['readme']['previous_published_sha256']); verify('current public README digest',sha((it/'README.md').read_bytes()),a['readme']['published_sha256']); verify('README existing bytes preserved',(it/'README.md').read_bytes().startswith((s/'private-originals/README.md').read_bytes()),True)
v=Path(__file__).resolve().parent
baseline=json.loads((v/'source-before.json').read_bytes())
target='08b0b89b2dd16c1906c9dd3468c5ddecca24c4ce'
contribution=git('diff','--cached','--name-only','-z',target).decode().split('\0')[:-1]
expected_non_evidence=[
 '.gitattributes','.github/workflows/ci.yml','scenarios/factory-live-canary/README.md',
 'scenarios/factory-live-canary/git-bytes.test.mjs','scenarios/factory-live-canary/status.mjs',
 'scenarios/factory-live-canary/status.test.mjs','tools/check_evidence_personal_paths.mjs',
 'tools/check_evidence_personal_paths.test.mjs']
verify('full contribution non-evidence scope',sorted(p for p in contribution if not p.startswith('docs/evidence/')),sorted(expected_non_evidence))
verify('all tracked current source bytes', {p:sha(Path(p).read_bytes()) for p in baseline['tracked_files']},baseline['tracked_files'])
verify('exact staged path set',git('diff','--cached','--name-only','-z').decode().split('\0')[:-1],baseline['staged_paths'])
verify('no unstaged source edits',git('diff','--name-only'),b'')
verify('no untracked nonignored source',git('ls-files','--others','--exclude-standard','-z'),b'')
verify('HEAD preserved',git('rev-parse','HEAD').decode().strip(),baseline['head'])
verify('branch preserved',git('symbolic-ref','HEAD').decode().strip(),baseline['branch'])
verify('exact index byte preservation',sha(Path(baseline['index_path']).read_bytes()),baseline['index_sha256'])
# Read every contribution file in full; inspect structured evidence and complete log outcomes.
inventory=[]; historical_outcomes=[]; credential_findings=[]
for p in contribution:
 data=Path(p).read_bytes()
 entry={'path':p,'bytes':len(data),'worktree_sha256':sha(data),
        'index_blob':git('rev-parse',':'+p).decode().strip(),
        'index_sha256':sha(blob(':'+p))}
 if p.endswith('.png'):
  with Image.open(p) as image:
   entry['image_dimensions']=image.size
   image.verify()
  checks.append({'check':p+' PNG decode/integrity','passed':True})
 else:
  text=data.decode('utf8')
  entry['lines']=len(text.splitlines())
  if p.endswith('.json'):
   value=json.loads(text)
   entry['json_shape']=list(value) if isinstance(value,dict) else {'type':type(value).__name__,'count':len(value)}
   checks.append({'check':p+' complete JSON parse','passed':True})
  elif p.endswith('.jsonl'):
   entry['jsonl_records']=sum(1 for line in text.splitlines() if line.strip() and json.loads(line) is not None)
   checks.append({'check':p+' complete JSONL parse','passed':True})
  if p.startswith('docs/evidence/'):
   if re.search(r'\b(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{20,})\b',text):
    credential_findings.append(p)
   summary=[line for line in text.splitlines() if re.search(
    r'test result:|^[#ℹ]\s*(?:tests|pass|fail|skipped|cancelled|todo)\s+\d+|^not ok|^error(?:\[|:)|^ACTUAL EXIT CODE:|^Found \d+ warnings',line)]
   if summary: historical_outcomes.append({'file':p,'result_lines':summary})
 inventory.append(entry)
verify('credential-shaped strings absent from full public evidence text',credential_findings,[])
# Old author-source assertions are historical and would reject newer main. Check their retained
# receipts against their actual portable logs, without presenting them as current-source review.
local=Path('docs/evidence/pr226-local-validation')
for recordfile in ['baseline-results.json','web-retry-results.json','final-checks-results.json',
                   'final-diff-check-results.json','normal-git-check-results.json']:
 for record in json.loads((local/recordfile).read_bytes()):
  for log in record['logs'].values():
   verify(recordfile+'/'+log['path']+' retained portable digest',sha((local/log['path']).read_bytes()),log['portableSha256'])
  verify(recordfile+'/'+record.get('id','')+' no signal',record['signal'],None)
for name in ['pr-226-completion-20260922','pr-226-completion-20260922-r2','pr-226-completion-20260922-r3']:
 root=Path('docs/evidence')/name
 receipt=json.loads((root/'validation.json').read_bytes())
 verify(name+' retains nine historical command records',len(receipt['checks']),9)
 verify(name+' does not claim current candidate tree',receipt['tested_staged_tree']==baseline['staged_tree'],False)
 for record in [*receipt['checks'],*receipt.get('build_preparation',{}).values()]:
  verify(name+'/'+record['log']+' published log binding',sha((root/record['log']).read_bytes()),record['published_log_sha256'])
# Validate the original canary contract at the current index, without executing historical code.
for name,expected in [('status.mjs','df8af8ce2c756d230c1d303c2121c88a8495c608c3616592504b42a3d47c520b'),
                      ('README.md','123cc52972ec592813f99069b97b79423bff1b04fa9025822327190fd646fa8e')]:
 p='scenarios/factory-live-canary/'+name
 verify(p+' raw current index original contract',sha(blob(':'+p)),expected)
 verify(p+' current working equals exact index',Path(p).read_bytes(),blob(':'+p))
report=Path('docs/evidence/2026-09-12-pr226-exact-git-bytes.md').read_text(encoding='utf8')
verify('nonclosing maintainer alternative retained','nonclosing maintainer contribution' in report,True)
verify('eight persisted native checks remain unproven','eight persisted checks' in report and 'remain open/unproven' in report,True)
verify('public saved report explicitly historical', 'not a live test or application capture' in html,True)
verify('public saved report runs no executable script', re.search(r'<script\b',html,re.I),None)
verify('root-only followup adds exactly two scoped attributes',
 (it/'.gitattributes').read_bytes(),
 blob(head+':'+(it/'.gitattributes').as_posix())+b'README.md whitespace=cr-at-eol\npath-normalization-20260922.json whitespace=cr-at-eol\n')
verify('all tracked source preserved after full review',{p:sha(Path(p).read_bytes()) for p in baseline['tracked_files']},baseline['tracked_files'])
verify('index preserved after full review',sha(Path(baseline['index_path']).read_bytes()),baseline['index_sha256'])
verify('pending MERGE_HEAD is new current-main target',git('rev-parse','MERGE_HEAD').decode().strip(),target)
verify('HEAD is local unpublished correction commit',baseline['head'],'91a5b4e58a13eb0128f3f69beedcb9bd174fbb23')
verify('pending merged tree is exact authorized input',baseline['staged_tree'],'2cf0ea4851f09cbdb7cf3f08a6c3422abda416a8')
verify('no author product/runtime changes against new main',
       git('diff','--cached','--name-only',target,'--','crates','apps','db','Cargo.toml','Cargo.lock','pnpm-lock.yaml','package.json'),b'')
pending=git('diff','--cached','--name-only','-z','HEAD').decode().split('\0')[:-1]
verify('only integrated runtime delta is the main retained-receipt change',
       [p for p in pending if not p.startswith('docs/evidence/')],['crates/crony-store/src/retained_provider_receipt.rs'])
receipt_path='crates/crony-store/src/retained_provider_receipt.rs'
verify('integrated retained-receipt raw index equals main',blob(':'+receipt_path),blob(target+':'+receipt_path))
receipt_text=Path(receipt_path).read_text(encoding='utf8')
expected_tests=re.findall(r'#\[test\]\s+fn (upload_binding_\w+)\(',receipt_text)
verify('five new main receipt tests in actual source',len(expected_tests),5)
# Exhaust the Boolean predicate change for absent object and representative lengths.
for length in [None,0,1,2,3,100]:
 verify('is_none_or equivalence for '+str(length),
        not(length is not None and length==2),length is None or length!=2)
(v/'author-contribution.diff').write_bytes(git('diff','--cached','--no-ext-diff','--no-textconv',target))
(v/'main-integration.diff').write_bytes(git('diff','--cached','--no-ext-diff','--no-textconv','HEAD'))
# Require real nonempty decoded outcome matches, not equal empty parser results.
for filename,expected in [('root-before.log',{'tests':6,'pass':4,'fail':2,'skipped':0}),('root-intermediate-failed.log',{'tests':6,'pass':4,'fail':2,'skipped':0}),('root-after.log',{'tests':6,'pass':6,'fail':0,'skipped':0})]:
 text=(r3/filename).read_text(encoding='utf8')
 actual={key:int(value) for key,value in re.findall(r'^.{1,6} (tests|pass|fail|skipped) (\d+)\s*$',text,re.M)}
 verify(filename+' non-vacuous actual summary',actual,expected)
result={'status':'passed','kind':'automated-author-delegate-self-review-checks',
 'independent_approval':False,'human_approval':False,'native_factory_acceptance':False,'issue225_closing':False,
 'head':baseline['head'],'candidate_tree':baseline['staged_tree'],'target':target,
 'checks':len(checks),'results':checks,'contribution_files':len(inventory),
 'contribution_bytes':sum(entry['bytes'] for entry in inventory),
 'inventory':inventory,'historical_outcomes':historical_outcomes,
 'limits':['Historical raw completion archives not accessed or reconstructed.',
           'All contribution bytes read and hashed; JSON/JSONL parsed, PNGs decoded, complete text log summaries inspected.',
           'PNG integrity and declared correction pixel bounds checked anew; publication/image production remains with the parent; no OCR privacy guarantee.',
           'Old self-review source manifest remains historical; not executed or relabelled against current main.',
           'Fresh nine-gate outcomes are separate and cannot be inferred from historical records.']}
(v/'author-checks-result-r8.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k] for k in ['status','kind','checks','contribution_files','contribution_bytes','head','candidate_tree','target']},indent=2))
