"""Final read-only source proof; retain, rather than waive, shared-ref audit failures."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

V = Path(__file__).resolve().parent
E = json.loads((V / "environment.json").read_bytes())
B = json.loads((V / "source-before.json").read_bytes())
ROOT = Path(E["cwd"])
ENV = E["environment"]
GIT = E["tools"]["files"]["git"]["path"]
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    (V / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf8")


def git(*args):
    return subprocess.check_output([GIT, *args], cwd=ROOT, env=ENV,
                                   creationflags=subprocess.CREATE_NO_WINDOW)


def refs():
    data = git("for-each-ref", "--format=%(refname) %(objectname)")
    return data, dict(line.split(" ", 1) for line in data.decode().splitlines())


original_ref_bytes = (V / "original-refs-reconstructed.txt").read_bytes()
assert sha(original_ref_bytes) == B["refs_sha256"]
original_refs = dict(line.split(" ", 1) for line in original_ref_bytes.decode().splitlines())
protected_refs = [B["branch"], "refs/heads/main", "refs/remotes/origin/main",
                  "refs/remotes/origin/ecorp/factory-live-225"]
protected_refs = [ref for ref in protected_refs if ref in original_refs]
checks = []


def check(label, actual, expected):
    checks.append({"check": label, "passed": actual == expected})
    assert actual == expected, label


def snapshot():
    raw_refs, ref_map = refs()
    state = {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "merge_head": git("rev-parse", "MERGE_HEAD").decode().strip(),
        "branch": git("symbolic-ref", "HEAD").decode().strip(),
        "index_sha256": sha(Path(B["index_path"]).read_bytes()),
        "tracked_files": {p: sha((ROOT / p).read_bytes()) for p in B["tracked_files"]},
        "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
        "git_control_files": {name: {"path": item["path"],
            "sha256": sha(Path(item["path"]).read_bytes()) if Path(item["path"]).is_file() else None}
            for name, item in B["git_control_files"].items()},
    }
    check("PR226 tracked source, HEAD, index, merge controls and config preserved", state, {k: B[k] for k in state})
    selected = {ref: ref_map.get(ref) for ref in protected_refs}
    check("PR226 and selected local main/tracking refs preserved", selected, {ref: original_refs[ref] for ref in protected_refs})
    changes = {ref: {"before": original_refs.get(ref), "after": ref_map.get(ref)}
               for ref in sorted(set(original_refs) | set(ref_map)) if original_refs.get(ref) != ref_map.get(ref)}
    return {"at": now(), "state": state, "selected_refs": selected,
            "all_refs_sha256": sha(raw_refs), "all_ref_differences": changes}


binding = {"started_at": now(), "driver": str(Path(__file__).resolve()),
           "driver_sha256": sha(Path(__file__).read_bytes()), "argv": sys.argv,
           "python": sys.executable, "python_sha256": sha(Path(sys.executable).read_bytes()),
           "environment": ENV, "tools": E["tools"], "baseline_sha256": sha((V / "source-before.json").read_bytes()),
           "scope": "Final local-source readback, not a passing whole-repository-ref assertion."}
save("final-readback-binding.json", binding)
before = snapshot()
save("final-readback.before.json", before)
results = json.loads((V / "results.json").read_bytes())
check("nine required commands executed", sum(r["required"] for r in results), 9)
for r in results:
    check(r["name"] + " actual terminal zero", r["exit_code"], 0)
    for flag in ["passed", "source_preserved", "runtime_preserved", "driver_preserved"]:
        check(r["name"] + " " + flag, r[flag], True)
    for side in ["source_before", "source_after"]:
        check(r["name"] + " original entire execution baseline " + side,
              json.loads((V / r[side]).read_bytes()), B)
    for stream, rec in r["logs"].items():
        data = (V / rec["file"]).read_bytes()
        data.decode("utf8")
        check(r["name"] + " complete raw " + stream, [len(data), sha(data)], [rec["bytes"], rec["sha256"]])
audit = json.loads((V / "complete-log-audit.json").read_bytes())
check("every executed command has full log readback", [r["name"] for r in audit], [r["name"] for r in results])
author = json.loads((V / "18-author-checks-r8.json").read_bytes())
check("author self-review terminal zero", author["exit_code"], 0)
check("author self-review source preserved", author["source_preserved"], True)
for rec in author["logs"].values():
    check("author complete raw log " + rec["path"], sha((V / rec["path"]).read_bytes()), rec["sha256"])
main = json.loads((V / "new-main-receipt-tests.json").read_bytes())
check("five main receipt tests actually passed", main["passed"], True)
check("main receipt source binding", main["source_sha256"], B["tracked_files"]["crates/crony-store/src/retained_provider_receipt.rs"])
check("main receipt Rust log binding", main["rust_log_sha256"], sha((V / "07-cargo-test.stdout.log").read_bytes()))
mcp = json.loads((V / "native-mcp-binding.json").read_bytes())
check("MCP exact pre-Node binary retained", sha(Path(mcp["path"]).read_bytes()), mcp["sha256"])
for name, item in E["tools"]["files"].items():
    check("unchanged selected tool " + name, sha(Path(item["path"]).read_bytes()), item["sha256"])
check("unchanged actual gate driver", sha((V / "validate-r8.py").read_bytes()), E["driver_sha256"])
check("unchanged prior driver", sha(Path(E["copied_driver"]["source"]).read_bytes()), E["copied_driver"]["sha256"])
temp = json.loads((V / "temp-preservation-before-rust.json").read_bytes())
t = Path(temp["root"])
check("all pre-Rust retained short-TEMP file bytes", {p: sha((t / p).read_bytes()) for p in temp["files"]}, temp["files"])
check("all pre-Rust short-TEMP directories retained", all((t / p).is_dir() for p in temp["directories"]), True)
check("task TEMP owner marker preserved", sha((t / ".owner.json").read_bytes()), B["temp_metadata"]["owner_sha256"])
acl = subprocess.check_output(["powershell.exe", "-NoProfile", "-Command",
    "$a=Get-Acl -LiteralPath 'C:\\LOCAL\\actor\\q70ab6'; "
    "@{owner=$a.Owner;sddl=$a.Sddl;protected=$a.AreAccessRulesProtected}|ConvertTo-Json -Compress"],
    cwd=ROOT, env=ENV, creationflags=subprocess.CREATE_NO_WINDOW)
check("inherited TEMP ACL unchanged", json.loads(acl), B["temp_metadata"]["acl"])
check("parent identity preserved", sha((V.parent / "identity.json").read_bytes()), E["source_identity_sha256"])
after = snapshot()
save("final-readback.after.json", after)
check("final local state unchanged during readback", after["state"], before["state"])
check("readback driver unchanged", sha(Path(__file__).read_bytes()), binding["driver_sha256"])
receipt = {
    "ended_at": now(), "local_validation": "PASS", "author_delegate_self_review": "PASS",
    "whole_repository_refs_unchanged": False,
    "global_ref_audit": "FAIL_RETAINED_CONCURRENT_UNRELATED_BRANCH_AND_CODEX_METADATA_CHANGES",
    "head": B["head"], "pending_tree": B["staged_tree"], "merge_head": B["merge_head"],
    "tracked_files_preserved": len(B["tracked_files"]), "source_index_merge_controls_preserved": True,
    "selected_refs_preserved": after["selected_refs"], "all_ref_differences": after["all_ref_differences"],
    "assertions_passed": len(checks), "checks": checks,
    "required_gates_passed": 9, "complete_raw_command_log_bytes": sum(r["bytes_read"] for r in audit),
    "author_assertions": json.loads((V / "author-checks-result-r8.json").read_bytes())["checks"],
    "authority": "Automated AUTHOR-DELEGATE only; no human/Santa/SAFE/independent approval or native Factory acceptance.",
}
save("final-readback.json", receipt)
print(json.dumps({k: receipt[k] for k in ["local_validation", "author_delegate_self_review",
    "whole_repository_refs_unchanged", "tracked_files_preserved", "assertions_passed",
    "required_gates_passed", "complete_raw_command_log_bytes"]}))
