"""Read every fresh terminal byte and reconcile counts, hashes, scope and preservation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
from collections import Counter
from PIL import Image

V = Path(__file__).resolve().parent
E = json.loads((V / "environment.json").read_bytes())
B = json.loads((V / "source-before.json").read_bytes())
ROOT = Path(E["cwd"])
ENV = E["environment"]
GIT = E["tools"]["files"]["git"]["path"]
sha = lambda b: hashlib.sha256(b).hexdigest()
checks = []


def verify(name, actual, expected=True):
    checks.append({"check": name, "passed": actual == expected})
    assert actual == expected, (name, actual, expected)


def save(name, value):
    (V / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf8")


def git(*args):
    return subprocess.check_output([GIT, *args], cwd=ROOT, env=ENV,
                                   creationflags=subprocess.CREATE_NO_WINDOW)


def live():
    return {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "merge_head": git("rev-parse", "MERGE_HEAD").decode().strip(),
        "branch": git("symbolic-ref", "HEAD").decode().strip(),
        "index_sha256": sha(Path(B["index_path"]).read_bytes()),
        "tracked_files": {p: sha((ROOT / p).read_bytes()) for p in B["tracked_files"]},
        "refs_sha256": sha(git("for-each-ref", "--format=%(refname) %(objectname)")),
        "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
        "git_control_files": {name: {"path": value["path"],
            "sha256": sha(Path(value["path"]).read_bytes()) if Path(value["path"]).is_file() else None}
            for name, value in B["git_control_files"].items()},
    }


before = live()
verify("live state matches execution baseline", before, {k: B[k] for k in before})
save("final-audit.before.json", before)
save("final-audit-binding.json", {
    "driver": str(Path(__file__).resolve()), "sha256": sha(Path(__file__).read_bytes()),
    "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "head": B["head"], "pending_tree": B["staged_tree"], "merge_head": B["merge_head"],
    "kind": "automated AUTHOR-DELEGATE audit of actual fresh private receipts",
})
results = json.loads((V / "results.json").read_bytes())
verify("all nine required commands executed", sum(r["required"] for r in results), 9)
log_audit = []
for r in results:
    name = r["name"]
    verify(name + " exact per-command record", r, json.loads((V / (name + ".json")).read_bytes()))
    verify(name + " terminal exit", r["exit_code"], 0)
    for key in ["source_preserved", "runtime_preserved", "driver_preserved", "passed"]:
        verify(name + " " + key, r[key])
    verify(name + " before complete source/index/ref baseline",
           json.loads((V / r["source_before"]).read_bytes()), B)
    verify(name + " after complete source/index/ref baseline",
           json.loads((V / r["source_after"]).read_bytes()), B)
    verify(name + " immutable driver", sha(Path(r["driver"]).read_bytes()), r["driver_sha256"])
    texts = {}
    for stream, rec in r["logs"].items():
        data = (V / rec["file"]).read_bytes()
        verify(name + " " + stream + " full-byte hash", sha(data), rec["sha256"])
        verify(name + " " + stream + " byte length", len(data), rec["bytes"])
        texts[stream] = data.decode("utf8")
    text = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", texts["stdout"])
    row = {"name": name, "exit_code": r["exit_code"], "stdout_lines": len(text.splitlines()),
           "stderr_complete": texts["stderr"], "bytes_read": sum(x["bytes"] for x in r["logs"].values())}
    if "node_summary" in r:
        actual = {k: int(n) for k, n in re.findall(
            r"^[#ℹ]\s*(tests|suites|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$", text, re.M)}
        verify(name + " nonempty Node terminal summary", actual, r["node_summary"])
        for key in ["fail", "cancelled", "skipped", "todo"]:
            verify(name + " Node " + key, actual[key], 0)
        passed = [line for line in text.splitlines() if re.match(r"^\s*✔ |^\s*ok \d+ - ", line)]
        verify(name + " individual pass lines reconcile", len(passed), actual["pass"])
        row["node_summary"] = actual
        row["individual_pass_lines"] = passed
        if name == "03-unit":
            native = [line for line in passed if "compiled " in line]
            verify("native MCP cases actually executed", len(native) >= 40)
            row["native_mcp_pass_lines"] = native
        row["other_stdout_lines"] = [line for line in text.splitlines() if line not in passed]
    elif "rust_totals" in r:
        suites = re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", text)
        totals = {key: sum(int(s[i + 1]) for s in suites)
                  for i, key in enumerate(["passed", "failed", "ignored", "measured", "filtered"])}
        verify(name + " full Rust suites reconcile", totals, r["rust_totals"])
        verify(name + " Rust every suite ok", all(s[0] == "ok" for s in suites))
        cases = re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored(?:,.*)?)$", text, re.M)
        passed = [n for n, status in cases if status == "ok"]
        ignored = [{"name": n, "reason": status.removeprefix("ignored").lstrip(", ")}
                   for n, status in cases if status.startswith("ignored")]
        verify(name + " individual Rust pass cases reconcile", len(passed), totals["passed"])
        verify(name + " individual Rust ignored cases reconcile", len(ignored), totals["ignored"])
        verify(name + " no filtered/failed/measured cases", [totals[k] for k in ["failed", "filtered", "measured"]], [0, 0, 0])
        row.update(rust_totals=totals, rust_suite_summaries=suites, individual_pass_names=passed,
                   ignored_cases=ignored, ignored_reason_counts=dict(Counter(c["reason"] for c in ignored)),
                   other_stdout_lines=[line for line in text.splitlines() if not re.match(r"^test .+ \.\.\. (?:ok|FAILED|ignored(?:,.*)?)$", line)])
    else:
        row["stdout_complete"] = texts["stdout"]
    log_audit.append(row)
save("complete-log-audit.json", log_audit)
new = json.loads((V / "new-main-receipt-tests.json").read_bytes())
verify("five new-main receipt cases pass in full actual Rust output", new["passed"])
verify("new-main receipt test log binding", sha((V / "07-cargo-test.stdout.log").read_bytes()), new["rust_log_sha256"])
mcp = json.loads((V / "native-mcp-binding.json").read_bytes())
verify("native MCP remains the pre-Node bound binary", sha(Path(mcp["path"]).read_bytes()), mcp["sha256"])
for name, item in E["tools"]["files"].items():
    verify(name + " runtime file preserved", sha(Path(item["path"]).read_bytes()), item["sha256"])
verify("original driver preserved", sha(Path(E["copied_driver"]["source"]).read_bytes()), E["copied_driver"]["sha256"])
verify("parent source identity preserved", sha((V.parent / "identity.json").read_bytes()), E["source_identity_sha256"])
author = json.loads((V / "18-author-checks-r8.json").read_bytes())
verify("author checks exit", author["exit_code"], 0)
for key in ["source_preserved", "runtime_preserved", "driver_preserved", "check_script_preserved"]:
    verify("author " + key, author[key])
for rec in author["logs"].values():
    verify("author raw log binding " + rec["path"], sha((V / rec["path"]).read_bytes()), rec["sha256"])
incoming = git("diff", "--cached", "--name-only", "-z", "HEAD").decode().split("\0")[:-1]
inventory = []
for path in incoming:
    data = (ROOT / path).read_bytes()
    raw = git("cat-file", "blob", ":" + path)
    verify(path + " clean incoming-main raw blob equality", raw, git("cat-file", "blob", B["merge_head"] + ":" + path))
    item = {"path": path, "bytes": len(data), "working_sha256": sha(data), "index_sha256": sha(raw)}
    if path.endswith(".png"):
        with Image.open(ROOT / path) as image:
            item["image_dimensions"] = image.size
            image.verify()
    else:
        text = data.decode("utf8")
        item["lines_read"] = len(text.splitlines())
        if path.endswith(".json"):
            value = json.loads(text)
            item["json_shape"] = list(value) if isinstance(value, dict) else {"type": type(value).__name__}
    inventory.append(item)
save("main-integration-inventory.json", {"files": len(inventory), "inventory": inventory,
    "scope": "Incoming main bytes, not author contribution; historical receipts not credited as fresh validation."})
temp_before = json.loads((V / "temp-preservation-before-rust.json").read_bytes())
t = Path(temp_before["root"])
verify("all baseline short-TEMP files preserved",
       {p: sha((t / p).read_bytes()) for p in temp_before["files"]}, temp_before["files"])
verify("all baseline short-TEMP directories retained", all((t / p).is_dir() for p in temp_before["directories"]))
verify("all baseline short-TEMP links preserved", {p: os.readlink(t / p) for p in temp_before["links"]}, temp_before["links"])
after = live()
verify("final live source/index/MERGE_HEAD/refs preserved", after, before)
save("final-audit.after.json", after)
save("terminal-audit.json", {"status": "PASS", "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "head": B["head"], "pending_tree": B["staged_tree"], "target": B["merge_head"],
    "assertions": len(checks), "checks": checks,
    "raw_command_log_bytes_read": sum(r["bytes_read"] for r in log_audit),
    "required_passed": 9, "author_assertions": json.loads((V / "author-checks-result-r8.json").read_bytes())["checks"],
    "ignored_not_passed": True, "no_native_factory_or_browser_or_provider_or_db_acceptance": True,
    "short_temp_preserved_scope": "141 pre-Rust existing files, directories, owner and inherited ACL; no cleanup performed",
    "independent_approval": False, "human_approval": False})
print(json.dumps({"status": "PASS", "assertions": len(checks), "required_passed": 9,
                  "incoming_main_files": len(inventory), "raw_log_bytes_read": sum(r["bytes_read"] for r in log_audit)}))
