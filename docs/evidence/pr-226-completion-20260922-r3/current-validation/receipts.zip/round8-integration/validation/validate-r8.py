"""Private PR226 validation driver. No source/index/ref writes or public evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path("C:/LOCAL/actor/repos/ecorp/worktrees/pr226-r7-public-evidence")
OUT = Path(__file__).resolve().parent
SCRATCH = OUT.parent
EXPECTED_HEAD = "91a5b4e58a13eb0128f3f69beedcb9bd174fbb23"
EXPECTED_TREE = "2cf0ea4851f09cbdb7cf3f08a6c3422abda416a8"
BASE = "08b0b89b2dd16c1906c9dd3468c5ddecca24c4ce"
DEPS = Path("C:/LOCAL/actor/.cache/codex-runtimes/codex-primary-runtime/dependencies")
NODE = DEPS / "node/bin/node.exe"
PNPM = DEPS / "node/node_modules/pnpm/bin/pnpm.mjs"
PYTHON = DEPS / "python/python.exe"
GIT = Path(shutil.which("git"))
CARGO = Path(shutil.which("cargo"))
RUSTC = Path(shutil.which("rustc"))
ALLOW = {"PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "COMSPEC", "USERPROFILE",
         "LOCALAPPDATA", "APPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMDATA",
         "HOMEDRIVE", "HOMEPATH", "COMPUTERNAME", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE",
         "CARGO_HOME", "RUSTUP_HOME", "VCTOOLSINSTALLDIR", "VCINSTALLDIR", "VSINSTALLDIR",
         "WINDOWSSDKDIR", "WINDOWSSDKVERSION", "INCLUDE", "LIB", "LIBPATH"}
ENV = {k: v for k, v in os.environ.items() if k.upper() in ALLOW}
TEMP = Path("C:/LOCAL/actor/q70ab6").resolve()
assert not TEMP.is_relative_to(ROOT) and not TEMP.is_relative_to(ROOT.parents[1])
assert len(str(TEMP)) == 26
OWNER = json.loads((TEMP / ".owner.json").read_bytes())
assert OWNER["purpose"] == "ecorp-pr226-short-native-test-temp"
assert OWNER["task"] == "01a0c4ef-fda5-7152-b6ae-5b04e48d36ca" and OWNER["retain"] is True
PRIOR = OUT.parents[1] / "round7-public-evidence/validation"
TARGET = PRIOR / "cargo-target"
assert TARGET.is_dir()
PRIOR_ENV = json.loads((PRIOR / "environment.json").read_bytes())
assert Path(PRIOR_ENV["cwd"]).resolve() == ROOT.resolve()
assert Path(PRIOR_ENV["cargo_target"]).resolve() == TARGET.resolve()
ENV.update({
    "PATH": os.pathsep.join([str(NODE.parent), str(PYTHON.parent), str(DEPS / "bin/fallback"), ENV["PATH"]]),
    "TEMP": str(TEMP), "TMP": str(TEMP),
    "CARGO_TARGET_DIR": str(TARGET), "CARGO_BUILD_JOBS": "2", "RUST_TEST_THREADS": "1",
    "GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0",
    "GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "core.longpaths", "GIT_CONFIG_VALUE_0": "true",
    "PYTHONDONTWRITEBYTECODE": "1", "CI": "true",
})
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def capture(args):
    return subprocess.check_output([str(a) for a in args], cwd=ROOT, env=ENV,
                                   stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)

def git(*args):
    return capture([GIT, *args])

def temp_metadata():
    acl = capture(["powershell.exe", "-NoProfile", "-Command",
                   "$a=Get-Acl -LiteralPath 'C:\\LOCAL\\actor\\q70ab6'; "
                   "@{owner=$a.Owner;sddl=$a.Sddl;protected=$a.AreAccessRulesProtected}|ConvertTo-Json -Compress"])
    result = {"owner_sha256": sha((TEMP / ".owner.json").read_bytes()), "acl": json.loads(acl)}
    assert result["acl"]["protected"] is False
    return result

def staged_tree(entries):
    root = {}
    for entry in entries:
        metadata, name = entry.split(b"\t", 1)
        mode, oid, stage = metadata.split()
        assert stage == b"0", "Unmerged index"
        directory = root
        parts = name.split(b"/")
        for part in parts[:-1]:
            directory = directory.setdefault(part, {})
        directory[parts[-1]] = (mode, bytes.fromhex(oid.decode()))
    def digest(directory):
        pieces = []
        for name, value in sorted(directory.items(), key=lambda item: item[0] + (b"/" if isinstance(item[1], dict) else b"")):
            mode, oid = (b"40000", digest(value)) if isinstance(value, dict) else value
            pieces.append(mode + b" " + name + b"\0" + oid)
        data = b"".join(pieces)
        return hashlib.sha1(b"tree " + str(len(data)).encode() + b"\0" + data).digest()
    return digest(root).hex()

def source():
    index = Path(git("rev-parse", "--path-format=absolute", "--git-path", "index").decode().strip())
    entries = git("ls-files", "--stage", "-z").split(b"\0")[:-1]
    files = {}
    for entry in entries:
        name = entry.split(b"\t", 1)[1].decode()
        files[name] = sha((ROOT / name).read_bytes())
    control = {}
    for name in ["HEAD", "MERGE_HEAD", "MERGE_MSG", "MERGE_MODE", "ORIG_HEAD", "config", "config.worktree"]:
        path = Path(git("rev-parse", "--path-format=absolute", "--git-path", name).decode().strip())
        control[name] = {"path": str(path), "sha256": sha(path.read_bytes()) if path.is_file() else None}
    return {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "branch": git("symbolic-ref", "HEAD").decode().strip(),
        "staged_tree": staged_tree(entries), "index_path": str(index), "index_sha256": sha(index.read_bytes()),
        "index_entries_sha256": sha(b"\0".join(entries)), "tracked_count": len(files),
        "tracked_files": files, "tracked_digest": sha(json.dumps(files, sort_keys=True).encode()),
        "status": git("status", "--porcelain=v1", "--untracked-files=all").decode(),
        "staged_paths": git("diff", "--cached", "--name-only", "-z").decode().split("\0")[:-1],
        "merge_head": git("rev-parse", "MERGE_HEAD").decode().strip(),
        "git_control_files": control,
        "refs_sha256": sha(git("for-each-ref", "--format=%(refname) %(objectname)")),
        "temp_metadata": temp_metadata(),
    }

TOOL_ARGS = {"node": [NODE, "--version"], "python": [PYTHON, "--version"],
             "pnpm": [NODE, PNPM, "--version"], "cargo": [CARGO, "--version"],
             "rustc": [RUSTC, "--version"], "git": [GIT, "--version"]}
def runtime():
    versions = {name: capture(args).decode().strip() for name, args in TOOL_ARGS.items()}
    paths = {"node": NODE, "python": PYTHON, "pnpm_entry": PNPM, "cargo": CARGO, "rustc": RUSTC, "git": GIT,
             "npm_shim": Path(shutil.which("npm.cmd", path=ENV["PATH"]))}
    # Rustup proxies are not the compiler identities; bind both resolved native tools too.
    for name in ("cargo", "rustc", "rustfmt", "cargo-clippy", "clippy-driver"):
        paths[f"native_{name}"] = Path(capture([CARGO.parent / "rustup.exe", "which", name]).decode().strip())
    return {"versions": versions, "files": {name: {"path": str(path), "sha256": sha(path.read_bytes())} for name, path in paths.items()}}

BASELINE = source()
assert BASELINE["head"] == EXPECTED_HEAD
assert BASELINE["staged_tree"] == EXPECTED_TREE
assert BASELINE["merge_head"] == BASE
IDENTITY = json.loads((SCRATCH / "identity.json").read_bytes())
assert IDENTITY["head"] == EXPECTED_HEAD and IDENTITY["pendingTree"] == EXPECTED_TREE and IDENTITY["mergeTarget"] == BASE
assert not git("diff", "--name-only"), "Unstaged source changes"
assert not git("ls-files", "--others", "--exclude-standard", "-z"), "Untracked source"
assert not git("diff", "--cached", "--name-only", BASE, "--", "Cargo.toml", "Cargo.lock",
               "pnpm-lock.yaml", "package.json", "crates", "apps", "db"), "Unexpected author runtime delta"
save("source-before.json", BASELINE)
TOOLS = runtime()
assert TOOLS["versions"]["node"] == "v24.19.0"
assert TOOLS["versions"]["pnpm"] == "11.19.0"
assert TOOLS["versions"]["python"].startswith("Python 3.12.")
assert TOOLS["versions"]["rustc"].startswith("rustc 1.98.1 ")
save("environment.json", {
    "at": now(), "cwd": str(ROOT), "driver": str(Path(__file__).resolve()),
    "driver_sha256": sha(Path(__file__).read_bytes()), "interpreter": sys.executable,
    "tools": TOOLS, "environment": ENV,
    "removed_ambient_names": sorted(k for k in os.environ if k.upper() not in ALLOW),
    "temp": str(TEMP), "cargo_target": str(TARGET), "acl": "Inherited only; no ACL/security/config/TLS workaround",
    "scope": "Author-delegate local source validation; no independent Santa/SAFE/GitHub/human approval or native Factory acceptance",
    "contracts_read": {p: BASELINE["tracked_files"][p] for p in [
        "AGENTS.md", "tools/AGENTS.md", "apps/web/AGENTS.md", "docs/PRODUCT_AND_TECHNICAL_PLAN.md", "docs/ARCHITECTURE.md", "docs/SECURITY.md", "docs/EVALS.md"]},
    "copied_driver": {"source": str(PRIOR / "validate.py"), "sha256": sha((PRIOR / "validate.py").read_bytes()),
                      "destination": str(Path(__file__).resolve()), "original_unchanged": True},
    "source_identity_sha256": sha((SCRATCH / "identity.json").read_bytes()),
    "target_reuse": "Same-worktree source-exclusive native Cargo cache; native invalidation for new-main inputs, no copied binaries",
    "temp_owner": OWNER, "temp_metadata": BASELINE["temp_metadata"],
    "protected_services": ["API8791", "web5187", "DB54329"],
    "attribution": {"kind": "automated AUTHOR-DELEGATE", "thread_id": os.environ.get("CODEX_THREAD_ID"),
                    "human": False, "independent": False},
    "harness_review": "Required scripts, pins, MCP synthetic port-0 fixtures, canary/scanner tests and Rust fixture/env boundaries inspected before execution. Shared API/web/DB and ignored integration/provider lanes not selected.",
})
RESULTS = []
DRIVER_SHA = sha(Path(__file__).read_bytes())

def run(name, label, args, required=False):
    assert sha(Path(__file__).read_bytes()) == DRIVER_SHA
    before = source()
    assert before == BASELINE, f"Source drift before {name}"
    record = {
        "name": name, "label": label, "required": required, "argv": [str(a) for a in args], "cwd": str(ROOT),
        "driver": str(Path(__file__).resolve()), "driver_sha256": sha(Path(__file__).read_bytes()),
        "interpreter": sys.executable, "interpreter_sha256": sha(Path(sys.executable).read_bytes()),
        "runtime_before": runtime(), "source_before": f"{name}.before.json",
        "source_after": f"{name}.after.json", "environment": ENV.copy(),
    }
    save(f"{name}.before.json", before)
    if ENV.get("CRONY_MCP_TEST_BINARY"):
        record["native_mcp_sha256"] = sha(Path(ENV["CRONY_MCP_TEST_BINARY"]).read_bytes())
    record["started_at_utc"] = now()
    save(f"{name}.json", record)
    start = time.monotonic()
    print(f"START {name}: {label}", flush=True)
    with (OUT / f"{name}.stdout.log").open("xb") as stdout, (OUT / f"{name}.stderr.log").open("xb") as stderr:
        try:
            result = subprocess.run(record["argv"], cwd=ROOT, env=ENV, stdin=subprocess.DEVNULL,
                                    stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            record["exit_code"] = result.returncode
        except OSError as error:
            record["exit_code"] = None
            record["launch_error"] = str(error)
    record["ended_at_utc"] = now()
    record["elapsed_seconds"] = round(time.monotonic() - start, 3)
    after = source()
    save(f"{name}.after.json", after)
    record["source_preserved"] = before == after == BASELINE
    record["runtime_after"] = runtime()
    record["runtime_preserved"] = record["runtime_after"] == record["runtime_before"]
    record["driver_preserved"] = sha(Path(__file__).read_bytes()) == DRIVER_SHA
    if record.get("native_mcp_sha256"):
        record["native_mcp_sha256_after"] = sha(Path(ENV["CRONY_MCP_TEST_BINARY"]).read_bytes())
        record["native_mcp_preserved"] = record["native_mcp_sha256"] == record["native_mcp_sha256_after"]
    record["logs"] = {}
    text = ""
    for stream in ("stdout", "stderr"):
        p = OUT / f"{name}.{stream}.log"
        data = p.read_bytes()
        record["logs"][stream] = {"file": p.name, "bytes": len(data), "sha256": sha(data)}
        text += data.decode("utf-8", errors="replace") + "\n"
    clean = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", text)
    node = re.findall(r"^[#ℹ]\s*(tests|suites|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$", clean, re.M)
    if node:
        record["node_summary"] = {key: int(value) for key, value in node}
    rust = re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", clean)
    if rust:
        record["rust_suites"] = [{"result": row[0], **dict(zip(["passed", "failed", "ignored", "measured", "filtered"], map(int, row[1:])))} for row in rust]
        record["rust_totals"] = {key: sum(row[key] for row in record["rust_suites"]) for key in ["passed", "failed", "ignored", "measured", "filtered"]}
    record["skip_and_ignore_lines"] = [line for line in clean.splitlines() if re.search(r"# SKIP| # TODO| \.\.\. ignored|^test result:|^[#ℹ]\s*(skipped|cancelled|todo) ", line)]
    record["failure_lines"] = [line for line in clean.splitlines() if re.search(r"^not ok|^✖|^error(?:\[|:)|FAILED|^failures:|panicked at", line)]
    record["passed"] = (record["exit_code"] == 0 and record["source_preserved"] and record["runtime_preserved"]
                        and record["driver_preserved"] and record.get("native_mcp_preserved", True))
    save(f"{name}.json", record)
    RESULTS.append(record)
    save("results.json", RESULTS)
    print(f"END {name}: exit={record['exit_code']} seconds={record['elapsed_seconds']} preserved={record['source_preserved']}", flush=True)
    if not record["source_preserved"] or not record["runtime_preserved"]:
        raise RuntimeError(f"Preservation failure after {name}; no repair attempted")
    return record

assert (ROOT / "node_modules").is_dir() and (ROOT / "apps/web/node_modules").is_dir()
native = run("00-native-mcp", "cargo build --locked -p crony-gateways --bin crony-mcp",
             [CARGO, "build", "--locked", "-p", "crony-gateways", "--bin", "crony-mcp"])
if native["passed"]:
    ENV["CRONY_MCP_TEST_BINARY"] = str(TARGET / "debug/crony-mcp.exe")
    assert Path(ENV["CRONY_MCP_TEST_BINARY"]).is_file()
    save("native-mcp-binding.json", {"path": ENV["CRONY_MCP_TEST_BINARY"],
        "sha256": sha(Path(ENV["CRONY_MCP_TEST_BINARY"]).read_bytes()),
        "build_receipt": "00-native-mcp.json", "tree": EXPECTED_TREE, "head": EXPECTED_HEAD,
        "bound_at": now()})
else:
    raise RuntimeError("Native MCP build failed; refusing skipped native Node cases")
commands = [
    ("01-migrations", "node tools/check_migrations.mjs", [NODE, "tools/check_migrations.mjs"]),
    ("02-docs", "pnpm check:docs", [NODE, PNPM, "check:docs"]),
    ("03-unit", "pnpm test:unit", [NODE, PNPM, "test:unit"]),
    ("04-steward", "pnpm test:steward", [NODE, PNPM, "test:steward"]),
    ("05-fmt", "cargo fmt --check", [CARGO, "fmt", "--check"]),
    ("06-clippy", "cargo clippy --workspace --all-targets -- -D warnings", [CARGO, "clippy", "--workspace", "--all-targets", "--", "-D", "warnings"]),
    ("07-cargo-test", "cargo test --workspace", [CARGO, "test", "--workspace"]),
    ("08-web-build", "pnpm build:web", [NODE, PNPM, "build:web"]),
    ("09-web-lint", "pnpm lint:web", [NODE, PNPM, "lint:web"]),
]
for name, label, args in commands:
    run(name, label, args, required=True)
run("10-focused", "16 focused canary/scanner tests", [NODE, "--test", "--test-reporter=tap",
    "scenarios/factory-live-canary/status.test.mjs", "scenarios/factory-live-canary/git-bytes.test.mjs",
    "tools/check_evidence_personal_paths.test.mjs"])
run("11-default-scan", "Default current-public scan", [NODE, "tools/check_evidence_personal_paths.mjs"])
run("12-explicit-scan", "Explicit current-public packets scan", [NODE, "tools/check_evidence_personal_paths.mjs",
    "docs/evidence/pr226-integration-20260921", "docs/evidence/pr226-local-validation",
    "docs/evidence/pr-226-completion-20260922-r3"])
run("13-report-scan", "Explicit current dated-report matcher", [NODE, "--input-type=module", "-e",
    "import{readFileSync}from'node:fs';import assert from'node:assert/strict';import{hasPersonalUserPath}from'./tools/check_evidence_personal_paths.mjs';assert.equal(hasPersonalUserPath(readFileSync('docs/evidence/2026-09-12-pr226-exact-git-bytes.md','utf8')),false);console.log('Dated report: no personal user-root paths');"])
run("14-diff-check", "git diff --check", [GIT, "diff", "--check"])
run("15-target-diff-check", f"git diff --cached --check {BASE}", [GIT, "diff", "--cached", "--check", BASE])
run("16-pending-diff-check", "git diff --cached --check HEAD", [GIT, "diff", "--cached", "--check", "HEAD"])
public_roots = sorted({str(Path(p).parent) for p in
    git("diff", "--cached", "--name-only", "-z", BASE, "--", "docs/evidence").decode().split("\0")[:-1]
    if p.endswith("/README.md")})
public_roots.append("docs/evidence/assets/pr226-local-validation")
run("17-all-public-scan", "All contributed public evidence packet roots", [NODE, "tools/check_evidence_personal_paths.mjs", *public_roots])
rust_output = (OUT / "07-cargo-test.stdout.log").read_text(encoding="utf-8")
receipt_source = (ROOT / "crates/crony-store/src/retained_provider_receipt.rs").read_text(encoding="utf-8")
new_tests = re.findall(r"#\[test\]\s+fn (upload_binding_\w+)\(", receipt_source)
observed = {name: f"test retained_provider_receipt::tests::{name} ... ok" in rust_output for name in new_tests}
save("new-main-receipt-tests.json", {"source_sha256": BASELINE["tracked_files"]["crates/crony-store/src/retained_provider_receipt.rs"],
    "expected": new_tests, "observed_passes": observed,
    "passed": len(new_tests) == 5 and all(observed.values()),
    "rust_log_sha256": sha((OUT / "07-cargo-test.stdout.log").read_bytes())})
save("source-after.json", source())
save("summary.json", {
    "completed_at": now(), "head": EXPECTED_HEAD, "candidate_tree": EXPECTED_TREE, "target": BASE,
    "required_executed": len([r for r in RESULTS if r["required"]]),
    "required_passed": len([r for r in RESULTS if r["required"] and r["passed"]]),
    "all_passed": all(r["passed"] for r in RESULTS),
    "source_preserved": source() == BASELINE,
    "new_main_receipt_tests_passed": len(new_tests) == 5 and all(observed.values()),
    "commands": [{k: r[k] for k in ["name", "label", "exit_code", "elapsed_seconds", "passed"]} for r in RESULTS],
    "authority": "Automated author-delegate validation only; not independent approval, not issue #225 closure/native Factory acceptance",
})
