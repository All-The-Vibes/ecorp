"""Private command receipts for the explicitly author-side review."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
V=Path(__file__).resolve().parent
E=json.loads((V/'environment.json').read_bytes())
ENV=E['environment']
ROOT=Path(E['cwd'])
BASELINE=json.loads((V/'source-before.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,value):
    (V/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def capture(argv):
    return subprocess.check_output(argv,cwd=ROOT,env=ENV,creationflags=subprocess.CREATE_NO_WINDOW)
GIT=E['tools']['files']['git']['path']
NODE=E['tools']['files']['node']['path']
PNPM=E['tools']['files']['pnpm_entry']['path']
def snapshot():
    return {
        'head':capture([GIT,'rev-parse','HEAD']).decode().strip(),
        'branch':capture([GIT,'symbolic-ref','HEAD']).decode().strip(),
        'index_sha256':sha(Path(BASELINE['index_path']).read_bytes()),
        'files':{p:sha((ROOT/p).read_bytes()) for p in BASELINE['tracked_files']},
        'status':capture([GIT,'status','--porcelain=v1','--untracked-files=all']).decode(),
        'merge_head':capture([GIT,'rev-parse','MERGE_HEAD']).decode().strip(),
        'git_control_files':{name:{'path':item['path'],'sha256':sha(Path(item['path']).read_bytes()) if Path(item['path']).is_file() else None}
                             for name,item in BASELINE['git_control_files'].items()},
        'refs_sha256':sha(capture([GIT,'for-each-ref','--format=%(refname) %(objectname)'])),
    }
def runtime():
    result={'files':{k:{'path':r['path'],'sha256':sha(Path(r['path']).read_bytes())} for k,r in E['tools']['files'].items()}}
    commands={'node':[NODE,'--version'],'python':[sys.executable,'--version'],'pnpm':[NODE,PNPM,'--version'],
              'cargo':[E['tools']['files']['cargo']['path'],'--version'],
              'rustc':[E['tools']['files']['rustc']['path'],'--version'],'git':[GIT,'--version']}
    result['versions']={k:capture(a).decode().strip() for k,a in commands.items()}
    return result
commands=[('19-terminal-audit',[sys.executable,'-B',str(V/'audit-r8.py')])]
for name,argv in commands:
    before=snapshot()
    assert before['files']==BASELINE['tracked_files'] and before['index_sha256']==BASELINE['index_sha256']
    assert before['head']==BASELINE['head'] and before['branch']==BASELINE['branch'] and before['status']==BASELINE['status']
    assert before['merge_head']==BASELINE['merge_head'] and before['git_control_files']==BASELINE['git_control_files']
    assert before['refs_sha256']==BASELINE['refs_sha256']
    write(name+'.before.json',before)
    record={'name':name,'argv':argv,'cwd':str(ROOT),'started_at_utc':now(),
            'driver':str(Path(__file__).resolve()),'driver_sha256':sha(Path(__file__).read_bytes()),
            'check_script_sha256':sha((V/'audit-r8.py').read_bytes()),
            'copied_driver':str(V/'run-author-checks-r8.py'),
            'copied_driver_sha256':sha((V/'run-author-checks-r8.py').read_bytes()),
            'audit_helper_authored_here':True,
            'interpreter':sys.executable,'runtime_before':runtime(),
            'source_before':name+'.before.json','source_after':name+'.after.json',
            'candidate_tree':BASELINE['staged_tree'],'environment':ENV,
            'attribution':{'actor':'Codex automated verifier operating as author delegate',
                           'thread_id':os.environ.get('CODEX_THREAD_ID'),'independent':False,'human':False}}
    write(name+'.json',record)
    start=time.monotonic()
    with (V/(name+'.stdout.log')).open('xb') as out,(V/(name+'.stderr.log')).open('xb') as err:
        process=subprocess.run(argv,cwd=ROOT,env=ENV,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
                               creationflags=subprocess.CREATE_NO_WINDOW)
    record.update(exit_code=process.returncode,ended_at_utc=now(),elapsed_seconds=time.monotonic()-start)
    after=snapshot();write(name+'.after.json',after)
    record['source_preserved']=before==after
    record['runtime_after']=runtime()
    record['runtime_preserved']=record['runtime_before']==record['runtime_after']
    record['driver_preserved']=record['driver_sha256']==sha(Path(__file__).read_bytes())
    record['check_script_preserved']=record['check_script_sha256']==sha((V/'audit-r8.py').read_bytes())
    record['logs']={stream:{'path':name+'.'+stream+'.log','sha256':sha((V/(name+'.'+stream+'.log')).read_bytes()),
                           'bytes':(V/(name+'.'+stream+'.log')).stat().st_size} for stream in ['stdout','stderr']}
    write(name+'.json',record)
    print(name,process.returncode,'preserved',record['source_preserved'],flush=True)
    assert record['source_preserved'] and record['runtime_preserved']
