# PR226 round-8 private verification

## Verdict

**PARTIAL overall preservation; PASS fresh validation (9/9) and AUTHOR-DELEGATE self-review.**
All 1,148 tracked PR226 inputs, index bytes, HEAD, pending tree, MERGE_HEAD, merge-control files,
configuration and selected PR226/main/tracking refs remain unchanged. The whole shared repository's
ref namespace did not: another PR362 branch was created, then Codex turn-diff metadata refs changed.
The initial exit-1 audit and failed one-branch-only reconciliation remain failed and retained.
This is not a failed product test, and no test/assertion/timeout was weakened to obtain the nine passes.

## Exact input

- HEAD: `91a5b4e58a13eb0128f3f69beedcb9bd174fbb23` (local unpublished correction commit).
- Pending merged tree: `2cf0ea4851f09cbdb7cf3f08a6c3422abda416a8`.
- MERGE_HEAD / reviewed target: `08b0b89b2dd16c1906c9dd3468c5ddecca24c4ce`.
- This run executed the actual merged worktree. No c71eec9 receipt substitution.
- The staged tree was reconstructed in memory from index entries; no `git write-tree`, staging,
  source edit, merge commit, push, or ref-mutating Git command was used.
- Read root AGENTS, tools/web AGENTS, all four contracts and relevant test entrypoints.

## Fresh required commands

| Command | Exit | Complete actual result | Seconds |
|---|---:|---|---:|
| `node tools/check_migrations.mjs` | 0 | 41 immutable migrations | 0.156 |
| `pnpm check:docs` | 0 | 5 validation documents; 2 runtime documents; 9 marked commands | 1.000 |
| `pnpm test:unit` | 0 | 1259 passed / 0 failed / 0 skipped | 50.829 |
| `pnpm test:steward` | 0 | 227 passed / 0 failed / 0 skipped | 56.782 |
| `cargo fmt --check` | 0 | Passed | 3.438 |
| `cargo clippy --workspace --all-targets -- -D warnings` | 0 | Passed | 54.265 |
| `cargo test --workspace` | 0 | 571 passed / 0 failed / 343 ignored; zero filtered | 727.328 |
| `pnpm build:web` | 0 | TypeScript + Vite passed; 57 modules | 13.485 |
| `pnpm lint:web` | 0 | 0 warnings / 0 errors; 58 files | 4.938 |

All command records contain full argv, selected tool identities/hashes, actual driver hash, timestamps,
raw stream hashes and before/after complete tracked-source/index/merge/ref snapshots. `results.json`
and the individual `01-` through `09-` JSON/logs are the evidence, not historical reports.

## Additional executed proof

- Native `cargo build --locked -p crony-gateways --bin crony-mcp`: exit 0. Its exact binary hash was
  bound before Node tests (`native-mcp-binding.json`); 43 compiled-native MCP cases ran inside the
  1,259-test Node suite, with no skips. These use synthetic owned endpoints, not shared-stack acceptance.
- Focused canary/scanner suite: **16 passed, zero failed/skipped** (`10-focused`).
- Default public scan, explicit current packet scan, dated-report matcher and all six contributed
  public evidence roots: exit 0, no findings (`11`, `12`, `13`, `17`). This is not OCR or an exhaustive
  personal-data guarantee.
- Normal configured `git diff --check`, staged diff check against target 08b0b89 and staged pending
  merge diff check against HEAD: all exit 0 (`14`, `15`, `16`); no whitespace config override.
- All five new-main `retained_provider_receipt::tests::upload_binding_*` cases appear as `... ok`
  in the fresh full Rust log. Store: **66 passed / 337 ignored**; runner: **212 / 1**;
  server: **130 / 5**; other suites add 163 passes; doc-test suites complete with zero tests.
- Full terminal-log audit reads **249,126 raw bytes** and reconciles individual pass/ignored lines
  with terminal totals. All 343 ignored cases remain unexecuted: 342 owned-database/SQLx cases and
  one explicitly selected stopped-session probe. No DB/provider/browser/Factory acceptance is claimed.
- Genuine full author contribution review: **276 files / 5,943,365 bytes**, 387 executed assertions;
  see `author-self-review.md`, `author-checks-result-r8.json` and `18-author-checks-r8.json`.

## Environment and preservation

Node 24.19.0, pnpm 11.19.0, Python 3.12.14, Rust/Cargo 1.98.1 and Git 2.55.0.windows.5 were
actually resolved and hash-bound. Pinned Node was first in PATH; the installed npm shim stayed
available. Existing dependencies were sufficient; no restore, dependency addition, account,
credential, model, ACL, global TEMP, Git settings, test or timeout change was made.

The verified owned `C:/LOCAL/actor/q70ab6` TEMP/TMP retained its owner marker and inherited ACL.
Its 141 existing pre-Rust file hashes and directories are preserved. No alias or protected
`C:/Windows/Temp` access was attempted. Only process-local native `core.longpaths=true` was set.
`RUST_TEST_THREADS=1` and `CARGO_BUILD_JOBS=2` match the authorized configuration. Native Cargo reused
only the designated same-worktree target and rebuilt the changed store/server inputs. No cache was
borrowed, deleted or purged. Shared API8791/web5187/DB54329 were not used.

### Shared-ref audit discrepancy (not erased)

Every gate and the author-review command matched the complete original ref digest before and after.
During the later terminal audit, reflog records the unrelated PR362 branch creation at
September 22, 2026, 17:48:55 -0500. Removing only that added line **in memory** exactly reconstructs
the original full-ref digest. The first audit remains exit 1. A new copied reconciliation driver
then failed preflight because native Codex turn-diff refs had also been added/removed; its helper
never executed. `external-ref-observation-2.json` identifies all five observed differences.
No refs were restored or edited. No generic ignore was used to turn those global assertions green.

`final-readback.json` separately passes 197 narrowly stated checks of the exact requested PR226
source, index, merge metadata, tool bytes, logs, short TEMP and selected refs while explicitly
reporting `whole_repository_refs_unchanged: false`. This does not relabel the global failures.
Local tracking refs are not a fresh remote GitHub fence.

## Gaps and retained authority

No remaining local nine-gate or author-source proof gap. Whole-repository ref preservation is
**not established and was observably false** because of concurrent shared-repository activity.
No independent reviewer, human decision, Santa/NICE/SAFE approval, hosted CI, live remote re-fence,
other-OS/MSRV rerun, opt-in SQLx/provider probe, browser, Factory closure or publication is supplied.
The parent retains publication/images, independent review and remote re-fencing. No public report
or new image was produced. Raw private receipts are intentionally not sanitized for publication.
