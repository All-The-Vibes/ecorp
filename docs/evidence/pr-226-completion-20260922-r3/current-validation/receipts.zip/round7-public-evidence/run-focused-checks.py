from pathlib import Path
import os,subprocess,json,datetime
s=Path(r'C:/LOCAL/actor/repos/ecorp/output/pr-gauntlet-20260922/pr226/round7-public-evidence')
commands=[
 ('scanner-syntax',['node','--check','tools/check_evidence_personal_paths.mjs']),
 ('scanner-test-syntax',['node','--check','tools/check_evidence_personal_paths.test.mjs']),
 ('focused',['node','--test','--test-reporter=tap','scenarios/factory-live-canary/status.test.mjs','scenarios/factory-live-canary/git-bytes.test.mjs','tools/check_evidence_personal_paths.test.mjs']),
 ('default-public-scan',['node','tools/check_evidence_personal_paths.mjs']),
 ('r3-public-scan',['node','tools/check_evidence_personal_paths.mjs','docs/evidence/pr-226-completion-20260922-r3']),
 ('dated-report-scan',['node','--input-type=module','-e',"import { readFileSync } from 'node:fs'; import assert from 'node:assert/strict'; import {hasPersonalUserPath} from './tools/check_evidence_personal_paths.mjs'; assert.equal(hasPersonalUserPath(readFileSync('docs/evidence/2026-09-12-pr226-exact-git-bytes.md','utf8')),false); console.log('Dated report: no personal user-root paths');"]),
 ('default-diff-check',['git','diff','--check']),
 ('target-default-diff-check',['git','diff','--check','de12261d045ddfccf790bcfd04a7fa254563d456']),
 ('scoped-attributes',['git','check-attr','text','whitespace','--','docs/evidence/pr226-integration-20260921/README.md','docs/evidence/pr226-integration-20260921/path-normalization-20260922.json']),
]
env={k:v for k,v in os.environ.items() if k.upper() in ['PATH','PATHEXT','SYSTEMROOT','WINDIR','TEMP','TMP','COMSPEC','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMFILES','PROGRAMFILES(X86)','PROGRAMDATA','HOMEDRIVE','HOMEPATH']}; env['GIT_OPTIONAL_LOCKS']='0'
records=[]
for name,args in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=120)
 (s/(name+'.stdout.log')).write_bytes(r.stdout); (s/(name+'.stderr.log')).write_bytes(r.stderr)
 records.append({'name':name,'argv':args,'started_at_utc':start,'exit_code':r.returncode}); print(name,r.returncode)
(s/'focused-checks.json').write_text(json.dumps(records,indent=2)+'\n')
assert all(r['exit_code']==0 for r in records)
