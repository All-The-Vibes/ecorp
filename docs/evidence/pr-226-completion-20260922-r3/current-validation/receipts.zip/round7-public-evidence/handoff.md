# PR226 round7 public-evidence correction handoff

Status: locally verified bounded correction; not published, independently approved, NICE, or nine-gate validated.
Base HEAD: `9d79db02c814497f93eed4b8d7c842cb2518d153`. Branch remains `codex/pr226-r7-public-evidence-20260922`.
Target ancestor: `de12261d045ddfccf790bcfd04a7fa254563d456`.

## Deliverable

- Full-index binary patch: `pr226-r7-public-evidence.full-index.patch` (334033 bytes).
- SHA-256: `af7846dc861fbf30692d2ac8f0e5dc6efd444005f9b08004533d25122d55dba7`.
- Exact paths: `changed-files.txt` (10 modified + 2 new).
- Forward index **check-only** and reverse working-tree check both exit 0. No staging or index write.

## Scope and actual ordered regression

1. Added only the r3 inclusion assertion to the existing retained-packet test: `scanner-coverage-red.log` is behavioral RED (exit 1: missing r3 default).
2. Added the one bounded default root: `scanner-covered-leak-red.log` is behavioral RED (exit 1: actual r3 root-before.log leak).
3. Replaced exactly two user-root spans in the public log, retaining all other bytes: `scanner-green.log`, six tests pass.
4. Replaced only three user-root spans in the dated report; original LF Git vs CRLF checkout identities are explicitly distinguished in r3 provenance.
5. Published a clearly labelled derivative of the actual failed launch. Five user-root rectangles plus one disclosure-label rectangle; all other pixels identical. Original raw PNG retained in private-originals and immutable Git. No OCR.
6. Added genuine unedited Edge screenshot of a small static report: existing before RED (4 pass/2 fail), intermediate failure (4/2), after GREEN (6/0), and receipt reference (3 checks/5 artifacts). Hash-bound original/current public inputs shown. No rerun/chronology claim.
7. Added only two `whitespace=cr-at-eol` attributes. Historical normalization manifest unchanged; integration README existing bytes preserved as prefix with explicit appended correction. Current derivative/README hashes live in terminal-provenance, separate from historical hashes.

## Verification

- `focused-checks.json` and associated stdout/stderr: two Node syntax checks; 16 focused canary/scanner tests pass, zero skipped; default and explicit r3 scans and dated-report matcher check pass; plain `git diff --check` and `git diff --check de12261d045ddfccf790bcfd04a7fa254563d456` pass without configuration overrides; scoped attributes verified.
- Before: `default-diff-before.log`, exit 2 with 272 trailing-whitespace diagnostics. After: both default diff checks exit 0, empty stdout/stderr.
- `provenance-and-preservation.json`: 126 assertions pass: all affected public hashes, retained r2/r3 references, historical manifest and README identities, original identity fields, source/index preservation and pixel bounds.
- Real index SHA-256 unchanged: `6f49acbe0a300edffb260efe6d751f8589a0b257ecd59f8a17714443a389613a`.
- 1071 other tracked files unchanged byte-for-byte; canary status/README index and working copies satisfy the original required hashes.
- Both images visually inspected. Browser capture provenance: `saved-report-browser-capture.json`; successful installed Edge version 153.0.4234.48 via bundled Playwright 1.62.1. Initial bundled Chromium lookup failed before capture; `browser-capture.log` retained, no install. Driver remains private scratch, not a new repository harness.

## Preservation and remaining ownership

All old worktrees, receipts, raw histories and source IDs untouched. Historical original r3 raw-log hashes remain identity records; the old private completion archive was not accessed or regenerated. Prior public log/report bytes and original PNG are separately retained here and bound to immutable Git. Private scratch uses inherited ACLs; no ACL/security changes.

No product/Factory/shared-stack/provider work, child agents, staging, commit, push, full-nine run, or regeneration of old receipts. The parent's independently reconstructed historical tree `7bdeb42dbda78174e96e54932797681a1fbcafc6` remains historical proof, not validation of this scanner correction. Parent must re-fence concurrent author changes, run combined validation and independent review, then decide publication. The patch and private raw copies contain old personal paths and must remain private; corrected public files alone are publication candidates.

## Exact changed files

- `docs/evidence/2026-09-12-pr226-exact-git-bytes.md`
- `docs/evidence/pr-226-completion-20260922-r3/README.md`
- `docs/evidence/pr-226-completion-20260922-r3/correction-provenance.json`
- `docs/evidence/pr-226-completion-20260922-r3/root-before.log`
- `docs/evidence/pr-226-completion-20260922-r3/saved-correction-results.html`
- `docs/evidence/pr-226-completion-20260922-r3/saved-correction-results.png`
- `docs/evidence/pr226-integration-20260921/.gitattributes`
- `docs/evidence/pr226-integration-20260921/README.md`
- `docs/evidence/pr226-integration-20260921/prior-attempts/capture-launch-v1-failed.png`
- `docs/evidence/pr226-integration-20260921/terminal-provenance.json`
- `tools/check_evidence_personal_paths.mjs`
- `tools/check_evidence_personal_paths.test.mjs`
