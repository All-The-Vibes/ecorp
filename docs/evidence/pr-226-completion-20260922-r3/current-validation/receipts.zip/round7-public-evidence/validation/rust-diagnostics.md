# PR226 Rust failure classification and bounded readback

The original nine-gate run remains **8/9**, with `cargo test --workspace` exiting
**101**. Its complete raw logs and receipt are unchanged. Reported Rust totals
are **366 passed, 9 failed, 1 ignored**, across reached suites only. Cargo stopped
after the runner binary; server/store/doc-test suites were not reached.

## Preconditions recorded before reruns

`rust-rerun-preconditions.json` records the inspected installed Git manual,
versions, exact binary hash, intended diagnostic commands and source boundary.

- Canonical owned OS temp:
  `C:\LOCAL\actor\AppData\Local\Temp\v226-2c382rdy` (52 characters).
- Target: the fresh `validation/cargo-target` owned solely by this source.
- Exact runner test binary SHA-256:
  `22ab40a5ea2a4896f13f2d32e1a2f50e9e17fe6b40a51ee393f534d3cb36a784`.
- Git: `2.55.0.windows.5`; ordinary effective `core.longpaths` lookup was unset
  (exit 1, empty output). The installed manual documents the native Windows
  option. No global, system or repository configuration was written.
- TEMP, source, target, test binary, test assertions, concurrency, timeout and
  inherited ACLs remained the same. Only private tracing, and for the two
  explicitly labelled diagnostics native process-scoped long-path support,
  were added.

## Actual terminal outcomes

| Receipt | Command scope | Exit | Actual outcome |
|---|---|---:|---|
| `20-late-stop-original-trace.json` | Exact existing late-stop test; original Git environment plus private trace | 101 | 0 passed, 1 failed, 212 filtered |
| `21-workspace-native-longpaths.json` | Exact existing workspace provisioning test; native process-only `core.longpaths=true` | 101 | 0 passed, 1 failed, 212 filtered |
| `22-late-stop-native-longpaths.json` | Same exact late-stop test/binary; native process-only `core.longpaths=true` | 0 | 1 passed, 0 failed, 212 filtered |

These are diagnostic selections, not a rerun of the complete contributor gate.
Their counts are not added to baseline totals.

## What the evidence proves

1. **Eight workspace failures remain blocked by native Git path handling.**
   The original log contains eight `fatal: '$GIT_DIR' too big` errors.
   The representative unchanged provisioning test still fails with that error
   after the documented native process option. Its trace identifies the failing
   child as `git reset --hard --no-recurse-submodules` during `git worktree add`.
   Importantly, current `workspace.rs:1467-1474` already supplies
   `-c core.longpaths=true` on Windows. The trace confirms that existing argument.
   Merely setting the option again is not a fix for these failures.

2. **The late-stop unwrap now has direct causal evidence.**
   The original-environment exact-binary trace shows `git bundle create`
   failing with exit 128 and `failed to stat 'refs/ecorp/deliverables/...':
   Filename too long`, before the expected deliverable-upload event.
   The channel then closes and the test unwraps `None` at
   `source_checkpoint.rs:674`. The same exact binary and assertion pass with
   native process-scoped long-path support. This classifies this fixture failure;
   it does not repair source or make the full Rust gate pass.

3. **No sibling npm failure was imported.**
   This run's log explicitly reports
   `verifier::tests::windows_installed_npm_shim_runs_incident_command_policy ... ok`.
   Its normal PATH was preserved.

4. **These implementation files are unchanged from the tested target.**
   Read-only comparison against `de12261d045ddfccf790bcfd04a7fa254563d456`
   reports no delta for workspace, source-checkpoint or deliverable code.
   This does not establish how a different host or newer main would behave.

Because the representative workspace case still fails, the documented condition
for a further full workspace rerun was not met. No speculative TEMP relocation,
test/filter alteration, ACL change or global-config/security workaround followed.
The frozen candidate, source/index and all failed evidence remain preserved.

## Parent update boundary

The parent reported main at
`08b0b89b2dd16c1906c9dd3468c5ddecca24c4ce` after external PR338 merge and PR226
remote still at `9d79db`. These are recorded as parent-supplied facts, not a new
remote fence by this validator. No merge or source change was performed.
Validation remains bound to the supplied candidate and `de122...` ancestor.
The sibling's model-transport failure is not evidence about this run and is not
represented as a reviewer completion.
