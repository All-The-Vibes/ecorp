"""Rerun the full unchanged Rust gate after the native short-temp control passed."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "full-rust"
OUT.mkdir()
WORK = Path("C:/LOCAL/actor/repos/ecorp/worktrees/pr226-r7-public-evidence")
old = json.loads((ROOT.parent / "validation/07-cargo-test.json").read_bytes())
probe = json.loads((ROOT / "result.json").read_bytes())
assert probe["exit"] == 0 and probe["source_and_index_unchanged"]
temp = Path(json.loads((ROOT / "root.json").read_bytes())["root"])
assert temp.is_dir() and (temp / ".owner.json").is_file()
env = {key: str(value) for key, value in old["environment"].items() if value is not None}
env.update(TEMP=str(temp), TMP=str(temp), GIT_CONFIG_COUNT="1",
           GIT_CONFIG_KEY_0="core.longpaths", GIT_CONFIG_VALUE_0="true",
           RUST_TEST_THREADS="1")
env.pop("GIT_TRACE", None)
cargo = Path("C:/LOCAL/actor/.rustup/toolchains/1.98.1-x86_64-pc-windows-msvc/bin/cargo.exe")
rustc = cargo.with_name("rustc.exe")
argv = [str(cargo), "test", "--workspace"]
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot():
    def git(*args):
        return subprocess.check_output(["git", "--no-optional-locks", "-C", str(WORK), *args])
    entries = git("ls-files", "-z").split(b"\0")
    files = {}
    for raw in filter(None, entries):
        path = WORK / os.fsdecode(raw)
        assert path.is_file() and not path.is_symlink()
        files[os.fsdecode(raw)] = sha(path)
    index = Path(os.fsdecode(git("rev-parse", "--path-format=absolute", "--git-path", "index")).strip())
    return {"head": git("rev-parse", "HEAD").decode().strip(),
            "stage_entries_sha256": hashlib.sha256(git("ls-files", "-s", "-z")).hexdigest(),
            "index_sha256": sha(index), "tracked_files": files}


before = snapshot()
binding = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "argv": argv, "cwd": str(WORK), "source_before": before,
           "driver_sha256": sha(__file__), "python_sha256": sha(sys.executable),
           "cargo_sha256": sha(cargo), "rustc_sha256": sha(rustc),
           "cargo_version": subprocess.check_output([str(cargo), "--version"], env=env).decode().strip(),
           "rustc_version": subprocess.check_output([str(rustc), "--version"], env=env).decode().strip(),
           "temp": str(temp), "target": env["CARGO_TARGET_DIR"],
           "changes_from_original_run": "Owned shorter user TEMP/TMP and native process-only Git longpaths; no source/assertion/ACL/global config change",
           "original_run_preserved": True}
(OUT / "before.json").write_text(json.dumps(binding, indent=2) + "\n")
with (OUT / "stdout.log").open("xb") as stdout, (OUT / "stderr.log").open("xb") as stderr:
    child = subprocess.Popen(argv, cwd=WORK, env=env, stdout=stdout, stderr=stderr,
                             creationflags=subprocess.CREATE_NO_WINDOW)
    (OUT / "process.json").write_text(json.dumps({"pid": child.pid, "argv": argv}) + "\n")
    exit_code = child.wait()
after = snapshot()
(OUT / "after.json").write_text(json.dumps(after, indent=2) + "\n")
result = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "exit_code": exit_code, "source_and_index_unchanged": before == after,
          "driver_unchanged": sha(__file__) == binding["driver_sha256"],
          "cargo_unchanged": sha(cargo) == binding["cargo_sha256"],
          "rustc_unchanged": sha(rustc) == binding["rustc_sha256"],
          "stdout_sha256": sha(OUT / "stdout.log"),
          "stderr_sha256": sha(OUT / "stderr.log"),
          "source_scope": "Original PR226 R7 candidate c71eec9 on9d79db, before new main integration",
          "limits": "No new-source, database opt-in, provider, Factory, Santa or publication approval"}
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(0 if exit_code == 0 and result["source_and_index_unchanged"] else 1)
