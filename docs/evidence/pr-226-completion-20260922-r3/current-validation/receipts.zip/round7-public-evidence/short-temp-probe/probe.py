"""One unchanged native test binary, under a new owned user temporary directory."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
WORK = Path("C:/LOCAL/actor/repos/ecorp/worktrees/pr226-r7-public-evidence")
VALIDATION = OUT.parent / "validation"
receipt = json.loads((VALIDATION / "07-cargo-test.json").read_bytes())
root = Path(json.loads((OUT / "root.json").read_bytes())["root"])
assert root.is_dir() and (root / ".owner.json").is_file()
environment = {key: str(value) for key, value in receipt["environment"].items()
               if value is not None}
environment.update(TEMP=str(root), TMP=str(root), GIT_CONFIG_COUNT="1",
                   GIT_CONFIG_KEY_0="core.longpaths", GIT_CONFIG_VALUE_0="true",
                   GIT_TRACE=str(OUT / "git.trace.log"), RUST_TEST_THREADS="1")
binary = Path(environment["CARGO_TARGET_DIR"]) / "debug/deps/crony_runner-87f899cdec9d59fe.exe"
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(binary) == "22ab40a5ea2a4896f13f2d32e1a2f50e9e17fe6b40a51ee393f534d3cb36a784"
argv = [str(binary),
        "workspace::tests::provisions_distinct_worktrees_without_touching_source_checkout",
        "--exact", "--nocapture", "--test-threads=1"]


def snapshot():
    def git(*args):
        return subprocess.check_output(["git", "--no-optional-locks", "-C", str(WORK), *args])
    paths = git("ls-files", "-z").split(b"\0")
    files = {}
    for raw in filter(None, paths):
        path = WORK / os.fsdecode(raw)
        assert path.is_file() and not path.is_symlink()
        files[os.fsdecode(raw)] = sha(path)
    index = Path(os.fsdecode(git("rev-parse", "--path-format=absolute", "--git-path", "index")).strip())
    return {"head": git("rev-parse", "HEAD").decode().strip(),
            "index_sha256": sha(index), "tracked_files": files}


before = snapshot()
binding = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "argv": argv, "cwd": str(WORK), "binary_sha256": sha(binary),
           "driver_sha256": sha(__file__), "temp": str(root),
           "process_only_git_longpaths": True, "source_before": before,
           "scope": "one inert workspace fixture test; no source or ACL changes"}
(OUT / "before.json").write_text(json.dumps(binding, indent=2) + "\n")
result = subprocess.run(argv, cwd=WORK, env=environment, capture_output=True,
                        timeout=180, creationflags=subprocess.CREATE_NO_WINDOW)
(OUT / "stdout.log").write_bytes(result.stdout)
(OUT / "stderr.log").write_bytes(result.stderr)
after = snapshot()
output = result.stdout.decode("utf-8", "replace")
data = {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "exit": result.returncode, "one_case_passed": "1 passed; 0 failed;" in output,
        "source_and_index_unchanged": before == after,
        "binary_unchanged": sha(binary) == binding["binary_sha256"],
        "driver_unchanged": sha(__file__) == binding["driver_sha256"],
        "stdout_sha256": sha(OUT / "stdout.log"),
        "stderr_sha256": sha(OUT / "stderr.log"),
        "limit": "selected diagnostic only, not a full workspace or nine-gate pass"}
(OUT / "result.json").write_text(json.dumps(data, indent=2) + "\n")
print(json.dumps(data, indent=2))
print(output)
raise SystemExit(0 if result.returncode == 0 and data["one_case_passed"]
                 and data["source_and_index_unchanged"] else 1)
