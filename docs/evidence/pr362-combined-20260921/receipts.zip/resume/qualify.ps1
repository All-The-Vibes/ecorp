$Host.UI.RawUI.WindowTitle='PR362 resumed capture qualification - no test executed'
Write-Host 'PR362 NEW background capture surface; no old PID/HWND reused.'
Write-Host ('Qualification UTC '+[DateTime]::UtcNow.ToString('o'))
Write-Host 'Awaiting source/target qualification before actual commands.'
while(!(Test-Path (Join-Path $PSScriptRoot 'begin.txt'))){Start-Sleep -Milliseconds 500}
& (Join-Path $PSScriptRoot 'resume-gates.ps1')
