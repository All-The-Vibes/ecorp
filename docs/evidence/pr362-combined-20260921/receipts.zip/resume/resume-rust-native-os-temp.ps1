$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$root='<COMBINED_WORKTREE>'
$output=Join-Path $PSScriptRoot 'gates-native-os-temp'
if(Test-Path $output){throw 'Existing capture receipts; refusing overwrite'}
New-Item -ItemType Directory $output | Out-Null
Set-Location -LiteralPath $root
$Host.UI.RawUI.WindowTitle='PR362 RESUMED ACTUAL gates - unchanged assembled source'
$env:CARGO_BUILD_JOBS='2'
$env:CARGO_TARGET_DIR=Join-Path (Split-Path $PSScriptRoot) 'target-combined-only-922b790c'
if(!(Test-Path (Join-Path $PSScriptRoot 'resume-preflight.json'))){throw 'Missing source/binary validation'}
$env:CARGO_NET_OFFLINE='true'
$env:CARGO_PROFILE_DEV_DEBUG='0'
$env:CARGO_PROFILE_TEST_DEBUG='0'
$env:CARGO_INCREMENTAL='0'
$env:RUST_TEST_THREADS='2'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:ECORP_FACTORY_WATCH='0'
$env:CRONY_MCP_TEST_BINARY=$null
$env:DATABASE_URL=$null
$env:GIT_CONFIG_COUNT='1'
$env:GIT_CONFIG_KEY_0='core.longpaths'
$env:GIT_CONFIG_VALUE_0='true'
$env:TEMP=(Get-Content (Join-Path $PSScriptRoot 'native-os-temp-proof-private.json') -Raw | ConvertFrom-Json).temp
$env:TMP=$env:TEMP; $env:TMPDIR=$env:TEMP
if(!(Test-Path (Join-Path $PSScriptRoot 'temp-proof.json'))){throw 'Missing external temp proof'}
$inputs=Get-Content (Join-Path (Split-Path $PSScriptRoot) 'inputs-before.json') -Raw | ConvertFrom-Json
$inputHash=(Get-FileHash (Join-Path (Split-Path $PSScriptRoot) 'inputs-before.json')).Hash
$results=[Collections.Generic.List[object]]::new()
@{head=$inputs.head;staged_tree=$inputs.assembled_staged_tree;tested_inputs_sha256=$inputHash;target=$env:CARGO_TARGET_DIR;temp=$env:TEMP;git_longpaths=(& git config --get core.longpaths);cargo_jobs=2;rust_test_threads=2;node_test_concurrency='repository script default 2';profiles='dev/test debug=0, incremental=0';cargo_offline=$true;rust=(& rustc --version);cargo=(& cargo --version);node=(& node --version);pnpm=(& pnpm --version)} | ConvertTo-Json | Set-Content (Join-Path $output 'environment.json')
function Run([string]$Name,[string]$Program,[string[]]$Arguments){
 Clear-Host
 $start=[DateTime]::UtcNow
 $log=Join-Path $output "$Name.log"
 # Empty successful commands still require a real zero-length receipt.
 [IO.File]::WriteAllText($log,'')
 Write-Host "ACTUAL COMMAND: $Program $($Arguments -join ' ')"
 Write-Host "HEAD $($inputs.head) + STAGED TREE $($inputs.assembled_staged_tree)"
 Write-Host "TESTED INPUTS SHA256 $inputHash"
 Write-Host "START $Name $($start.ToString('o')) | jobs=2 rust-threads=2"
 # Stream live output to both file and console; never replay saved output for a picture.
 & $Program @Arguments 2>&1 | Tee-Object -FilePath $log | Out-Host
 $exit=$LASTEXITCODE
 $results.Add(@{name=$Name;program=$Program;arguments=$Arguments;cwd=$root;started_utc=$start.ToString('o');finished_utc=[DateTime]::UtcNow.ToString('o');exit_code=$exit;log="$Name.log";sha256=(Get-FileHash $log).Hash;bytes=(Get-Item $log).Length;head=$inputs.head;staged_tree=$inputs.assembled_staged_tree;tested_inputs_sha256=$inputHash})
 $results | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $output 'results.json')
 Write-Host "END $Name | ACTUAL EXIT $exit | $([DateTime]::UtcNow.ToString('o'))"
 Write-Host "HEAD $($inputs.head)"
 Write-Host "STAGED TREE $($inputs.assembled_staged_tree)"
 Write-Host "TESTED INPUTS SHA256 $inputHash"
 [IO.File]::WriteAllText((Join-Path $output 'ready.txt'),$Name)
 $deadline=[DateTime]::UtcNow.AddMinutes(30)
 while(!(Test-Path (Join-Path $output "$Name.continue"))){if([DateTime]::UtcNow -gt $deadline){throw 'Capture wait timeout'};Start-Sleep -Milliseconds 300}
}
Run '07-rust-native-os-temp' 'cargo' @('test','--workspace')
[IO.File]::WriteAllText((Join-Path $output 'complete.txt'),[DateTime]::UtcNow.ToString('o'))
