"""Diagnostic only: replay exact ACL snippet on two new owned empty directories."""
import os,re,json,hashlib,subprocess,datetime
from pathlib import Path
S=Path(__file__).parent; W=Path(r'<COMBINED_WORKTREE>')
p=W/'crates/crony-runner/src/connection_setup/storage.rs'; b=p.read_bytes()
script=re.search(r'let script = r#"(.*?)"#;',b.decode(),re.S)[1]
base=Path(r'<DRIVE_ROOT_TEMP>\acl-diagnostic-v2');base.mkdir(exist_ok=False)
rows=[]
for name,prefix in [('lexical',''),('canonical','\\\\?\\')]:
 d=base/name;d.mkdir(); env=os.environ.copy();env['ECORP_CONNECTION_ACL_TARGET']=prefix+str(d)
 exe=str(Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe')
 args=[exe,'-NoLogo','-NoProfile','-NonInteractive','-Command',script]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(args,cwd=d,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
 (S/f'acl-{name}.stdout.log').write_bytes(p.stdout);(S/f'acl-{name}.stderr.log').write_bytes(p.stderr)
 rows.append({'case':name,'argv':args,'cwd':str(d),'acl_target':env['ECORP_CONNECTION_ACL_TARGET'],'source_sha256':hashlib.sha256(b).hexdigest(),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':f'acl-{name}.stdout.log','stderr':f'acl-{name}.stderr.log'})
(S/'acl-diagnostic.json').write_text(json.dumps({'scope':'Exact source snippet, standalone diagnostic, not run_owned or a passing test. No retained failure fixture modified.','runs':rows},indent=2)+'\n')
for r in rows:print(r['case'],r['exit_code'],(S/r['stderr']).read_text())

