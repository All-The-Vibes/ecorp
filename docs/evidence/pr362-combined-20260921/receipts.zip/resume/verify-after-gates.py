import json,hashlib,subprocess,re
from pathlib import Path
S=Path(__file__).parent;I=S.parent;W=Path(r'<COMBINED_WORKTREE>');H=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((I/'inputs-before.json').read_bytes());pre=json.loads((S/'resume-preflight.json').read_bytes())
for n,v in x['files'].items():assert H((W/n).read_bytes())==v['working_sha256'],n
for n,h in pre['original_gate_receipts'].items():assert H((I/n).read_bytes())==h,n
G=lambda *a:subprocess.check_output(['git','-C',str(W),*a])
assert G('write-tree').decode().strip()==x['assembled_staged_tree']
assert G('diff','--cached','--binary','--',*x['source_paths'])==(I/'assembled-source.patch').read_bytes()
log=(S/'gates-native-os-temp/07-rust-native-os-temp.log').read_text();counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)]
assert len(counts)==14
out={'head':G('rev-parse','HEAD').decode().strip(),'staged_tree':x['assembled_staged_tree'],'tracked_inputs_verified':len(x['files']),'original_gate_receipts_unchanged':len(pre['original_gate_receipts']),'source_patch_sha256':H((I/'assembled-source.patch').read_bytes()),'rust_workspace_counts':{'passed':sum(t[0] for t in counts),'failed':sum(t[1] for t in counts),'ignored':sum(t[2] for t in counts)},'scope':'After all actual gates, before evidence-only public packaging. No source input drift.'}
(S/'source-after-gates.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
