import hashlib,json,subprocess,re
from pathlib import Path
S=Path(__file__).parent; I=S.parent; W=Path(r'<COMBINED_WORKTREE>')
H=lambda b:hashlib.sha256(b).hexdigest()
G=lambda *a:subprocess.check_output(['git','-C',str(W),*a])
old=json.loads((I/'inputs-before.json').read_bytes())
assert G('rev-parse','HEAD').decode().strip()==old['head']
assert G('write-tree').decode().strip()==old['assembled_staged_tree']
assert G('diff','--cached','--binary','--',*old['source_paths'])==(I/'assembled-source.patch').read_bytes()
for p,row in old['files'].items(): assert H((W/p).read_bytes())==row['working_sha256'],p
T=I/'target-combined-only-922b790c'
roots=set()
for p in (T/'debug').rglob('*.d'):
 text=p.read_text(errors='replace')
 roots.update(re.findall(r'<HOME>\\repos\\(ecorp[^\\ /:\n]*)',text))
assert roots=={W.name,'ecorp'},roots # ecorp is the exclusive target output, not an input source.
binaries=[{'path':str(p.relative_to(T)),'sha256':H(p.read_bytes()),'bytes':p.stat().st_size} for p in (T/'debug').rglob('*.exe')]
assert binaries
# Preserve all old capture receipts, including failed Rust and the last build image.
receipts={str(p.relative_to(I)):H(p.read_bytes()) for p in (I/'gates').rglob('*') if p.is_file()}
out={'head':old['head'],'staged_tree':old['assembled_staged_tree'],'input_manifest_sha256':H((I/'inputs-before.json').read_bytes()),'verified_files':len(old['files']),'source_patch_sha256':H((I/'assembled-source.patch').read_bytes()),'target':str(T),'depfile_repository_roots':sorted(roots),'target_binaries':binaries,'original_gate_receipts':receipts,'binary_qualification':'Existing source-exclusive target retained. Native cargo test --workspace --no-run must confirm current source/build artifacts before test execution.'}
(S/'resume-preflight.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS source/index unchanged:',len(old['files']),'files;',len(binaries),'target binaries hashed;',len(receipts),'prior receipts preserved')
