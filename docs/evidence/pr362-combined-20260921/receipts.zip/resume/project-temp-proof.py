import json,hashlib
from pathlib import Path
s=Path(__file__).parent
p=s/'native-os-temp-proof-private.json';v=json.loads(p.read_bytes());a=json.loads((s/'acl-readback-private.json').read_bytes())
owner=a['user_sid']; full=';FA;;;'+owner+')'
assert full in v['sddl'] and full not in a['paths'][0]['sddl']
o={k:v[k] for k in ['temp','length','ancestors','git_exit','git_output','scope']}
o['classification']='Authored diagnostic projection of retained private OS TEMP proof; account/SID/ACL text omitted, no test results omitted.'
o['private_original_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
o['acl_readback_private_sha256']=hashlib.sha256((s/'acl-readback-private.json').read_bytes()).hexdigest()
o['observed_acl_difference']='Native OS TEMP explicitly inherits user FullControl; drive-root temp does not. Unchanged source ACL snippet fails UnauthorizedAccessException in both lexical and canonical drive-root paths, succeeds in both native OS TEMP paths. No existing ACL or permission policy was changed.'
(s/'native-os-temp-proof-public-source.json').write_text(json.dumps(o,indent=2)+'\n')
