param([string]$Name)
$g=Join-Path $PSScriptRoot 'gates'
if((Get-Content (Join-Path $g 'ready.txt') -Raw) -ne $Name){throw 'Wrong completed gate'}
if(Test-Path (Join-Path $g "$Name.png")){throw 'Refuse overwrite'}
@{pid=13180;window_id=2623972;screenshot_out_file=(Join-Path $g "$Name.png")} | ConvertTo-Json -Compress | Tee-Object (Join-Path $g "$Name-cua-request.json") | cua-driver call get_window_state | Set-Content (Join-Path $g "$Name-cua.json")
if(!(Test-Path (Join-Path $g "$Name.png"))){throw 'No screenshot'}
