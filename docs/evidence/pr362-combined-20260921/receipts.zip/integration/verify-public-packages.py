"""Read-only check of PR362 public derivatives against retained private receipts."""
import hashlib,io,json,re,runpy,zipfile,sys
from pathlib import Path
from PIL import Image,ImageChops,ImageDraw
S=Path(__file__).parent
api=runpy.run_path(str(S/'package-owner-evidence.py'))
H=lambda b:hashlib.sha256(b).hexdigest()
base=Path(sys.argv[1]) if len(sys.argv)>1 else S/'public-packages'
verified=[]
for d in sorted(base.glob('pr362-*-20260921')):
 m=json.loads((d/'manifest.json').read_text())
 original=S/'owner-originals'/d.name
 if d.name=='pr362-startup-20260921':
  with zipfile.ZipFile(original/'receipts.zip') as z: raw={n:z.read(n) for n in z.namelist()}
  raw.update({'owner-manifest.json':(original/'manifest.json').read_bytes(),'owner-README.md':(original/'README.md').read_bytes()})
 elif d.name=='pr362-regressions-20260921':
  raw={p.relative_to(original).as_posix():p.read_bytes() for p in original.rglob('*') if p.is_file() and p.suffix!='.png'}
 else:
  source_map=json.loads((S/'combined-archive-sources.json').read_text())
  raw={n:(S/p).read_bytes() for n,p in source_map.items()}
 with zipfile.ZipFile(d/'receipts.zip') as z:
  api['safe'](z.namelist());assert z.testzip() is None
  assert sorted(z.namelist())==sorted(raw)==sorted(row['member'] for row in m['archive_members'])
  for row in m['archive_members']:
   n=row['member']; actual=z.read(n); expected,counts=api['redact_with_counts'](raw[n])
   assert actual==expected,('non-path/result alteration',d.name,n)
   assert H(raw[n])==row['raw_sha256'] and len(raw[n])==row['raw_bytes']
   assert H(actual)==row['public_sha256'] and len(actual)==row['public_bytes'] and counts==row['replacements']
   assert not re.search(rb'(?i)<LOCAL_USER_NAME>|C:(?:\\+|/)Users(?:\\+|/)',actual),n
   if n.endswith('.json'):json.loads(actual.decode('utf-8-sig'))
 for row in m['images']:
  p=d/row['path']; source=(S/row['raw_source']) if d.name=='pr362-combined-20260921' else original/p.name
  b=source.read_bytes(); public=p.read_bytes(); assert H(b)==row['raw_sha256'] and H(public)==row['public_sha256']
  assert len(b)==row['raw_bytes'] and len(public)==row['public_bytes']
  if not row['rectangles']: assert b==public
  else:
   a=Image.open(io.BytesIO(b)).convert('RGB'); c=Image.open(io.BytesIO(public)).convert('RGB')
   assert c.size==(a.width,a.height+22)
   delta=ImageChops.difference(a,c.crop((0,0,a.width,a.height)))
   for box in row['rectangles']: ImageDraw.Draw(delta).rectangle(box,fill=0)
   assert delta.getbbox() is None,('pixels outside privacy masks',p.name)
 for row in m['delivered_files']:
  b=(d/row['path']).read_bytes();assert H(b)==row['sha256'] and len(b)==row['bytes'],row['path']
 for link in re.findall(r'\]\(([^)]+)\)',(d/'README.md').read_text()):
  if '://' not in link: assert (d/link.split('#')[0]).exists(),('missing link',d.name,link)
 for p in d.iterdir():
  if p.suffix not in ('.png','.zip'): assert not re.search(rb'(?i)<LOCAL_USER_NAME>|C:(?:\\+|/)Users(?:\\+|/)',p.read_bytes()),p.name
 verified.append({'package':d.name,'archive_members':len(raw),'images':len(m['images']),'masked_images':sum(bool(r['rectangles']) for r in m['images']),'result':'PASS: raw/public replay, hashes, lengths, replacement counts, safe ZIP names, pixels, JSON, local links'})
print(json.dumps(verified,indent=2))

