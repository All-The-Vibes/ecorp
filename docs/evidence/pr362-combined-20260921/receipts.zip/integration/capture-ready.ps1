param([string]$Name)
$s=$PSScriptRoot; $g=Join-Path $s 'gates'
if((Get-Content (Join-Path $g 'ready.txt') -Raw) -ne $Name){throw 'Wrong completed gate'}
@{pid=55060;window_id=16261150;screenshot_out_file=(Join-Path $g "$Name.png")} | ConvertTo-Json -Compress | Tee-Object (Join-Path $g "$Name-cua-request.json") | cua-driver call get_window_state | Set-Content (Join-Path $g "$Name-cua.json")
if(!(Test-Path (Join-Path $g "$Name.png"))){throw 'No screenshot'}
