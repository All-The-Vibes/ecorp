"""PR362 evidence only. Reuse inspected path-redactor and explicit PNG masks."""
import hashlib,json,re,runpy,zipfile
from pathlib import Path
S=Path(__file__).parent; R=S/'resume-after-reboot'
api=runpy.run_path(str(S/'package-owner-evidence.py')); H=api['H']
D=S/'public-packages/pr362-combined-20260921';D.mkdir(exist_ok=True)
# Mask visually inspected HOME prefixes only, never command/result/source fields.
home=r'<HOME>'
def box(x,y):return [x,y,x+8*len(home)-1,y+15]
api['masks']['06-clippy.png']=[box(x,y) for x,y in [(264,720),(272,752),(272,768),(248,784)]]
api['masks']['00-target-validation.png']=[box(8*line.index(home),112+32*n) for n,line in enumerate((R/'gates/00-target-validation.log').read_text().splitlines()[1:])]
api['masks']['10-secrets.png']=[box(264,640),box(272,656),box(288,688)]
api['masks']['11-python-harness.png']=[box(128,32)]
# Frozen sources, scripts and real old/new command captures. Private account ACL dumps stay local.
source_map={}
for name in ['inputs-before.json','owner-source-mapping.json','assembled.json','assembled-source.patch','capture-combined.ps1','capture-ready.ps1','bind-inputs.py','verify-final-source.py','verify-public-packages.py','package-owner-evidence.py','package-combined.py','redact_paths.py','redaction-helper-provenance.json','owner-evidence-line-ending-map.json','owner-manifests-verification.json','preparation-diagnostics.json','first-rust-failures.json','diagnose-first-rust.py']:
 source_map['integration/'+name]=name
for p in R.iterdir():
 if p.is_file() and p.suffix in ('.json','.py','.ps1','.log') and 'private' not in p.name:
  source_map['resume/'+p.name]=str(p.relative_to(S)).replace('\\','/')
for folder in [S/'gates',R/'gates',R/'gates-native-os-temp']:
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ('.log','.json'):
   source_map[str(p.relative_to(S)).replace('\\','/')]=str(p.relative_to(S)).replace('\\','/')
(S/'combined-archive-sources.json').write_text(json.dumps(source_map,indent=2)+'\n')
rows=[]
with zipfile.ZipFile(D/'receipts.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(source_map.items()):
  b=(S/path).read_bytes();public,counts=api['redact_with_counts'](b)
  if name.endswith('.json'):json.loads(public.decode('utf-8-sig'))
  z.writestr(name,public)
  rows.append({'member':name,'raw_sha256':H(b),'public_sha256':H(public),'raw_bytes':len(b),'public_bytes':len(public),'replacements':counts,'representation':'redacted public text' if b!=public else 'unchanged bytes'})
images=[]
for folder in [S/'gates',R/'gates',R/'gates-native-os-temp']:
 for p in sorted(folder.glob('*.png')):
  b=p.read_bytes();public,boxes=api['picture'](b,p.name);(D/p.name).write_bytes(public)
  images.append({'path':p.name,'raw_source':p.relative_to(S).as_posix(),'raw_sha256':H(b),'public_sha256':H(public),'raw_bytes':len(b),'public_bytes':len(public),'rectangles':boxes,'representation':'public privacy-masked PNG derivative with disclosure footer' if boxes else 'byte-identical native PNG'})
old=json.loads((S/'gates/results.json').read_bytes()); resumed=json.loads((R/'gates/results.json').read_bytes()); final=json.loads((R/'gates-native-os-temp/results.json').read_bytes());final=final if isinstance(final,list) else [final]
allruns=old+resumed+final
chosen=[next(x for x in allruns if x['name']==name) for name in ['01-migrations','02-docs','03-unit','04-steward','05-fmt','06-clippy','07-rust-native-os-temp','08-web-build','09-web-lint']]
assert all(x['exit_code']==0 for x in chosen)
summary={'classification':'Actual nine-command matrix; original passes reused, not reexecuted','head':chosen[0]['head'],'tested_staged_tree':chosen[0]['staged_tree'],'input_manifest_sha256':chosen[0]['tested_inputs_sha256'],'gates':chosen,'focused':[x for x in resumed if x['name'] in ('10-secrets','11-python-harness')],'prior_failures':[x for x in allruns if x['exit_code']!=0]}
(D/'gate-matrix.json').write_bytes(api['redact']((json.dumps(summary,indent=2)+'\n').encode()))
inputs=json.loads((S/'inputs-before.json').read_bytes())
owned=tuple('docs/evidence/'+p+'/' for p in ['pr362-startup-20260921','pr362-regressions-20260921','pr362-combined-20260921'])
binding={'head':inputs['head'],'tested_staged_tree':inputs['assembled_staged_tree'],'source_patch_sha256':inputs['source_patch_sha256'],'files':{p:v for p,v in inputs['files'].items() if not p.startswith(owned)}}
for p,v in binding['files'].items():
 v['canonical_lf_sha256']=H((Path(r'<COMBINED_WORKTREE>')/p).read_bytes().replace(b'\r\n',b'\n'))
(D/'source-bindings.json').write_text(json.dumps(binding,indent=2)+'\n')
# README and portable checker are authored separately, never substituted for raw results.
manifest={'schema_version':2,'classification':'Public derivatives, not raw local receipts','path_roles':[{'token':token,'original_characters':len(path)} for token,path in api['rules']],'archive_members':rows,'images':images,'delivered_files':[{'path':p.name,'sha256':H(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(D.iterdir()) if p.name!='manifest.json']}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PACKED',len(rows),'raw/public member mappings;',len(images),'actual-command screenshots')


