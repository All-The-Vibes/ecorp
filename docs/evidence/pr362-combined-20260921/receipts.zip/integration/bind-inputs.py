import hashlib,json,subprocess
from pathlib import Path
r=Path(r'<COMBINED_WORKTREE>')
s=Path(__file__).parent
G=lambda *a:subprocess.check_output(['git','-C',str(r),*a])
H=lambda b:hashlib.sha256(b).hexdigest()
head=G('rev-parse','HEAD').decode().strip(); tree=G('write-tree').decode().strip()
a=json.loads((s/'assembled.json').read_text(encoding='utf-8-sig'))
assert head==a['head'] and tree==a['stagedTree']
paths=G('diff','--cached','--name-only').decode().splitlines()
assert [p for p in paths if not p.startswith('docs/evidence/')] == a['sourcePaths']
assert not G('diff','--name-only').strip()
files={}
entries=G('ls-files','-s').decode().splitlines()
blobs=[line.split()[1] for line in entries]
batch=subprocess.run(['git','-C',str(r),'cat-file','--batch'],input=('\n'.join(blobs)+'\n').encode(),capture_output=True,check=True).stdout
pos=0
for line in entries:
 meta,p=line.split('\t'); mode,blob,stage=meta.split(); assert stage=='0'
 end=batch.index(b'\n',pos); length=int(batch[pos:end].split()[-1]); b=batch[end+1:end+1+length]; pos=end+length+2; w=(r/p).read_bytes()
 files[p]={'git_blob':blob,'git_sha256':H(b),'working_sha256':H(w),'bytes':len(w)}
# Production Rust prefix and fixture helper unchanged. Test delta is precisely the owner patch.
p=a['sourcePaths'][0]
assert G('show','HEAD:'+p).split(b'#[cfg(test)]')[0].replace(b'\r\n',b'\n')==(r/p).read_bytes().split(b'#[cfg(test)]')[0].replace(b'\r\n',b'\n')
owner=(r/'docs/evidence/pr362-regressions-20260921/source.patch').read_bytes()
diff=G('diff','--cached','--binary','--',*a['sourcePaths'])
assert owner.replace(b'\r\n',b'\n').strip()==diff.replace(b'\r\n',b'\n').strip()
# Reverse applicability proves exact startup evidence patch is present without applying it.
patch=Path(a['startupPatch'])
c=subprocess.run(['git','-C',str(r),'apply','--reverse','--check',str(patch)],capture_output=True)
assert c.returncode==0,c.stderr
pins=json.loads((r/'docs/evidence/pr362-regressions-20260921/source-pins.json').read_text())
owner_root=Path(r'<REGRESSION_WORKTREE>')
owner_mapping={}
for p,row in pins['files']['candidate'].items():
 old=(owner_root/p).read_bytes(); current=(r/p).read_bytes()
 assert H(old)==row['tested_sha256'],p
 assert old.replace(b'\r\n',b'\n')==current.replace(b'\r\n',b'\n'),p
 owner_mapping[p]={'owner_raw_sha256':H(old),'combined_raw_sha256':H(current),'canonical_lf_sha256':H(current.replace(b'\r\n',b'\n')),'line_ending_only':old!=current}
(s/'owner-source-mapping.json').write_text(json.dumps(owner_mapping,indent=2)+'\n')
identity={'head':head,'assembled_staged_tree':tree,'source_paths':a['sourcePaths'],'source_patch_sha256':H(diff),'startup_patch_sha256':H(patch.read_bytes()),'startup_reverse_check_exit':c.returncode,'files':files}
(s/'inputs-before.json').write_text(json.dumps(identity,indent=2)+'\n')
(s/'assembled-source.patch').write_bytes(diff)
print('Verified HEAD, assembled staged tree, owner source patch, candidate hashes, startup patch reverse applicability;',len(files),'indexed files')
print('TESTED INPUT MANIFEST SHA256',H((s/'inputs-before.json').read_bytes()))

