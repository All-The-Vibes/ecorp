"""PR362-only public evidence packaging; raw owner receipts stay untouched."""
import hashlib,io,json,re,zipfile
from pathlib import Path,PurePosixPath
from PIL import Image,ImageDraw,ImageChops
S=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()
from redact_paths import redact as redact_roots
reg=r'<REGRESSION_WORKTREE>'
roots={str(S):'<INTEGRATION_SCRATCH>',str(S.parent/'startup'):'<STARTUP_SCRATCH>',reg+r'\output\pr362-regressions\baseline':'<REGRESSION_BASELINE>',reg:'<REGRESSION_WORKTREE>',r'<STARTUP_WORKTREE>':'<STARTUP_WORKTREE>',r'<COMBINED_WORKTREE>':'<COMBINED_WORKTREE>',r'<EARLIER_FIX_WORKTREE>':'<EARLIER_FIX_WORKTREE>',r'<ORIGINAL_AUTHOR_WORKTREE>':'<ORIGINAL_AUTHOR_WORKTREE>',r'<COORDINATOR>':'<COORDINATOR>',r'<HOME>':'<HOME>'}
roots.update({r'<DRIVE_ROOT_TEMP>':'<DRIVE_ROOT_TEMP>',r'<OWNED_OS_TEMP>':'<OWNED_OS_TEMP>'})
rules=[(token,path) for path,token in sorted(roots.items(),key=lambda p:len(p[0]),reverse=True)]
def redact_with_counts(b):
 public,counts=redact_roots(b,rules)
 # Separate, disclosed transcript identity-header redaction; not a path-only claim.
 for header in ('Username','RunAs User','Machine'):
  public,n=re.subn(rb'(?m)^'+header.encode()+rb':[^\r\n]*',lambda m:header.encode()+b': <LOCAL_IDENTITY_REDACTED>',public)
  if n: counts['transcript-header:'+header]=n
 user=next(p for p,t in roots.items() if t=='<HOME>').rsplit('\\',1)[-1]
 public,n=re.subn(rb'(?i)(?<![A-Za-z0-9])'+re.escape(user.encode())+rb'(?![A-Za-z0-9])',b'<LOCAL_USER_NAME>',public)
 if n: counts['local-user-name']=n
 return public,counts
def redact(b): return redact_with_counts(b)[0]
assert redact(b'<REGRESSION_WORKTREE>\\tools\\x.py')==b'<REGRESSION_WORKTREE>\\tools\\x.py'
assert redact(br'<REGRESSION_WORKTREE>\\tools\\x.py')==br'<REGRESSION_WORKTREE>\\tools\\x.py'
assert redact(b'PASS 7; FAILED 1; SOURCE 03b77bc\r\n')==b'PASS 7; FAILED 1; SOURCE 03b77bc\r\n'
assert redact(redact(b'<COORDINATOR>/test'))==b'<COORDINATOR>/test'
assert redact(b'<HOME>/repos/ecorp-sibling/test')==b'<HOME>/repos/ecorp-sibling/test'
# Pixel rectangles mask ONLY visually inspected machine-path prefixes. Native text is 8x16.
reg=next(k for k,v in roots.items() if v=='<REGRESSION_WORKTREE>')
home=r'<HOME>'
startup=str(S.parent/'startup')
def rect(x,y,text): return [x,y,x+8*len(text)-1,y+15]
masks={
 'startup-invocation.png':[rect(80,96,startup)],
 'startup-progress.png':[rect(80,48,startup)],
 '01-nonce-red.png':[rect(264,96,reg),rect(288,112,reg),rect(272,160,reg),rect(288,192,reg)],
 '02-nonce-green-fresh-target.png':[rect(264,256,reg),rect(288,272,reg),rect(272,320,reg)],
 '04-tls-green.png':[rect(64,64,home)],
 '06-harness-suite.png':[rect(64,64,home)],
}
j=json.loads((S/'owner-originals/pr362-regressions-20260921/runs/03-tls-red.json').read_text())
command='COMMAND '+j['executable']+' '+' '.join(j['arguments'])
rs=[]
for prefix in (reg,home):
 for m in re.finditer(re.escape(prefix),command):
  if prefix==home and command[m.start():].startswith(reg): continue
  col,row=m.start()%175,m.start()//175
  assert col+len(prefix)<=175
  rs.append(rect(col*8,64+row*16,prefix))
rs.append(rect(64,240,reg))
masks['03-tls-red.png']=rs

def picture(b,name):
 im=Image.open(io.BytesIO(b)).convert('RGB'); edited=im.copy(); draw=ImageDraw.Draw(edited)
 boxes=masks.get(name,[])
 if not boxes: return b,boxes
 for box in boxes:
  assert box[2]<im.width and box[3]<im.height
  draw.rectangle(box,fill=(70,70,70)); draw.text((box[0]+2,box[1]+2),'[local path redacted]',fill='white')
 # Verify no outcome/source pixels outside the declared rectangles changed.
 delta=ImageChops.difference(im,edited)
 for box in boxes: ImageDraw.Draw(delta).rectangle(box,fill=0)
 assert delta.getbbox() is None
 out=Image.new('RGB',(im.width,im.height+22),(235,235,235)); out.paste(edited)
 ImageDraw.Draw(out).text((5,im.height+4),'PUBLIC VIEW: local-path masks only; raw original retained; see manifest.json',fill='black')
 stream=io.BytesIO(); out.save(stream,format='PNG')
 return stream.getvalue(),boxes

def safe(names):
 assert len(names)==len(set(n.casefold() for n in names))
 for n in names:
  p=PurePosixPath(n); assert not p.is_absolute() and '..' not in p.parts and '\\' not in n and ':' not in n

def pack(name):
 original=S/'owner-originals'/name; dest=S/'public-packages'/name
 dest.mkdir(parents=True,exist_ok=True)
 rows=[]; members={}
 if name=='pr362-startup-20260921':
  with zipfile.ZipFile(original/'receipts.zip') as z:
   safe(z.namelist()); assert z.testzip() is None
   members={n:z.read(n) for n in z.namelist()}
  members['owner-manifest.json']=(original/'manifest.json').read_bytes()
  members['owner-README.md']=(original/'README.md').read_bytes()
 else:
  members={p.relative_to(original).as_posix():p.read_bytes() for p in original.rglob('*') if p.is_file() and p.suffix!='.png'}
 safe(list(members))
 with zipfile.ZipFile(dest/'receipts.zip','w',zipfile.ZIP_DEFLATED) as z:
  for n,b in sorted(members.items()):
   public,counts=redact_with_counts(b)
   # Every owner JSON remains JSON. Strings may have public path tokens.
   if n.endswith('.json'): json.loads(public.decode('utf-8-sig'))
   z.writestr(n,public)
   rows.append({'member':n,'raw_sha256':H(b),'public_sha256':H(public),'raw_bytes':len(b),'public_bytes':len(public),'replacements':counts,'representation':'redacted public text' if b!=public else 'unchanged bytes'})
 images=[]
 for p in original.glob('*.png'):
  b=p.read_bytes(); public,boxes=picture(b,p.name); (dest/p.name).write_bytes(public)
  images.append({'path':p.name,'raw_sha256':H(b),'public_sha256':H(public),'raw_bytes':len(b),'public_bytes':len(public),'rectangles':boxes,'representation':('public PNG derivative; added disclosure footer; only declared path pixels masked' if boxes else 'unchanged original native PNG')})
 readme=redact((original/'README.md').read_bytes()).decode('utf-8-sig')
 # Archive links use explicit member names rather than pretending GitHub browses ZIP contents.
 readme=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',lambda m:m.group(0) if m.group(2).endswith('.png') or '://' in m.group(2) else f'[{m.group(1)}](receipts.zip) (member `{m.group(2)}`)',readme)
 readme=readme.replace('The images are unedited PNGs returned by Cua Driver','The original images were unedited PNGs returned by Cua Driver')
 readme=readme.replace('`receipts.zip` retains raw','The local original `receipts.zip` retains raw')
 note='''> **PUBLIC REDACTED PACKAGE.** Machine/home/worktree prefixes and transcript identity headers use
> named tokens in archive text. Masked PNGs are explicit derivatives: path-only
> masks and a disclosure footer; source IDs, assertions, results and counts remain
> visible. Unmasked PNGs are byte-identical originals. Redacted bytes are NOT raw. `manifest.json` records each
> raw/public SHA-256 and each image rectangle. Untouched assembled owner copies and raw archive
> remain in the local integration scratch `owner-originals/NAME/`.
> Archive links below resolve to `receipts.zip`; the adjacent member path identifies
> the exact file. Historical manifest/receipt hash fields still refer to raw bytes;
> use the public manifest to verify the redacted members. This packaging adds no
> test run or reviewer verdict. The combined run is documented separately in
> [combined validation](../pr362-combined-20260921/README.md).

'''.replace('NAME',name)
 (dest/'README.md').write_text(note+readme,encoding='utf-8',newline='\n')
 manifest={'schema_version':2,'classification':'explicit public redacted views; not raw bytes','raw_originals_local':'<INTEGRATION_SCRATCH>/owner-originals/'+name,'path_roles':[{'token':token,'original_characters':len(path)} for token,path in rules],'archive_members':rows,'images':images,'delivered_files':[{'path':p.name,'sha256':H(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(dest.iterdir()) if p.name!='manifest.json']}
 (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
 with zipfile.ZipFile(dest/'receipts.zip') as z:
  safe(z.namelist()); assert z.testzip() is None
  for row in rows: assert H(z.read(row['member']))==row['public_sha256']
 print(name,len(rows),'archive members',len(images),'public images; raw originals preserved')
if __name__=='__main__':
 for name in ('pr362-startup-20260921','pr362-regressions-20260921'):pack(name)







