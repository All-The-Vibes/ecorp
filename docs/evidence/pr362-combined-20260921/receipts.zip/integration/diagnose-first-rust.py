import json,re
from pathlib import Path
s=Path(__file__).parent;t=(s/'gates/07-rust.log').read_text()
parts=re.split(r'^---- (.*?) stdout ----\n',t,flags=re.M)
findings=[]
for i in range(1,len(parts),2):
 block=parts[i+1]; findings.append({'test':parts[i],'git_dir_too_big':"'$GIT_DIR' too big" in block,'assertion':next((line for line in block.splitlines() if 'panicked at' in line),'')})
(s/'first-rust-failures.json').write_text(json.dumps({'classification':'Actual first combined workspace failure; no tests discarded','failures':findings,'git_dir_too_big_count':sum(x['git_dir_too_big'] for x in findings),'diagnosis':'Long TEMP nested under coordinator checkout. Short external TEMP is an environment-only correction; all test code, Rust threads=2, jobs=2, and unique same-source target remain unchanged.'},indent=2)+'\n')
print('Failure blocks',len(findings),'Git dir too big',sum(x['git_dir_too_big'] for x in findings))
