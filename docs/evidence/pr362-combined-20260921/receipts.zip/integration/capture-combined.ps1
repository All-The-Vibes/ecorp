$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$root='<COMBINED_WORKTREE>'
$output=Join-Path $PSScriptRoot 'gates'
if(Test-Path $output){throw 'Existing capture receipts; refusing overwrite'}
New-Item -ItemType Directory $output | Out-Null
Set-Location -LiteralPath $root
$Host.UI.RawUI.WindowTitle='PR362 combined ACTUAL gates - staged source, not HEAD alone'
$env:CARGO_BUILD_JOBS='2'
$env:CARGO_TARGET_DIR=Join-Path $PSScriptRoot 'target-combined-only-922b790c'
if(Test-Path $env:CARGO_TARGET_DIR){throw 'Target must be new and source-root exclusive'}
$env:CARGO_NET_OFFLINE='true'
$env:CARGO_PROFILE_DEV_DEBUG='0'
$env:CARGO_PROFILE_TEST_DEBUG='0'
$env:CARGO_INCREMENTAL='0'
$env:RUST_TEST_THREADS='2'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:ECORP_FACTORY_WATCH='0'
$env:CRONY_MCP_TEST_BINARY=$null
$env:DATABASE_URL=$null
$env:GIT_CONFIG_COUNT='1'
$env:GIT_CONFIG_KEY_0='core.longpaths'
$env:GIT_CONFIG_VALUE_0='true'
$env:TEMP=Join-Path $PSScriptRoot 'tmp'
$env:TMP=$env:TEMP; $env:TMPDIR=$env:TEMP
New-Item -ItemType Directory $env:TEMP | Out-Null
$inputs=Get-Content (Join-Path $PSScriptRoot 'inputs-before.json') -Raw | ConvertFrom-Json
$inputHash=(Get-FileHash (Join-Path $PSScriptRoot 'inputs-before.json')).Hash
$results=[Collections.Generic.List[object]]::new()
@{head=$inputs.head;staged_tree=$inputs.assembled_staged_tree;tested_inputs_sha256=$inputHash;target=$env:CARGO_TARGET_DIR;temp=$env:TEMP;git_longpaths=(& git config --get core.longpaths);cargo_jobs=2;rust_test_threads=2;node_test_concurrency='repository script default 2';profiles='dev/test debug=0, incremental=0';cargo_offline=$true;rust=(& rustc --version);cargo=(& cargo --version);node=(& node --version);pnpm=(& pnpm --version)} | ConvertTo-Json | Set-Content (Join-Path $output 'environment.json')
function Run([string]$Name,[string]$Program,[string[]]$Arguments){
 Clear-Host
 $start=[DateTime]::UtcNow
 $log=Join-Path $output "$Name.log"
 # Empty successful commands still require a real zero-length receipt.
 [IO.File]::WriteAllText($log,'')
 Write-Host "ACTUAL COMMAND: $Program $($Arguments -join ' ')"
 Write-Host "HEAD $($inputs.head) + STAGED TREE $($inputs.assembled_staged_tree)"
 Write-Host "TESTED INPUTS SHA256 $inputHash"
 Write-Host "START $Name $($start.ToString('o')) | jobs=2 rust-threads=2"
 # Stream live output to both file and console; never replay saved output for a picture.
 & $Program @Arguments 2>&1 | Tee-Object -FilePath $log | Out-Host
 $exit=$LASTEXITCODE
 $results.Add(@{name=$Name;program=$Program;arguments=$Arguments;cwd=$root;started_utc=$start.ToString('o');finished_utc=[DateTime]::UtcNow.ToString('o');exit_code=$exit;log="$Name.log";sha256=(Get-FileHash $log).Hash;bytes=(Get-Item $log).Length;head=$inputs.head;staged_tree=$inputs.assembled_staged_tree;tested_inputs_sha256=$inputHash})
 $results | ConvertTo-Json -Depth 7 | Set-Content (Join-Path $output 'results.json')
 Write-Host "END $Name | ACTUAL EXIT $exit | $([DateTime]::UtcNow.ToString('o'))"
 Write-Host "HEAD $($inputs.head)"
 Write-Host "STAGED TREE $($inputs.assembled_staged_tree)"
 Write-Host "TESTED INPUTS SHA256 $inputHash"
 [IO.File]::WriteAllText((Join-Path $output 'ready.txt'),$Name)
 $deadline=[DateTime]::UtcNow.AddMinutes(30)
 while(!(Test-Path (Join-Path $output "$Name.continue"))){if([DateTime]::UtcNow -gt $deadline){throw 'Capture wait timeout'};Start-Sleep -Milliseconds 300}
}
Run '01-migrations' 'node' @('tools/check_migrations.mjs')
Run '02-docs' 'pnpm.cmd' @('check:docs')
Run '03-unit' 'pnpm.cmd' @('test:unit')
Run '04-steward' 'pnpm.cmd' @('test:steward')
Run '05-fmt' 'cargo' @('fmt','--check')
Run '06-clippy' 'cargo' @('clippy','--workspace','--all-targets','--','-D','warnings')
Run '07-rust' 'cargo' @('test','--workspace')
Run '08-web-build' 'pnpm.cmd' @('build:web')
Run '09-web-lint' 'pnpm.cmd' @('lint:web')
Run '10-secrets' 'cargo' @('test','--locked','--offline','-p','crony-server','secrets::tests','--','--nocapture')
Run '11-python-harness' '<HOME>\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' @('-B','-m','unittest','discover','-s','tools','-p','test_startup_validation_harness.py','-v')
[IO.File]::WriteAllText((Join-Path $output 'complete.txt'),[DateTime]::UtcNow.ToString('o'))
