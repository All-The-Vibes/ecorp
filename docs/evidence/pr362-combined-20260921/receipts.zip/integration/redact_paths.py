import re

def redact(data, rules):
    text = data.decode("utf-8")
    counts = {}
    for token, prefix in rules:
        pattern = re.escape(prefix).replace(r"\\", r"[/\\]+") + r"(?![A-Za-z0-9_.-])"
        text, count = re.subn(pattern, lambda _: token, text, flags=re.I)
        if count:
            counts[token] = count
    return text.encode("utf-8"), counts
