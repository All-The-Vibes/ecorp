import hashlib,json,subprocess
from pathlib import Path
S=Path(__file__).parent;R=Path(r'<COMBINED_WORKTREE>')
G=lambda *a:subprocess.check_output(['git','-C',str(R),*a])
H=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((S/'inputs-before.json').read_bytes())
owned=tuple('docs/evidence/'+p+'/' for p in ['pr362-startup-20260921','pr362-regressions-20260921','pr362-combined-20260921'])
files={line.split('\t')[1]:line.split()[1] for line in G('ls-files','-s').decode().splitlines()}
expected={p:v['git_blob'] for p,v in old['files'].items() if not p.startswith(owned)}
current={p:v for p,v in files.items() if not p.startswith(owned)}
assert expected==current,'index change outside evidence'
for p in expected: assert H((R/p).read_bytes())==old['files'][p]['working_sha256'],p
assert G('rev-parse','HEAD').decode().strip()==old['head']
assert G('diff','--cached','--binary','--',*old['source_paths'])==(S/'assembled-source.patch').read_bytes()
changed=G('diff','--cached','--name-only').decode().splitlines()
assert [p for p in changed if not p.startswith(owned)]==old['source_paths']
assert not G('diff','--name-only').strip(),'unstaged changes'
assert not G('ls-files','--others','--exclude-standard').strip(),'untracked files'
rows=[]
for p in changed:
 blob=files[p]; b=G('cat-file','blob',blob)
 rows.append({'path':p,'git_blob':blob,'staged_sha256':H(b),'staged_bytes':len(b),'working_sha256':H((R/p).read_bytes())})
out={'head':old['head'],'tested_assembled_index_tree':old['assembled_staged_tree'],'final_staged_tree':G('write-tree').decode().strip(),'unchanged_nonowned_index_entries':len(expected),'nonowned_index_bindings_sha256':H(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()),'source_patch_sha256':H((S/'assembled-source.patch').read_bytes()),'changed_paths':rows,'scope':'Nine gates bind assembled source; final tree additionally contains evidence-only packaging. Source test files and previously committed evidence unchanged since validation.'}
(S/'final-staged-binding.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='changed_paths'},indent=2));print('Changed paths',len(rows))
