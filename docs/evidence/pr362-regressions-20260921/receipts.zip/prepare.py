"""Prepare NEW retrospective test-only overlays; never change another worktree."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
EVIDENCE = Path(__file__).resolve().parent
BASE = "410eddfc8bfcfa874dae05555128d39a914f0456"
PARENT = "03b77bc6a7b402665e2dba7f6f1820f8fa8dbdd7"
BASELINE = ROOT / "output/pr362-regressions/baseline"


def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd)


assert git("rev-parse", "HEAD").decode().strip() == PARENT
assert not BASELINE.exists(), "Never overwrite a prior attempt"
BASELINE.parent.mkdir(parents=True, exist_ok=True)
subprocess.run(["git", "worktree", "add", "--detach", str(BASELINE), BASE],
               cwd=ROOT, check=True)
secrets_path = "crates/crony-server/src/secrets.rs"
candidate = (ROOT / secrets_path).read_text()
test_start = candidate.index("    #[test]\n    fn nonces_are_not_constrained")
test_end = candidate.index("    #[test]", test_start + len("    #[test]"))
nonce_test = candidate[test_start:test_end]
original = (BASELINE / secrets_path).read_text()
anchor = "    #[test]\n    fn ciphertext_is_bound_to_corp_secret_and_name"
assert original.count(anchor) == 1
(BASELINE / secrets_path).write_text(original.replace(anchor, nonce_test + anchor))
test_path = "tools/test_startup_validation_harness.py"
(BASELINE / test_path).write_bytes((ROOT / test_path).read_bytes())

pins = {"classification": "NEW retrospective, not original test-first chronology",
        "parent": PARENT, "baseline": BASE, "files": {}}
for label, directory, revision in [("baseline", BASELINE, BASE), ("candidate", ROOT, PARENT)]:
    source = (directory / secrets_path).read_text().split("#[cfg(test)]")[0]
    expected = git("show", f"{revision}:{secrets_path}").decode().split("#[cfg(test)]")[0]
    assert source == expected, f"{label}: non-test secrets source changed"
    assert (directory / "tools/test_startup_validation.py").read_bytes().replace(
        b"\r\n", b"\n") == git("show", f"{revision}:tools/test_startup_validation.py")
    patch = git("diff", "--", secrets_path, test_path, cwd=directory)
    (EVIDENCE / f"{label}-test-only.patch").write_bytes(patch)
    files = {}
    for path in [secrets_path, test_path, "tools/test_startup_validation.py",
                 "Cargo.toml", "Cargo.lock", "crates/crony-server/Cargo.toml"]:
        data = (directory / path).read_bytes()
        files[path] = {"git_blob": git("rev-parse", f"{revision}:{path}").decode().strip(),
                       "tested_sha256": hashlib.sha256(data).hexdigest()}
    pins["files"][label] = files
(EVIDENCE / "source-pins.json").write_text(json.dumps(pins, indent=2) + "\n")
print(json.dumps(pins, indent=2))
