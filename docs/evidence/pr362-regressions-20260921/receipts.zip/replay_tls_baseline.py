"""Run the identical TLS test on the exact old helper; certificate setup only is adapted."""
from pathlib import Path
import sys
import unittest

source = Path(sys.argv[1]).resolve()
openssl = Path(sys.argv[2]).resolve(strict=True)
sys.path.insert(0, str(source / "tools"))
import test_startup_validation as harness
import test_startup_validation_harness as tests

assert not hasattr(harness, "openssl"), "This adapter is only for the pinned old helper"
# The old harness lacks the later OpenSSL locator. Supply certificate generation
# only; http_fixture, SSLContext, minimum_version and the test remain unchanged.
harness.openssl = lambda args: harness.command([str(openssl), *args])
suite = unittest.defaultTestLoader.loadTestsFromTestCase(tests.TlsFixtureTests)
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
