"""Check retained receipt bindings; these static checks are not runtime regression proof."""
import hashlib
import json
from pathlib import Path
import subprocess

evidence = Path(__file__).resolve().parent
root = evidence.parents[2]
pins = json.loads((evidence / "source-pins.json").read_text())
expected = {
    "runs/01-nonce-red": (101, "non_v4_version=false, non_uuid_variant=false", "baseline"),
    "runs/03-tls-red": (1, "AssertionError: <TLSVersion.TLSv1_3: 772> != <TLSVersion.TLSv1_2: 771>", "baseline"),
    "runs/04-tls-green": (0, "OK", "candidate"),
    "retry-runs/02-nonce-green": (0, "1 passed; 0 failed", "candidate"),
    "retry-runs/05-secrets-suite": (0, "7 passed; 0 failed", "candidate"),
    "retry-runs/06-harness-suite": (0, "Ran 5 tests", "candidate"),
}
for name, (exit_code, marker, source) in expected.items():
    record = json.loads((evidence / f"{name}.json").read_text(encoding="utf-8-sig"))
    text = (evidence / f"{name}.log").read_text(encoding="utf-8-sig")
    assert record["exit_code"] == exit_code and marker in text, name
    assert record["head"] == pins["baseline" if source == "baseline" else "parent"], name
    for key, path in [("secrets_sha256", "crates/crony-server/src/secrets.rs"),
                      ("tls_helper_sha256", "tools/test_startup_validation.py"),
                      ("tls_test_sha256", "tools/test_startup_validation_harness.py")]:
        assert record[key].lower() == pins["files"][source][path]["tested_sha256"], name

for label, directory, revision in [
    ("candidate", root, pins["parent"]),
    ("baseline", root / "output/pr362-regressions/baseline", pins["baseline"]),
]:
    def git(*args):
        return subprocess.check_output(["git", *args], cwd=directory)
    assert git("rev-parse", "HEAD").decode().strip() == revision
    assert set(git("diff", "--name-only").decode().splitlines()) == {
        "crates/crony-server/src/secrets.rs", "tools/test_startup_validation_harness.py"}
    for path, identity in pins["files"][label].items():
        assert hashlib.sha256((directory / path).read_bytes()).hexdigest() == identity["tested_sha256"]
    path = "crates/crony-server/src/secrets.rs"
    assert (directory / path).read_text().split("#[cfg(test)]")[0] == git(
        "show", f"{revision}:{path}").decode().split("#[cfg(test)]")[0]
    path = "tools/test_startup_validation.py"
    assert (directory / path).read_bytes().replace(b"\r\n", b"\n") == git("show", f"{revision}:{path}")

stale = json.loads((evidence / "stale-candidate-attempt.json").read_text(encoding="utf-8-sig"))
assert stale["baselineHash"] == stale["attemptHash"]
fresh = json.loads((evidence / "candidate-binary.json").read_text(encoding="utf-8-sig"))
assert fresh["Hash"] != stale["attemptHash"]
assert "Compiling crony-server" in (evidence / "retry-runs/02-nonce-green.log").read_text()
for image in ["01-nonce-red.png", "02-nonce-green-fresh-target.png", "03-tls-red.png",
              "04-tls-green.png", "05-secrets-suite.png", "06-harness-suite.png"]:
    assert (evidence / image).read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
subprocess.run(["git", "apply", "--reverse", "--check", str(evidence / "source.patch")],
               cwd=root, check=True)
print("PASS: six accepted runtime receipts bind to unchanged tested bytes and expected outcomes.")
print("PASS: both exact historical implementations remain unchanged outside test overlays.")
print("PASS: stale candidate attempt excluded; fresh candidate binary differs; six result PNGs present.")
print("LIMIT: static receipt integrity checks, not a substitute for the recorded native test runs or review.")
