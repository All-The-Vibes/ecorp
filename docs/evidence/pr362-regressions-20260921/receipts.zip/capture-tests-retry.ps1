$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$root = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$baseline = Join-Path $root 'output/pr362-regressions/baseline'
$output = Join-Path $PSScriptRoot 'retry-runs'
if (Test-Path -LiteralPath $output) { throw 'Refuse to overwrite prior test attempts.' }
New-Item -ItemType Directory -Path $output | Out-Null
$env:CARGO_BUILD_JOBS = '2'
$env:CARGO_TARGET_DIR = Join-Path $root 'output/pr362-regressions/target-candidate-fresh'
$env:CARGO_NET_OFFLINE = 'true'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:TEMP = Join-Path $root 'output/pr362-regressions/tmp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
$python = '<HOME>\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$openssl = 'C:\Program Files\Git\usr\bin\openssl.exe'
$Host.UI.RawUI.WindowTitle = 'PR362 candidate-only fresh target regression retry'
$PSStyle.OutputRendering = 'PlainText'
$cases = @(
    @{name='02-nonce-green'; cwd=$root; exe='cargo'; args=@('test','-p','crony-server','--locked','--offline','secrets::tests::nonces_are_not_constrained_to_uuid_v4_fixed_bits','--','--exact','--nocapture','--test-threads=1')},
    @{name='05-secrets-suite'; cwd=$root; exe='cargo'; args=@('test','-p','crony-server','--locked','--offline','secrets::tests','--','--nocapture','--test-threads=1')},
    @{name='06-harness-suite'; cwd=$root; exe=$python; args=@('-B','-m','unittest','discover','-s','tools','-p','test_startup_validation_harness.py','-v')}
)
foreach ($case in $cases) {
    Clear-Host
    Set-Location -LiteralPath $case.cwd
    $started = [DateTime]::UtcNow.ToString('o')
    $head = (& git rev-parse HEAD)
    Write-Host "PR362 NEW RETROSPECTIVE $($case.name) | $started"
    Write-Host "SOURCE $head + test-only overlay; CARGO_BUILD_JOBS=2"
    Write-Host "COMMAND $($case.exe) $($case.args -join ' ')"
    $arguments = $case.args
    & $case.exe @arguments 2>&1 |
        Tee-Object -FilePath (Join-Path $output "$($case.name).log") |
        Select-Object -Last 24 | Out-Host
    $exit = $LASTEXITCODE
    Write-Host "ACTUAL EXIT $exit | NEW retrospective evidence, NOT original TDD."
    [ordered]@{name=$case.name; cwd=$case.cwd; head=$head; executable=$case.exe;
        arguments=$case.args; exit_code=$exit; started_utc=$started;
        ended_utc=[DateTime]::UtcNow.ToString('o'); shell_pid=$PID;
        target=$env:CARGO_TARGET_DIR; jobs=$env:CARGO_BUILD_JOBS;
        secrets_sha256=(Get-FileHash 'crates/crony-server/src/secrets.rs').Hash;
        tls_helper_sha256=(Get-FileHash 'tools/test_startup_validation.py').Hash;
        tls_test_sha256=(Get-FileHash 'tools/test_startup_validation_harness.py').Hash
    } | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $output "$($case.name).json")
    [IO.File]::WriteAllText((Join-Path $output 'ready.txt'), $case.name)
    $ack = Join-Path $output "$($case.name).continue"
    $deadline = [DateTime]::UtcNow.AddMinutes(30)
    while (!(Test-Path -LiteralPath $ack)) {
        if ([DateTime]::UtcNow -gt $deadline) { throw 'Capture wait expired; all evidence retained.' }
        Start-Sleep -Milliseconds 300
    }
}
Write-Host 'Completed actual commands; no saved logs or reports were replayed.'
