# Setup and evidence boundaries

All work in this directory is **NEW, retrospective work on September 21, 2026**.
Nothing here establishes that the original security fixes were developed test-first.
No commit, push, production change, dependency change, policy change, provider run,
Factory operation, shared service, or other worker's worktree is authorized here.

## Reads and retained setup issues

- Read root `AGENTS.md`, `tools/AGENTS.md`, and all four product references at
  `03b77bc6a7b402665e2dba7f6f1820f8fa8dbdd7` before editing tests.
- Read the parent-pinned team code-review skill and its remediation/dependencies
  references under `ecorp/output/pr-gauntlet-20260921/policy`, and both round2
  `lane-a/review.md` and `lane-b/review.md`. They remain independent historical
  reviews, not approvals of these new tests.
- Initial PowerShell `git rev-parse SHA^{commit}` calls were unquoted. PowerShell
  misparsed the braces, producing `-encodedCommand YwBvAG0AbQBpAHQA` and
  `fatal: ambiguous argument 'YwBvAG0AbQBpAHQA'`. Quoted revision arguments then
  resolved both exact requested commits. This was setup failure, not RED.
- An initial recursive inventory of the parent's evidence directory included its
  dependency cache and overflowed the tool display. Subsequent reads were bounded
  to the specific policy/review files. No contents were modified.
- A read of the optional worktree `.cargo` directory reported that it does not
  exist. No configuration was created or changed. Native Cargo uses its existing
  cached dependencies with `--locked --offline` and `CARGO_BUILD_JOBS=2`.
- Cua `launch_app` response was delayed while the native terminal was already
  running. No duplicate launch occurred. The conhost PID's `list_windows` returned
  an empty list; the owned child PowerShell PID resolved the exact terminal HWND.
  Both readbacks are retained. The eventual launch response reports `active:false`.
  The qualified screenshot shows the live command, not a completed result.
  Geometry changed through Cua's native background frame tool and was read back.
  No foreground delivery, desktop capture, or rendered-report replacement was used.
- Web-tool requests for the RFC and Python documentation returned no content.
  The bit positions are the user's supplied RFC 9562 research lead; the test uses
  those positions directly. The installed Python SSL property implementation and
  actual default are separately retained, not claimed as a web-research result.

## Actual call paths traced

- Startup initializes `SecretCipher`; the server's `create_secret` handler calls
  `encrypt`, persists its ciphertext/nonce through `store.create_secret`, and
  `resolve_secret_refs` calls `decrypt` on the persisted grant.
  No caller, serialization, key, cipher, AAD or production nonce code changes.
- `http_fixture` creates a loopback-only `ThreadingHTTPServer`, constructs a real
  `SSLContext(PROTOCOL_TLS_SERVER)`, loads its certificate, and wraps its socket.
  The main startup driver and the existing `TlsFixtureTests` use this helper.
  Only the latter's test code changes; the full startup driver is not executed.

## Original author records

The only original-author search location was the requested
`<ORIGINAL_AUTHOR_WORKTREE>\output`.
`original-author-records/top-level-inventory.json` records the bounded inventory;
`nonce-tls-log-matches.json` records the relevant top-level log matches.

The retained `secret-tests.log` failed compilation with E0063 (missing
`dispatch_readiness`), so it is **not RED**. Later nonce checks and
`python-tls-minimum-validation.log` pass the earlier, insufficient tests.
No applicable original nonce/TLS failing-baseline receipt was found in that search.
This does not prove that no such record exists elsewhere. Original full-PR TDD
chronology remains unavailable; no historical receipt or review was rewritten.
