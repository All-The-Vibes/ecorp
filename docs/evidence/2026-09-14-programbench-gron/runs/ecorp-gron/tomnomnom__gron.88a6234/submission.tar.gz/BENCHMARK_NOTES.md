# Independent gron implementation

## Approach and scope

`gron.py` is independently authored Python 3 source using only standard libraries.
`compile.sh` creates the standalone root `executable` by copying that source and
ensuring it is executable. This offline interpreted build is not a wrapper around
the reference. Runtime requires only the installed `/usr/bin/python3` and standard
libraries, not the source filename, reference, absolute task path, or host services.

Implemented modes include JSON flattening, assignment reconstruction, JSON
statement streams, line-oriented input streams, values extraction, file/stdin
input, CLI flags, and standard-library HTTP/HTTPS support. A custom JSON decoder
preserves number spellings. Paths use JavaScript-compatible identifier formatting;
object paths sort by rendered segments and array paths by index. Reconstruction
merges partial trees and pads sparse arrays with null.

Only `TASK.md`, permitted `/workspace/README.mkd` and `/workspace/ADVANCED.mkd`,
and ordinary reference CLI interactions informed this implementation. No target
source, binary contents, evaluator tests, Internet resources, credentials, build
caches, or parent-host files were accessed. No subagents were used. `TASK.md`,
`.gitignore`, and Git metadata were not modified. No commits were created.

## Runtime boundary

The exact required runtime-proof command was executed before documentation or
implementation and again on the final resume:

```sh
/usr/bin/python3 -c 'import os,json,pathlib; r={"os":os.name,"cwd":os.getcwd(),"proxy_key_present":bool(os.environ.get("COPILOT_PROXY_API_KEY"))}; assert r["os"]=="posix" and r["cwd"].startswith("/ecorp-task/") and not r["proxy_key_present"], "Runtime boundary check failed; stop"; pathlib.Path("runtime-proof.json").write_text(json.dumps(r,indent=2)+"\n"); print(json.dumps(r))'
```

The original environment failed at bubblewrap startup before Python ran, and work
stopped. After the owner's repair, the command passed. It passed again on the
final resume. `runtime-proof.json` records POSIX, the assigned task directory,
and `proxy_key_present: false`. This is environment evidence, not a benchmark
test or score. No credential value was printed.

## Actual commands and verification

Documentation and initial CLI inspection included:

```sh
cat TASK.md
cat /workspace/README.mkd
cat /workspace/ADVANCED.mkd
/workspace/executable --help
/workspace/executable --version
python3 --version
```

Python reported 3.10.12; the reference reported `gron version dev`. Initial inline
Python probes invoked the reference normally with authored stdin and CLI arguments.
The durable `verify.py` suite repeats the important observations and adds generated
JSON using fixed seed 8836234. It compares stdout, stderr, and exit status exactly,
including reverse conversion of successful ordinary/JSON-stream flattenings.

The final differential command executed was:

```sh
./compile.sh && python3 verify.py
```

**Observed: 467 comparisons; 467 passed; 0 failed; 49.890 seconds.**
`verification.json` contains every input, argument list, reference result,
candidate result, match flag, and the summary. Coverage includes nested data,
25-element array ordering, reserved/Unicode keys, string escaping, number spelling,
duplicate keys, sparse reconstruction, merge conflicts, malformed input, streaming,
JSON statements, values, flags/help/version, and missing-file errors. These are
self-authored checks, not official ProgramBench tests or held-out feedback.

Syntax and file smoke commands actually executed:

```sh
sh -n compile.sh
printf '{"a":[1,true,null],"a-b":"hello"}\n' > smoke-input.json
./executable smoke-input.json > smoke-output.gron
./executable -u smoke-output.gron
```

Shell syntax passed; the round trip returned the original object as formatted
JSON. An inline Python check also successfully parsed the source with
`ast.parse(pathlib.Path('gron.py').read_text())`.

Relocation commands actually executed, entirely inside the assigned worktree:

```sh
mkdir -p relocation-check
cp compile.sh gron.py relocation-check/
(cd relocation-check && ./compile.sh && mv gron.py source-held.py && printf '{"a":[1,true,null],"a-b":"hello"}\n' | ./executable > actual.gron)
cmp smoke-output.gron relocation-check/actual.gron
```

The relocated build passed, and the executable worked after its source filename
was renamed. `cmp` passed. This is a nested-directory relocation check, not a
claim to have run the official fresh evaluator environment. The generated
relocated copies are removed after validation; the output and result note remain.

An initial unconditional chmod failed in this managed filesystem, where new
files were already executable. The build was corrected to chmod only when
needed; the final build returned zero. No apply_patch executable was exposed,
and GNU patch failed while setting ownership. Text edits used a shell apply_patch
helper that writes patches directly without changing ownership or Git metadata.

## Observations and limitations

- The reference preserves number spellings in ordinary and assignment modes;
  JSON-stream ungron converts through floating point. Both behaviors are tested,
  including large-integer rounding.
- The reference accepts the first JSON value and ignores trailing input in
  ordinary mode. Line-stream mode rejects blank lines after emitting prior valid
  statements. The candidate matches these observed cases.
- Captured non-TTY reference output has no ANSI escapes even with `--colorize`;
  that flag makes ungron output compact. Those cases match. Interactive terminal
  coloring is unverified.
- HTTP/HTTPS, proxies, certificate errors, and network diagnostics use Python
  standard-library behavior and were not network-tested. Exact Go transport
  parity, environment proxy defaults, and every proxy form are not claimed.
  No Internet requests were made.
- `--no-sort` preserves Python object insertion order; reference map ordering may
  differ. Exact unsorted object ordering is not claimed.
- Input is read fully before processing; indefinitely open stdin is not handled
  incrementally. Scanner length limits, extreme memory cases, and every I/O
  failure behavior are not replicated or exhaustively tested.
- Sparse indices above 10,000,000 are rejected to bound allocation. Deep recursion
  and extreme inputs remain constrained by Python resources. Malformed assignment
  syntaxes outside the authored corpus may differ in diagnostics or acceptance.

No held-out tests or feedback were available, and no ProgramBench score is claimed.
Artifact existence and these checks do not certify full functional equivalence.
