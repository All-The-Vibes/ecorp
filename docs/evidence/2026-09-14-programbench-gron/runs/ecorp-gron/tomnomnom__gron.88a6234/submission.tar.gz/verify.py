#!/usr/bin/python3
import json
import random
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CASES = []


def add(arguments, *inputs):
    CASES.extend((arguments, value) for value in inputs)


add([], '', '{}', '[]', 'null', 'true', 'false', '1.00', '1e30', '1e-8', '-0', '9007199254740993', '{}{}', '[1,2] trailing', '{', '[1,]', 'NaN', '{"x":}', '{"x" 1}', '{"x":1,}', '{"x":1 "y":2}', '[1 2]', '"\\x41"', '"\\uXY00"', '"\\uD800"', '"\\uD83D\\uDE00"', '"<>&\\u2028\\u2029\\u0000\\b\\f\\n\\r\\t/é"', '{"a":1,"a":2}')
add(['-s'], '', '\n', '{}\n', '{}\r\n{}\r\n', '{} {}\n', '{"a":1}\n\n{"b":2}\n', '{"a":1}\n{"b":2}\n', '[1,2]\ntrue\nnull\n', '{\n"a":1\n}\n')
add(['-u'], '', 'json = {};', 'json = [];', 'json = 1;', 'json = 1.00;', 'json = 1e30;', 'json = -0;', 'json = 9007199254740993;', 'json = "<>&";', 'json.a = 1;\njson = {};', 'json.a = 1;\njson.a = {};', 'json.a.b = 1;\njson.a = {};', 'json.a = 1;\njson.a.b = 2;', 'json.a = {};\njson.a[0] = 1;', 'json.a = [];\njson.a.b = 1;', 'json[0] = 1;\njson.a = 2;', 'json.a = 1;\njson[0] = 2;', 'json.a=1;', ' json.a = 1;', 'json.a = 1;\n\njson.b = 2;', 'json.a = 1; // comment', 'json.a = [1,2];', 'json.a = undefined;', 'json.a = -1.25e+2;', 'json["a-b"] = "ok";', "json['a-b'] = 'ok';", 'json[01] = 1;', 'json[-1] = 1;', 'json[1.2] = 1;', 'foo = 1;', 'jsonx.a = 1;', 'json.json = 1;', 'json.a = "\\uD800";', 'json.a = "\\x41";', 'json.a = "hi"', 'json.a = true', 'json.a = {}', 'json.a = [];\n', 'json.a = ;', 'json.a = 01;', 'json.a = NaN;', 'json.a = .5;', 'json.a = +1;', 'json.a = 1e309;', 'json.a = "a\nb";', 'json.a = false ;', 'json . a = 1;', 'json[ "a" ] = 1;', '[0] = 1;', '.a = 1;', 'a-b = 1;', '123 = 1;', '\tjson.a = 1;', 'garbage\njson.a = 1;', 'json.a;\njson.b = 2;', 'json.a = {};\njson.a = 1;', 'json.a = [];\njson.a = null;')
add(['-v'], 'json.a = "a\\nb\\t\\u263a";', 'json.a = 1.00;\njson.b = 1e30;', 'json.a = [1,2];', 'json.a = true;\nBAD\njson.b = false;', 'json.a=1;', 'json.a = 1\n', 'foo = "yes";', 'json = "hello";', 'json.a = undefined;', 'json.a = 1; json.b = 2;', ' json.a = 1;', 'json.a = "\\x41";', 'json.a = {};\njson.b = [1];\njson.c = null;')
add(['-j', '-u'], '', '[[],{}]\n[["a"],1]', '[["b"],1]\n[["a"],2]', '[[2],1]', '[["a"],1.00]', '[["a"],{"x":1}]', '[[],[1,2]]', '[[],null]', '[[],1]\n', '[["a"],1]\n\n[["b"],2]', '[["a"],1] [["b"],2]', '{}', '[[]]', '[[true],1]', '[[1.5],1]', '[["a"],1,2]', '[["a"],1]\nnot json', '[["a"],1e100]', '[null,1]', '[[],true]', '[["json","a"],1]', '[["a"],1e20]', '[["a"],1e6]', '[["a"],1e-6]', '[["a"],1e-7]', '[["a"],9007199254740993]', '[["a"],-0]', '[["a"],1e309]', '[[0.0],1]')
for arguments in [['-uv'], ['--values', '--ungron'], ['--help'], ['--foo'], ['--color'], ['--sort'], ['--version=foo'], ['-s=false'], ['-u=false'], ['-x'], ['--'], ['-'], ['missing.json'], ['-j', '-c'], ['-u', '-c'], ['-u', '-m'], ['-u', '--no-sort'], ['--version'], ['--compact'], ['--colorize', '-u'], ['-c=false', '-u'], ['--monochrome', '--colorize', '-u'], ['-s', '-u'], ['--json', '--stream'], ['-v', '-s'], ['-x', 'bad proxy']]:
    add(arguments, 'json.b = 1;\njson.a = 2;' if '-u' in arguments or '--ungron' in arguments or '-v' in arguments else '{}')

KEYS = ['', 'a', 'b', 'a10', 'a2', '0', '10', '2', 'class', 'null', 'let', '$', '_', 'é', '中文', 'á', 'a١', 'a²', 'a\u200c', 'a‿', 'foo bar', 'a.b', 'a-b', 'a[', 'aA', '"', '\\', '\n', '<>&', '💩']
SPECIAL = json.dumps({key: index for index, key in enumerate(KEYS)}, ensure_ascii=False)
add([], SPECIAL, json.dumps(list(range(25))), '{"a":[1,2],"aA":3,"b":5,"a-b":{"x":1,"x-":2,"xA":3}}')
add(['-j'], SPECIAL, '[1.00,1e30,1e-8,9007199254740993,-0,1E+02]')
RANDOM = random.Random(8836234)


def random_value(depth=0):
    kind = RANDOM.randrange(6 if depth < 4 else 4)
    if kind == 0:
        return RANDOM.choice([None, True, False])
    if kind == 1:
        return RANDOM.randrange(-100000, 100000)
    if kind == 2:
        return RANDOM.choice(['', 'test', 'α😀', '<>&', '\n\r\t\b\f', 'x\u2028y\u2029z', 'a"b\\c'])
    if kind == 3:
        return RANDOM.uniform(-100, 100)
    if kind == 4:
        return [random_value(depth + 1) for unused in range(RANDOM.randrange(5))]
    return {RANDOM.choice(KEYS): random_value(depth + 1) for unused in range(RANDOM.randrange(7))}


for unused in range(70):
    data = json.dumps(random_value(), ensure_ascii=False)
    add([], data)
    add(['-j'], data)


def run(program, arguments, data):
    result = subprocess.run([program] + arguments, input=data.encode(), capture_output=True, cwd=ROOT, timeout=10)
    return {'code': result.returncode, 'stdout': result.stdout.decode(errors='replace'), 'stderr': result.stderr.decode(errors='replace')}


def main():
    start = time.monotonic()
    records = []
    for arguments, data in CASES:
        expected = run('/workspace/executable', arguments, data)
        actual = run(str(ROOT / 'executable'), arguments, data)
        records.append({'arguments': arguments, 'input': data, 'reference': expected, 'candidate': actual, 'match': expected == actual})
        if expected['code'] == 0 and arguments in ([], ['-j']):
            reverse = arguments + ['-u']
            expected_reverse = run('/workspace/executable', reverse, expected['stdout'])
            actual_reverse = run(str(ROOT / 'executable'), reverse, expected['stdout'])
            records.append({'arguments': reverse, 'input': expected['stdout'], 'reference': expected_reverse, 'candidate': actual_reverse, 'match': expected_reverse == actual_reverse})
    failures = [record for record in records if not record['match']]
    summary = {'total': len(records), 'passed': len(records) - len(failures), 'failed': len(failures), 'seconds': round(time.monotonic() - start, 3)}
    (ROOT / 'verification.json').write_text(json.dumps({'summary': summary, 'cases': records}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary))
    for failure in failures[:20]:
        print(json.dumps(failure, ensure_ascii=False))
    return bool(failures)


if __name__ == '__main__':
    raise SystemExit(main())
