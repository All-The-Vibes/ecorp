$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$PSStyle.OutputRendering = 'PlainText'
$root = '<STARTUP_WORKTREE>'
$out = $PSScriptRoot
$python = '<HOME>\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$binary = Join-Path $out 'cargo-target\debug\crony-server.exe'
$expected = '03b77bc6a7b402665e2dba7f6f1820f8fa8dbdd7'
if (Test-Path -LiteralPath (Join-Path $out 'run.json')) { throw 'Preserve prior attempt; do not reuse receipts.' }
Set-Location -LiteralPath $root
$env:TEMP = Join-Path $out 'tmp'
$env:TMP = $env:TEMP
$env:TMPDIR = $env:TEMP
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONUNBUFFERED = '1'
$env:PYTHONOPTIMIZE = $null
$env:CARGO_BUILD_JOBS = '2'
$env:DATABASE_URL = $null
$env:ECORP_FACTORY_WATCH = '0'
$build = Get-Content -LiteralPath (Join-Path $out 'build.json') -Raw | ConvertFrom-Json
if ($build.exit -ne 0 -or !$build.lock_unchanged) { throw 'Successful locked standalone build required.' }
$head = & git rev-parse HEAD
if ($head -ne $expected -or @(& git status --porcelain).Count) { throw 'Exact clean source required before run.' }
$hash = (Get-FileHash -LiteralPath $binary).Hash
if ($hash -ne $build.binary_sha256) { throw 'Binary does not match build receipt.' }
$argsForTest = @('-B', '-u', 'tools/test_startup_validation.py', '--server-binary', $binary, '--allow-disposable-docker')
$identity = [ordered]@{
    started_utc = [DateTime]::UtcNow.ToString('o')
    root = $root; head = $head; tree = (& git rev-parse 'HEAD^{tree}')
    shell_pid = $PID; python = $python; arguments = $argsForTest
    binary = $binary; binary_sha256 = $hash
    harness_sha256 = (Get-FileHash -LiteralPath 'tools/test_startup_validation.py').Hash
    cargo_lock_sha256 = (Get-FileHash -LiteralPath 'Cargo.lock').Hash
    python_version = (& $python -B -c 'import sys,ssl; print(sys.version); print(ssl.OPENSSL_VERSION)') -join "`n"
    openssl = (& 'C:\Program Files\Git\usr\bin\openssl.exe' version)
    temp_root = $env:TEMP
    scope = 'New complete startup run, not original 09f916 history; no baseline or unit-only substitution.'
}
$identity | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'run.json') -Encoding utf8
& docker version --format '{{json .}}' | Set-Content -LiteralPath (Join-Path $out 'docker-version.json') -Encoding utf8
& docker image inspect postgres:17-alpine --format '{{json .}}' | Set-Content -LiteralPath (Join-Path $out 'postgres-image.json') -Encoding utf8
& docker container ls -a --filter 'label=ecorp.test-owner' --format '{{json .}}' | Set-Content -LiteralPath (Join-Path $out 'containers-before.jsonl') -Encoding utf8
Start-Transcript -LiteralPath (Join-Path $out 'terminal-transcript.txt') | Out-Null
Write-Host 'PR362 F-362-B-01 | NEW COMPLETE STARTUP REGRESSION'
Write-Host "SOURCE $head"
Write-Host 'COMMAND: bundled Python -B -u tools/test_startup_validation.py'
Write-Host '         --server-binary $binary --allow-disposable-docker'
Write-Host "`$binary = $binary"
Write-Host "BINARY SHA256 $hash"
Write-Host "BUILD: cargo build -p crony-server --locked --offline | jobs=2"
Write-Host 'Native command output follows after the invocation capture.'
[IO.File]::WriteAllText((Join-Path $out 'ready.txt'), 'invocation')
$deadline = [DateTime]::UtcNow.AddMinutes(20)
while (!(Test-Path -LiteralPath (Join-Path $out 'invoke.continue'))) {
    if ([DateTime]::UtcNow -gt $deadline) { throw 'Invocation capture wait expired; no test started.' }
    Start-Sleep -Milliseconds 250
}
$identity.invoked_utc = [DateTime]::UtcNow.ToString('o')
Write-Host "INVOKING NOW $($identity.invoked_utc)"
& $python @argsForTest 2>&1 | Tee-Object -FilePath (Join-Path $out 'startup.log') | Out-Host
$code = $LASTEXITCODE
$identity.exit_code = $code
$identity.finished_utc = [DateTime]::UtcNow.ToString('o')
$identity.log_sha256 = (Get-FileHash -LiteralPath (Join-Path $out 'startup.log')).Hash
$identity.binary_unchanged = ((Get-FileHash -LiteralPath $binary).Hash -eq $hash)
$identity.source_status_after = @(& git status --porcelain)
$identity.temp_entries_after = @(Get-ChildItem -LiteralPath $env:TEMP -Force | Select-Object -ExpandProperty Name)
$identity | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'run.json') -Encoding utf8
& docker container ls -a --filter 'label=ecorp.test-owner' --format '{{json .}}' | Set-Content -LiteralPath (Join-Path $out 'containers-after.jsonl') -Encoding utf8
Write-Host "ACTUAL COMPLETE STARTUP EXIT $code | $($identity.finished_utc)"
Write-Host "SOURCE $head"
Write-Host 'COMMAND: Python -B -u tools/test_startup_validation.py'
Write-Host '         --server-binary $binary --allow-disposable-docker'
Write-Host "BINARY SHA256 $hash"
Write-Host "TEMP ENTRIES REMAINING $($identity.temp_entries_after.Count)"
Write-Host 'New execution. No saved logs rendered; no historical/TDD claim.'
[IO.File]::WriteAllText((Join-Path $out 'ready.txt'), 'result')
$deadline = [DateTime]::UtcNow.AddMinutes(20)
while (!(Test-Path -LiteralPath (Join-Path $out 'capture.continue'))) {
    if ([DateTime]::UtcNow -gt $deadline) { throw 'Result capture wait expired; evidence retained.' }
    Start-Sleep -Milliseconds 250
}
Stop-Transcript | Out-Null
exit $code
