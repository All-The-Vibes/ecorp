"""Package this new execution only; refuse changed source or incomplete receipts."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import zipfile

scratch = Path(__file__).resolve().parent
root = Path(r"<STARTUP_WORKTREE>")
output = root / "docs/evidence/pr362-startup-20260921"
head = "03b77bc6a7b402665e2dba7f6f1820f8fa8dbdd7"


def read(name):
    return json.loads((scratch / name).read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


run, build, cleanup = read("run.json"), read("build.json"), read("cleanup.json")
assert run["head"] == build["head"] == head
assert run["exit_code"] == build["exit"] == 0
assert run["binary_unchanged"] and build["lock_unchanged"]
assert not run["source_status_after"] and not run["temp_entries_after"]
assert "--baseline" not in run["arguments"]
assert "--allow-disposable-docker" in run["arguments"]
assert digest(Path(run["binary"])) == run["binary_sha256"].lower() == build["binary_sha256"].lower()
assert digest(scratch / "startup.log") == run["log_sha256"].lower()
assert digest(root / "Cargo.lock") == run["cargo_lock_sha256"].lower()
assert digest(root / "tools/test_startup_validation.py") == run["harness_sha256"].lower()
assert cleanup["query_exit"] == 0 and cleanup["observed_fixture_directory_absent"]
for name in ("remaining_container_ids", "remaining_exact_binary_processes",
             "remaining_harness_processes", "temp_entries"):
    assert cleanup[name] == [], name
assert read("windows-after-release.json")["windows"] == []
assert read("launch-request.json")["start_minimized"] is False
assert read("launch-result.json")["active"] is False
assert subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip() == head
subprocess.run(["git", "-C", str(root), "diff", "--exit-code", "HEAD", "--", "."], check=True)
inputs = read("source-inputs.json")
assert inputs["head"] == head and len(inputs["files"]) == 765
for item in inputs["files"]:
    assert digest(root / item["path"]) == item["sha256"], item["path"]

tree = ast.parse((root / "tools/test_startup_validation.py").read_text(encoding="utf-8"))
cases = next(node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == "cases" for target in node.targets))
names = [ast.literal_eval(case.elts[0]) for case in cases.elts]
assert len(names) == 29 and len(set(names)) == 29
lines = (scratch / "startup.log").read_text(encoding="utf-8-sig").splitlines()
expected = [f"PASS {state} {name}" for state in ("empty", "seeded") for name in names]
expected += [
    "PASS runner and orphan-artifact startup recovery on a disposable clone",
    "PASS development startup, migration, demo persistence and restart",
    "PASS explicit CLI rejection and secret-safe help",
    "PASS production startup with TLS storage and signing bytes 32",
    "PASS production startup with TLS storage and signing bytes 33",
]
assert Counter(line for line in lines if line.startswith("PASS ")) == Counter(expected)
assert lines[-1] == "All startup regressions passed; owned infrastructure removed."

images = ["startup-invocation.png", "startup-progress.png", "startup-result.png"]
for name, phase in zip(images, ("invocation", "progress", "result")):
    capture = read(f"capture-{phase}-result.json")
    assert capture["pid"] == 44088 and capture["window_id"] == 64495882
    image = (scratch / name).read_bytes()
    assert image[:8] == b"\x89PNG\r\n\x1a\n"
    assert struct.unpack(">II", image[16:24]) == (capture["screenshot_width"], capture["screenshot_height"])
    assert not (output / name).exists(), "Never replace an earlier screenshot."
    shutil.copyfile(scratch / name, output / name)

verification = dict(observed_utc=datetime.now(timezone.utc).isoformat(),
                    source=head, original_tracked_files_unchanged=765,
                    rejection_cases=58, pass_lines=63, complete_startup_exit=0,
                    standalone_build_exit=0, independent_cleanup_verified=True,
                    native_images=3, image_dimensions=[977, 510],
                    scope="Receipt integrity/readback, not a substitute or additional application test.")
(scratch / "verification.json").write_text(json.dumps(verification, indent=2) + "\n", encoding="utf-8")
members = [
    "build.json", "build.log", "capture-startup.ps1", "run.json", "startup.log",
    "terminal-transcript.txt", "source-inputs.json", "source-tree.txt",
    "remote-before.json", "tool-identities.json", "docker-version.json",
    "postgres-image.json", "python-process.json", "temp-during.json",
    "owned-container.json", "children-during.json", "fixture-listeners.json",
    "cleanup.json", "event-query.json", "owned-container-events.jsonl",
    "owned-container-events-rfc3339.jsonl", "windows-initial.json",
    "windows-after-release.json", "launch-request.json", "launch-result.json",
    "capture-invocation-request.json", "capture-invocation-result.json",
    "capture-progress-request.json", "capture-progress-result.json",
    "capture-result-request.json", "capture-result-result.json",
    "diagnostics.md", "verification.json", "package-evidence.py",
]
with zipfile.ZipFile(output / "receipts.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
    for name in members:
        archive.write(scratch / name, name)
with zipfile.ZipFile(output / "receipts.zip") as archive:
    assert archive.testzip() is None
    assert archive.namelist() == members
    for name in members:
        assert archive.read(name) == (scratch / name).read_bytes()
manifest = dict(schema_version=1, source=head,
                base="410eddfc8bfcfa874dae05555128d39a914f0456",
                finding="F-362-B-01", verification=verification,
                archive_members=[dict(path=name, bytes=(scratch/name).stat().st_size,
                                      sha256=digest(scratch/name)) for name in members],
                files=[dict(path=name, bytes=(output/name).stat().st_size,
                            sha256=digest(output/name))
                       for name in ["README.md", "receipts.zip", *images]])
with (output / "manifest.json").open("x", encoding="utf-8") as target:
    json.dump(manifest, target, indent=2)
    target.write("\n")
print(json.dumps(verification, indent=2))
print(f"Packaged {len(members)} exact receipt members and {len(images)} unchanged native PNGs.")
