# Preserved non-test diagnostics

The fresh standalone build and complete startup invocation both exited 0 on
their first execution in this worker. The following were tooling/readback
diagnostics, not failures or reruns of the startup regression:

1. An initial PowerShell Git identity read did not quote `HEAD^{tree}`.
   PowerShell parsed the braces and Git reported
   `fatal: ambiguous argument 'dAByAGUAZQA=': unknown revision or path not in the working tree.`
   Quoting `'HEAD^{tree}'` returned the recorded source tree. No ref mutation
   occurred in that failed read.
2. The first live monitor read reached `startup.log` before the harness's first
   output. That monitoring command returned 1; the native Python process kept
   running. No test timeout, restart or skip occurred.
3. The first bounded Docker lifecycle-event query passed PowerShell's
   date-coerced JSON value to the native CLI. Docker rejected it:
   `failed to parse value as time or duration: "09/21/2026 20:15:48"`.
   Independent cleanup reads had already succeeded. The failed query produced
   no JSON receipt; its diagnostic is retained here. A new read with an explicit
   RFC3339 timestamp succeeded and is retained separately as
   `owned-container-events-rfc3339.jsonl`. The original failed query was not
   a failed cleanup operation and performed no mutation.
4. Initial evidence packaging incorrectly expected that failed event query to
   have created an empty file. It failed with `FileNotFoundError` after creating
   a partial ZIP. The original script/log and that partial ZIP were retained;
   `failed-packaging.json` identifies and hashes the preserved partial archive.
   Packaging v2 records the actual absence rather than manufacturing a receipt.
   It reuses only byte-identical existing PNGs. No build or regression was rerun.

The Cua launch call took time to settle the console host/child identity.
An initial window lookup by conhost PID 66532 returned no windows. Read-only
discovery found the console owned by shell PID 44088; the eventual launch
response confirmed that PID and HWND 64495882 with `active:false`.
No duplicate launch, foreground fallback, UI shell shim or replacement image
was used.

Earlier attempts and original committed PR evidence remain untouched in their
original locations. This directory is a new execution, not rewritten history.
